function [] = simSetup(obstacles, targets,hardware,file)
%SIMSETUP This file should setup the workspace for the simulation
%
% The execution of this file is timed and included in your course score.
% This file takes as inputs the arrays locating the obstacles and the
% targets of the obstacle course. Then your team can do any processing in
% here that you would like (such as initial path planning, etc).
%
% This function will know if the simulation is being done on the hardware
% or in software based upon the status of the "hardware" variable. If
% hardware=1, then the actual crane hardware is being used.

start_course=0;
waypoints_list= py.solve_course_csv.find_result([pwd '\..\..\Courses\' file]);
total_waypoints=length(waypoints_list);
waypoints_cell=cell(waypoints_list);
xwaypoints_cell=cell(total_waypoints,1);
ywaypoints_cell=cell(total_waypoints,1);

for i=1:total_waypoints
	xwaypoints_cell{i}=waypoints_cell{i}{1};
    ywaypoints_cell{i}=waypoints_cell{i}{2};
	tags_cell{i}=waypoints_cell{i}{3};
	xwaypoints(i)=double(xwaypoints_cell{i})/100;
	ywaypoints(i)=double(ywaypoints_cell{i})/100;
	tags(i)=double(tags_cell{i});
end



%% Run Crane Hardware
if(hardware==1)
%Set Timeout
t=9;
Ts=1/100;
start_course=1;


%% Crane Software Model Setup
else
% SimscapeCrane_MPC_start;
load('Params_Simscape.mat');
load('SSmodelParams.mat');
% Load the dynamics matrices using a solution from last assignment
Ts=1/100;
T=10;
x0=[0 0 0 0 0 0 0 0]'; % starting offset
% Refine friction model
TxVisc = 49.1750;
TxCoulomb = 2.5;
TxBreak = 0;
xZero = 0.;
yZero = 0.0;
TyBreak = 0;
TyVisc = 47.5650;
TyCoulomb = 1.8;
TzVisc = 342; %Z friciton without contant frictional force added by the 

%Set Time Out
t=7;
start_course=1;
end
% Run Software Model
	
%error('You should insert your own code here');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DO NOT DELETE THIS
save('workspace.mat');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear waypoints_list;

end

