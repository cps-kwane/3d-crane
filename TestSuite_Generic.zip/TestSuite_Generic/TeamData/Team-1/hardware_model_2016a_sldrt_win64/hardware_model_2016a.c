/*
 * hardware_model_2016a.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "hardware_model_2016a".
 *
 * Model version              : 1.141
 * Simulink Coder version : 8.10 (R2016a) 10-Feb-2016
 * C source code generated on : Wed Jan 10 20:24:33 2018
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "hardware_model_2016a.h"
#include "hardware_model_2016a_private.h"
#include "hardware_model_2016a_dt.h"

/* Named constants for Chart: '<Root>/HL_Controller' */
#define hardware_model_2016a_CALL_EVENT (-1)
#define hardware_model_2016a_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define hardware_model_2016a_IN_S0_IDLE ((uint8_T)1U)
#define hardware_model_2016a_IN_S1_Initialize ((uint8_T)2U)
#define hardware_model_2016a_IN_S2_Move_to_waypoint ((uint8_T)3U)
#define hardware_model_2016a_IN_S3_wait_for_arrival ((uint8_T)4U)
#define hardware_model_2016a_IN_S4_checkifdone ((uint8_T)5U)
#define hardware_model_2016a_IN_S5_done ((uint8_T)6U)
#define hardware_model_2016a_IN_s3_delay ((uint8_T)7U)

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.01, 0.0,
};

/* Block signals (auto storage) */
B_hardware_model_2016a_T hardware_model_2016a_B;

/* Continuous states */
X_hardware_model_2016a_T hardware_model_2016a_X;

/* Block states (auto storage) */
DW_hardware_model_2016a_T hardware_model_2016a_DW;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_hardware_model_2016a_T hardware_model_2016a_Y;

/* Real-time model */
RT_MODEL_hardware_model_2016a_T hardware_model_2016a_M_;
RT_MODEL_hardware_model_2016a_T *const hardware_model_2016a_M =
  &hardware_model_2016a_M_;

/* Forward declaration for local functions */
static void hardware_model_2016a_func3_CheckDone(real_T count, real_T total);
static void hardware_model_2016a_setpidy(real_T ycurrent, real_T ydest, real_T
  *Kp, real_T *Ki, real_T *Kpa, real_T *swy);
static void hardware_model_2016a_func1_setpidy(real_T ycurrent, real_T ydest);
static void hardware_model_2016a_setpidx(real_T xcurrent, real_T xdest, real_T
  *Kix, real_T *Kpax, real_T *Kpx, real_T *swx);
static void hardware_model_2016a_func1_setpidx(real_T xcurrent, real_T xdest);
static void hardware_model_2016a_func2_CheckArrival(real_T currentx, real_T
  currenty, real_T xdest, real_T ydest);

/*
 * This function updates continuous states using the ODE5 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE5_A[6] = {
    1.0/5.0, 3.0/10.0, 4.0/5.0, 8.0/9.0, 1.0, 1.0
  };

  static const real_T rt_ODE5_B[6][6] = {
    { 1.0/5.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 3.0/40.0, 9.0/40.0, 0.0, 0.0, 0.0, 0.0 },

    { 44.0/45.0, -56.0/15.0, 32.0/9.0, 0.0, 0.0, 0.0 },

    { 19372.0/6561.0, -25360.0/2187.0, 64448.0/6561.0, -212.0/729.0, 0.0, 0.0 },

    { 9017.0/3168.0, -355.0/33.0, 46732.0/5247.0, 49.0/176.0, -5103.0/18656.0,
      0.0 },

    { 35.0/384.0, 0.0, 500.0/1113.0, 125.0/192.0, -2187.0/6784.0, 11.0/84.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE5_IntgData *id = (ODE5_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T *f4 = id->f[4];
  real_T *f5 = id->f[5];
  real_T hB[6];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  hardware_model_2016a_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE5_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[0]);
  rtsiSetdX(si, f1);
  hardware_model_2016a_output();
  hardware_model_2016a_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE5_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[1]);
  rtsiSetdX(si, f2);
  hardware_model_2016a_output();
  hardware_model_2016a_derivatives();

  /* f(:,4) = feval(odefile, t + hA(3), y + f*hB(:,3), args(:)(*)); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE5_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[2]);
  rtsiSetdX(si, f3);
  hardware_model_2016a_output();
  hardware_model_2016a_derivatives();

  /* f(:,5) = feval(odefile, t + hA(4), y + f*hB(:,4), args(:)(*)); */
  for (i = 0; i <= 3; i++) {
    hB[i] = h * rt_ODE5_B[3][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[3]);
  rtsiSetdX(si, f4);
  hardware_model_2016a_output();
  hardware_model_2016a_derivatives();

  /* f(:,6) = feval(odefile, t + hA(5), y + f*hB(:,5), args(:)(*)); */
  for (i = 0; i <= 4; i++) {
    hB[i] = h * rt_ODE5_B[4][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f5);
  hardware_model_2016a_output();
  hardware_model_2016a_derivatives();

  /* tnew = t + hA(6);
     ynew = y + f*hB(:,6); */
  for (i = 0; i <= 5; i++) {
    hB[i] = h * rt_ODE5_B[5][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4] + f5[i]*hB[5]);
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Function for Chart: '<Root>/HL_Controller' */
static void hardware_model_2016a_func3_CheckDone(real_T count, real_T total)
{
  /* MATLAB Function 'func3_CheckDone': '<S2>:49' */
  /* Graphical Function 'func3_CheckDone': '<S2>:49' */
  /* '<S2>:59:1' */
  if (count > total) {
    /* '<S2>:58:1' */
    hardware_model_2016a_DW.finished = 1.0;
  } else {
    /* '<S2>:57:1' */
    hardware_model_2016a_DW.finished = 0.0;
  }
}

/* Function for Chart: '<Root>/HL_Controller' */
static void hardware_model_2016a_setpidy(real_T ycurrent, real_T ydest, real_T
  *Kp, real_T *Ki, real_T *Kpa, real_T *swy)
{
  real_T temp;

  /* MATLAB Function 'setpidy': '<S2>:10' */
  /* '<S2>:10:2' */
  *swy = 1.0;
  if (ycurrent >= 50.0) {
    /* '<S2>:10:3' */
    /* '<S2>:10:4' */
    ycurrent = 0.0;
  }

  /* '<S2>:10:6' */
  temp = fabs(ycurrent - ydest);
  if (temp <= 0.005) {
    /* '<S2>:10:7' */
    /* '<S2>:10:8' */
    *Kp = 0.0;

    /* '<S2>:10:9' */
    *Ki = 0.0;

    /* '<S2>:10:10' */
    *Kpa = 0.0;

    /* '<S2>:10:11' */
    *swy = 0.0;
  } else if (temp <= 0.02) {
    /* '<S2>:10:12' */
    /* '<S2>:10:13' */
    *Ki = 2.8;

    /* '<S2>:10:14' */
    *Kp = 29.0;

    /* '<S2>:10:15' */
    *Kpa = 7.5;
  } else if (temp <= 0.04) {
    /* '<S2>:10:16' */
    /* '<S2>:10:17' */
    *Ki = 0.01;

    /* '<S2>:10:18' */
    *Kp = 13.0;

    /* '<S2>:10:19' */
    *Kpa = 7.5;
  } else if (temp <= 0.06) {
    /* '<S2>:10:20' */
    /* '<S2>:10:21' */
    *Ki = 0.2;

    /* '<S2>:10:22' */
    *Kp = 8.2;

    /* '<S2>:10:23' */
    *Kpa = 5.2;
  } else if (temp <= 0.08) {
    /* '<S2>:10:24' */
    /* '<S2>:10:25' */
    *Ki = 0.05;

    /* '<S2>:10:26' */
    *Kp = 6.6;

    /* '<S2>:10:27' */
    *Kpa = 4.2;
  } else if (temp <= 0.09) {
    /* '<S2>:10:28' */
    /* '<S2>:10:29' */
    *Ki = 0.1;

    /* '<S2>:10:30' */
    *Kp = 5.8;

    /* '<S2>:10:31' */
    *Kpa = 3.0;
  } else if (temp <= 0.1) {
    /* '<S2>:10:32' */
    /* '<S2>:10:33' */
    *Ki = 0.02;

    /* '<S2>:10:34' */
    *Kp = 5.4;

    /* '<S2>:10:35' */
    *Kpa = 4.05;
  } else if (temp <= 0.11) {
    /* '<S2>:10:36' */
    /* '<S2>:10:37' */
    *Ki = 0.01;

    /* '<S2>:10:38' */
    *Kp = 5.1;

    /* '<S2>:10:39' */
    *Kpa = 3.4;

    /* tsy=3.5 */
  } else if (temp <= 0.12) {
    /* '<S2>:10:41' */
    /* '<S2>:10:42' */
    *Ki = 0.01;

    /* '<S2>:10:43' */
    *Kp = 5.1;

    /* '<S2>:10:44' */
    *Kpa = 3.4;

    /* tsy=3.5 */
  } else if (temp <= 0.15) {
    /* '<S2>:10:46' */
    /* '<S2>:10:47' */
    *Ki = 0.02;

    /* '<S2>:10:48' */
    *Kp = 4.5;

    /* '<S2>:10:49' */
    *Kpa = 4.2;
  } else if (temp <= 0.18) {
    /* '<S2>:10:50' */
    /* '<S2>:10:51' */
    *Ki = 0.02;

    /* '<S2>:10:52' */
    *Kp = 4.2;

    /* '<S2>:10:53' */
    *Kpa = 3.6;
  } else if (temp <= 0.2) {
    /* '<S2>:10:54' */
    /* '<S2>:10:55' */
    *Ki = 0.025;

    /* '<S2>:10:56' */
    *Kp = 3.9;

    /* '<S2>:10:57' */
    *Kpa = 3.6;
  } else if (temp <= 0.23) {
    /* '<S2>:10:58' */
    /* '<S2>:10:59' */
    *Ki = 0.01;

    /* '<S2>:10:60' */
    *Kp = 3.6;

    /* '<S2>:10:61' */
    *Kpa = 5.0;
  } else if (temp <= 0.25) {
    /* '<S2>:10:62' */
    /* '<S2>:10:63' */
    *Ki = 0.01;

    /* '<S2>:10:64' */
    *Kp = 3.4;

    /* '<S2>:10:65' */
    *Kpa = 5.0;
  } else if (temp <= 0.28) {
    /* '<S2>:10:66' */
    /* '<S2>:10:67' */
    *Ki = 0.01;

    /* '<S2>:10:68' */
    *Kp = 3.4;

    /* '<S2>:10:69' */
    *Kpa = 5.2;
  } else if (temp <= 0.3) {
    /* '<S2>:10:70' */
    /* '<S2>:10:71' */
    *Ki = 0.01;

    /* '<S2>:10:72' */
    *Kp = 3.2;

    /* '<S2>:10:73' */
    *Kpa = 5.0;
  } else if (temp <= 0.33) {
    /* '<S2>:10:74' */
    /* '<S2>:10:75' */
    *Ki = 0.002;

    /* '<S2>:10:76' */
    *Kp = 3.2;

    /* '<S2>:10:77' */
    *Kpa = 5.2;
  } else if (temp <= 0.35) {
    /* '<S2>:10:78' */
    /* '<S2>:10:79' */
    *Ki = 0.01;

    /* '<S2>:10:80' */
    *Kp = 3.0;

    /* '<S2>:10:81' */
    *Kpa = 5.5;
  } else if (temp <= 0.4) {
    /* '<S2>:10:82' */
    /* '<S2>:10:83' */
    *Ki = 0.01;

    /* '<S2>:10:84' */
    *Kp = 3.0;

    /* '<S2>:10:85' */
    *Kpa = 5.6;
  } else if (temp <= 0.42) {
    /* '<S2>:10:86' */
    /* '<S2>:10:87' */
    *Ki = 0.01;

    /* '<S2>:10:88' */
    *Kp = 3.0;

    /* '<S2>:10:89' */
    *Kpa = 5.2;
  } else if (temp <= 0.47) {
    /* '<S2>:10:90' */
    /* '<S2>:10:91' */
    *Ki = 0.012;

    /* '<S2>:10:92' */
    *Kp = 2.9;

    /* '<S2>:10:93' */
    *Kpa = 5.2;
  } else {
    /* '<S2>:10:95' */
    *Kp = 0.0;

    /* '<S2>:10:96' */
    *Ki = 0.0;

    /* '<S2>:10:97' */
    *Kpa = 0.0;

    /* '<S2>:10:98' */
    *swy = 0.0;
  }
}

/* Function for Chart: '<Root>/HL_Controller' */
static void hardware_model_2016a_func1_setpidy(real_T ycurrent, real_T ydest)
{
  real_T Kp_l;
  real_T Ki_l;
  real_T Kpa_l;
  real_T swy_l;

  /* MATLAB Function 'func1_setpidy': '<S2>:13' */
  /* Graphical Function 'func1_setpidy': '<S2>:13' */
  /* '<S2>:38:1' */
  hardware_model_2016a_setpidy(ycurrent, ydest, &Kp_l, &Ki_l, &Kpa_l, &swy_l);

  /* '<S2>:38:1' */
  hardware_model_2016a_DW.Kp_l = Kp_l;

  /* '<S2>:38:1' */
  hardware_model_2016a_DW.Ki_l = Ki_l;

  /* '<S2>:38:1' */
  hardware_model_2016a_DW.Kpa_l = Kpa_l;

  /* '<S2>:38:1' */
  hardware_model_2016a_DW.swy_l = swy_l;
}

/* Function for Chart: '<Root>/HL_Controller' */
static void hardware_model_2016a_setpidx(real_T xcurrent, real_T xdest, real_T
  *Kix, real_T *Kpax, real_T *Kpx, real_T *swx)
{
  real_T temp;

  /* MATLAB Function 'setpidx': '<S2>:24' */
  /* '<S2>:24:2' */
  *swx = 1.0;
  if (xcurrent >= 50.0) {
    /* '<S2>:24:3' */
    /* '<S2>:24:4' */
    xcurrent = 0.0;
  }

  /* '<S2>:24:6' */
  temp = fabs(xcurrent - xdest);
  if (temp <= 0.005) {
    /* '<S2>:24:7' */
    /* '<S2>:24:8' */
    *swx = 0.0;

    /* '<S2>:24:9' */
    *Kix = 0.0;

    /* '<S2>:24:10' */
    *Kpx = 0.0;

    /* '<S2>:24:11' */
    *Kpax = 0.0;
  } else if (temp <= 0.02) {
    /* '<S2>:24:12' */
    /* '<S2>:24:13' */
    *Kix = 0.0;

    /* '<S2>:24:14' */
    *Kpx = 30.0;

    /* '<S2>:24:15' */
    *Kpax = 5.5;
  } else if (temp <= 0.04) {
    /* '<S2>:24:16' */
    /* '<S2>:24:17' */
    *Kix = 0.01;

    /* '<S2>:24:18' */
    *Kpx = 17.0;

    /* '<S2>:24:19' */
    *Kpax = 7.0;
  } else if (temp <= 0.06) {
    /* '<S2>:24:20' */
    /* '<S2>:24:21' */
    *Kix = 0.2;

    /* '<S2>:24:22' */
    *Kpx = 9.5;

    /* '<S2>:24:23' */
    *Kpax = 6.0;
  } else if (temp <= 0.08) {
    /* '<S2>:24:24' */
    /* '<S2>:24:25' */
    *Kix = 0.01;

    /* '<S2>:24:26' */
    *Kpx = 7.5;

    /* '<S2>:24:27' */
    *Kpax = 6.0;
  } else if (temp <= 0.09) {
    /* '<S2>:24:28' */
    /* '<S2>:24:29' */
    *Kix = 0.1;

    /* '<S2>:24:30' */
    *Kpx = 6.8;

    /* '<S2>:24:31' */
    *Kpax = 4.0;
  } else if (temp <= 0.1) {
    /* '<S2>:24:32' */
    /* '<S2>:24:33' */
    *Kix = 0.08;

    /* '<S2>:24:34' */
    *Kpx = 6.2;

    /* '<S2>:24:35' */
    *Kpax = 4.6;
  } else if (temp <= 0.11) {
    /* '<S2>:24:36' */
    /* '<S2>:24:37' */
    *Kix = 0.25;

    /* '<S2>:24:38' */
    *Kpx = 5.8;

    /* '<S2>:24:39' */
    *Kpax = 3.4;

    /* tsx=3.5 */
  } else if (temp <= 0.12) {
    /* '<S2>:24:41' */
    /* '<S2>:24:42' */
    *Kix = 0.15;

    /* '<S2>:24:43' */
    *Kpx = 5.6;

    /* '<S2>:24:44' */
    *Kpax = 3.4;

    /* tsx=3 */
  } else if (temp <= 0.15) {
    /* '<S2>:24:46' */
    /* '<S2>:24:47' */
    *Kix = 0.05;

    /* '<S2>:24:48' */
    *Kpx = 5.2;

    /* '<S2>:24:49' */
    *Kpax = 4.1;
  } else if (temp <= 0.18) {
    /* '<S2>:24:50' */
    /* '<S2>:24:51' */
    *Kix = 0.02;

    /* '<S2>:24:52' */
    *Kpx = 4.6;

    /* '<S2>:24:53' */
    *Kpax = 4.4;
  } else if (temp <= 0.2) {
    /* '<S2>:24:54' */
    /* '<S2>:24:55' */
    *Kix = 0.005;

    /* '<S2>:24:56' */
    *Kpx = 4.42;

    /* '<S2>:24:57' */
    *Kpax = 4.4;
  } else if (temp <= 0.23) {
    /* '<S2>:24:58' */
    /* '<S2>:24:59' */
    *Kix = 0.02;

    /* '<S2>:24:60' */
    *Kpx = 4.0;

    /* '<S2>:24:61' */
    *Kpax = 5.2;
  } else if (temp <= 0.25) {
    /* '<S2>:24:62' */
    /* '<S2>:24:63' */
    *Kix = 0.02;

    /* '<S2>:24:64' */
    *Kpx = 3.8;

    /* '<S2>:24:65' */
    *Kpax = 5.2;
  } else if (temp <= 0.28) {
    /* '<S2>:24:66' */
    /* '<S2>:24:67' */
    *Kix = 0.01;

    /* '<S2>:24:68' */
    *Kpx = 3.7;

    /* '<S2>:24:69' */
    *Kpax = 5.2;
  } else if (temp <= 0.3) {
    /* '<S2>:24:70' */
    /* '<S2>:24:71' */
    *Kix = 0.01;

    /* '<S2>:24:72' */
    *Kpx = 3.6;

    /* '<S2>:24:73' */
    *Kpax = 5.0;
  } else if (temp <= 0.33) {
    /* '<S2>:24:74' */
    /* '<S2>:24:75' */
    *Kix = 0.0;

    /* '<S2>:24:76' */
    *Kpx = 3.5;

    /* '<S2>:24:77' */
    *Kpax = 5.6;
  } else if (temp <= 0.35) {
    /* '<S2>:24:78' */
    /* '<S2>:24:79' */
    *Kix = 0.005;

    /* '<S2>:24:80' */
    *Kpx = 3.4;

    /* '<S2>:24:81' */
    *Kpax = 5.2;
  } else if (temp <= 0.4) {
    /* '<S2>:24:82' */
    /* '<S2>:24:83' */
    *Kix = 0.01;

    /* '<S2>:24:84' */
    *Kpx = 3.2;

    /* '<S2>:24:85' */
    *Kpax = 5.8;
  } else if (temp <= 0.42) {
    /* '<S2>:24:86' */
    /* '<S2>:24:87' */
    *Kix = 0.01;

    /* '<S2>:24:88' */
    *Kpx = 3.2;

    /* '<S2>:24:89' */
    *Kpax = 5.4;
  } else if (temp <= 0.47) {
    /* '<S2>:24:90' */
    /* '<S2>:24:91' */
    *Kix = 0.005;

    /* '<S2>:24:92' */
    *Kpx = 3.2;

    /* '<S2>:24:93' */
    *Kpax = 5.4;
  } else {
    /* '<S2>:24:95' */
    *swx = 0.0;

    /* '<S2>:24:96' */
    *Kix = 0.0;

    /* '<S2>:24:97' */
    *Kpx = 0.0;

    /* '<S2>:24:98' */
    *Kpax = 0.0;
  }
}

/* Function for Chart: '<Root>/HL_Controller' */
static void hardware_model_2016a_func1_setpidx(real_T xcurrent, real_T xdest)
{
  real_T Kix_l;
  real_T Kpax_l;
  real_T Kpx_l;
  real_T swx_l;

  /* MATLAB Function 'func1_setpidx': '<S2>:17' */
  /* Graphical Function 'func1_setpidx': '<S2>:17' */
  /* '<S2>:26:1' */
  hardware_model_2016a_setpidx(xcurrent, xdest, &Kix_l, &Kpax_l, &Kpx_l, &swx_l);

  /* '<S2>:26:1' */
  hardware_model_2016a_DW.Kix_l = Kix_l;

  /* '<S2>:26:1' */
  hardware_model_2016a_DW.Kpax_l = Kpax_l;

  /* '<S2>:26:1' */
  hardware_model_2016a_DW.Kpx_l = Kpx_l;

  /* '<S2>:26:1' */
  hardware_model_2016a_DW.swx_l = swx_l;
}

/* Function for Chart: '<Root>/HL_Controller' */
static void hardware_model_2016a_func2_CheckArrival(real_T currentx, real_T
  currenty, real_T xdest, real_T ydest)
{
  boolean_T sf_internal_predicateOutput;

  /* MATLAB Function 'func2_CheckArrival': '<S2>:37' */
  /* Graphical Function 'func2_CheckArrival': '<S2>:37' */
  /*  checks for steady state */
  if ((fabs(xdest - currentx) < 0.004) && (fabs(ydest - currenty) < 0.004)) {
    /* '<S2>:46:1' */
    sf_internal_predicateOutput = true;
  } else {
    /* '<S2>:46:1' */
    sf_internal_predicateOutput = false;
  }

  if (sf_internal_predicateOutput) {
    /* '<S2>:46:1' */
    /* '<S2>:51:1' */
    hardware_model_2016a_DW.arrived = 1.0;
  } else {
    /* '<S2>:50:1' */
    hardware_model_2016a_DW.arrived = 0.0;
  }
}

/* Model output function */
void hardware_model_2016a_output(void)
{
  real_T rtb_Encoder500PPR[5];
  real_T rtb_Add1;
  real_T rtb_Switchx;
  real_T rtb_Add2;
  real_T rtb_Switchy;
  int32_T i;
  if (rtmIsMajorTimeStep(hardware_model_2016a_M)) {
    /* set solver stop time */
    if (!(hardware_model_2016a_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&hardware_model_2016a_M->solverInfo,
                            ((hardware_model_2016a_M->Timing.clockTickH0 + 1) *
        hardware_model_2016a_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&hardware_model_2016a_M->solverInfo,
                            ((hardware_model_2016a_M->Timing.clockTick0 + 1) *
        hardware_model_2016a_M->Timing.stepSize0 +
        hardware_model_2016a_M->Timing.clockTickH0 *
        hardware_model_2016a_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(hardware_model_2016a_M)) {
    hardware_model_2016a_M->Timing.t[0] = rtsiGetT
      (&hardware_model_2016a_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(hardware_model_2016a_M)) {
    /* Level2 S-Function Block: '<S1>/Encoder' (Crane3D_Encoder) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[0];
      sfcnOutputs(rts, 1);
    }

    /* Gain: '<S1>/Encoder 500PPR' */
    for (i = 0; i < 5; i++) {
      rtb_Encoder500PPR[i] = hardware_model_2016a_P.Encoder500PPR_Gain *
        hardware_model_2016a_B.Encoder[i];
    }

    /* End of Gain: '<S1>/Encoder 500PPR' */

    /* Gain: '<S1>/X Scale' */
    hardware_model_2016a_B.XScale = hardware_model_2016a_P.XScale_Gain *
      rtb_Encoder500PPR[0];

    /* Gain: '<S1>/Y Scale' */
    hardware_model_2016a_B.YScale = hardware_model_2016a_P.YScale_Gain *
      rtb_Encoder500PPR[1];

    /* Gain: '<S1>/Z Scale' */
    hardware_model_2016a_B.ZScale = hardware_model_2016a_P.ZScale_Gain *
      rtb_Encoder500PPR[2];

    /* Gain: '<S1>/X Angle Scale' */
    hardware_model_2016a_B.XAngleScale = hardware_model_2016a_P.XAngleScale_Gain
      * rtb_Encoder500PPR[3];

    /* Gain: '<S1>/Y Angle Scale' */
    hardware_model_2016a_B.YAngleScale = hardware_model_2016a_P.YAngleScale_Gain
      * rtb_Encoder500PPR[4];

    /* Gain: '<S3>/GainZ1' incorporates:
     *  Sum: '<S3>/Add1'
     *  UnitDelay: '<S3>/Unit Delay'
     */
    hardware_model_2016a_B.Derivatives[0] = (hardware_model_2016a_B.XScale -
      hardware_model_2016a_DW.UnitDelay_DSTATE[0]) *
      hardware_model_2016a_P.GainZ1_Gain;
    hardware_model_2016a_B.Derivatives[1] = (hardware_model_2016a_B.YScale -
      hardware_model_2016a_DW.UnitDelay_DSTATE[1]) *
      hardware_model_2016a_P.GainZ1_Gain;
    hardware_model_2016a_B.Derivatives[2] = (hardware_model_2016a_B.ZScale -
      hardware_model_2016a_DW.UnitDelay_DSTATE[2]) *
      hardware_model_2016a_P.GainZ1_Gain;
    hardware_model_2016a_B.Derivatives[3] = (hardware_model_2016a_B.XAngleScale
      - hardware_model_2016a_DW.UnitDelay_DSTATE[3]) *
      hardware_model_2016a_P.GainZ1_Gain;
    hardware_model_2016a_B.Derivatives[4] = (hardware_model_2016a_B.YAngleScale
      - hardware_model_2016a_DW.UnitDelay_DSTATE[4]) *
      hardware_model_2016a_P.GainZ1_Gain;

    /* Outport: '<Root>/2' */
    hardware_model_2016a_Y.u[0] = hardware_model_2016a_B.XScale;
    hardware_model_2016a_Y.u[1] = hardware_model_2016a_B.Derivatives[0];
    hardware_model_2016a_Y.u[2] = hardware_model_2016a_B.YScale;
    hardware_model_2016a_Y.u[3] = hardware_model_2016a_B.Derivatives[1];
    hardware_model_2016a_Y.u[4] = hardware_model_2016a_B.ZScale;
    hardware_model_2016a_Y.u[5] = hardware_model_2016a_B.Derivatives[2];
    hardware_model_2016a_Y.u[6] = hardware_model_2016a_B.XAngleScale;
    hardware_model_2016a_Y.u[7] = hardware_model_2016a_B.Derivatives[3];
    hardware_model_2016a_Y.u[8] = hardware_model_2016a_B.YAngleScale;
    hardware_model_2016a_Y.u[9] = hardware_model_2016a_B.Derivatives[4];

    /* Constant: '<Root>/xwaypoints' */
    memcpy(&hardware_model_2016a_B.xwaypoints[0],
           &hardware_model_2016a_P.xwaypoints_Value[0], sizeof(real_T) << 4U);

    /* Constant: '<Root>/ywaypoints ' */
    memcpy(&hardware_model_2016a_B.ywaypoints[0],
           &hardware_model_2016a_P.ywaypoints_Value[0], sizeof(real_T) << 4U);

    /* Constant: '<Root>/start_course' */
    hardware_model_2016a_B.start_course =
      hardware_model_2016a_P.start_course_Value;

    /* Constant: '<Root>/total_waypoints ' */
    hardware_model_2016a_B.total_waypoints =
      hardware_model_2016a_P.total_waypoints_Value;

    /* Constant: '<Root>/time' */
    hardware_model_2016a_B.time = hardware_model_2016a_P.time_Value;

    /* Chart: '<Root>/HL_Controller' */
    if (hardware_model_2016a_DW.temporalCounter_i1 < MAX_uint32_T) {
      hardware_model_2016a_DW.temporalCounter_i1++;
    }

    /* Gateway: HL_Controller */
    hardware_model_2016a_DW.sfEvent = hardware_model_2016a_CALL_EVENT;

    /* During: HL_Controller */
    if (hardware_model_2016a_DW.is_active_c3_hardware_model_2016a == 0U) {
      /* Entry: HL_Controller */
      hardware_model_2016a_DW.is_active_c3_hardware_model_2016a = 1U;

      /* Entry Internal: HL_Controller */
      /* Transition: '<S2>:63' */
      hardware_model_2016a_DW.is_c3_hardware_model_2016a =
        hardware_model_2016a_IN_S0_IDLE;

      /* Entry 'S0_IDLE': '<S2>:1' */
      hardware_model_2016a_DW.xlocal = 0.0;
      hardware_model_2016a_DW.ylocal = 0.0;
      hardware_model_2016a_B.done = false;
      hardware_model_2016a_DW.index = 1.0;
      hardware_model_2016a_DW.Kp_l = 0.0;
      hardware_model_2016a_DW.Ki_l = 0.0;
      hardware_model_2016a_DW.Kpa_l = 0.0;
      hardware_model_2016a_DW.Kix_l = 0.0;
      hardware_model_2016a_DW.Kpx_l = 0.0;
      hardware_model_2016a_DW.Kpax_l = 0.0;
      hardware_model_2016a_DW.swx_l = 0.0;
      hardware_model_2016a_DW.swy_l = 0.0;
      hardware_model_2016a_DW.waypoints_reached_l = 0.0;
    } else {
      switch (hardware_model_2016a_DW.is_c3_hardware_model_2016a) {
       case hardware_model_2016a_IN_S0_IDLE:
        /* During 'S0_IDLE': '<S2>:1' */
        if (hardware_model_2016a_B.start_course == 1.0) {
          /* Transition: '<S2>:65' */
          hardware_model_2016a_DW.is_c3_hardware_model_2016a =
            hardware_model_2016a_IN_S1_Initialize;

          /* Entry Internal 'S1_Initialize': '<S2>:25' */
          hardware_model_2016a_DW.is_active_S1_setpoints1 = 1U;

          /* Entry 'S1_setpoints1': '<S2>:27' */
          hardware_model_2016a_DW.xlocal = hardware_model_2016a_B.xwaypoints
            [(int32_T)hardware_model_2016a_DW.index - 1];
          hardware_model_2016a_DW.ylocal = hardware_model_2016a_B.ywaypoints
            [(int32_T)hardware_model_2016a_DW.index - 1];
          hardware_model_2016a_DW.arrived = 0.0;
          hardware_model_2016a_DW.is_active_S1_setup_pidy1 = 1U;

          /* Entry 'S1_setup_pidy1': '<S2>:28' */
          hardware_model_2016a_func1_setpidy(hardware_model_2016a_B.YScale,
            hardware_model_2016a_B.ywaypoints[(int32_T)
            hardware_model_2016a_DW.index - 1]);
          hardware_model_2016a_DW.is_active_S1_setup_pidy = 1U;

          /* Entry 'S1_setup_pidy': '<S2>:29' */
          hardware_model_2016a_func1_setpidx(hardware_model_2016a_B.XScale,
            hardware_model_2016a_B.xwaypoints[(int32_T)
            hardware_model_2016a_DW.index - 1]);
        }
        break;

       case hardware_model_2016a_IN_S1_Initialize:
        /* During 'S1_Initialize': '<S2>:25' */
        /* Transition: '<S2>:67' */
        /* Exit Internal 'S1_Initialize': '<S2>:25' */
        hardware_model_2016a_DW.is_active_S1_setup_pidy = 0U;
        hardware_model_2016a_DW.is_active_S1_setup_pidy1 = 0U;
        hardware_model_2016a_DW.is_active_S1_setpoints1 = 0U;
        hardware_model_2016a_DW.is_c3_hardware_model_2016a =
          hardware_model_2016a_IN_S2_Move_to_waypoint;

        /* Entry 'S2_Move_to_waypoint': '<S2>:30' */
        hardware_model_2016a_B.xref = hardware_model_2016a_DW.xlocal;
        hardware_model_2016a_B.yref = hardware_model_2016a_DW.ylocal;
        hardware_model_2016a_B.Kpy = hardware_model_2016a_DW.Kp_l;
        hardware_model_2016a_B.Kiy = hardware_model_2016a_DW.Ki_l;
        hardware_model_2016a_B.Kpay = hardware_model_2016a_DW.Kpa_l;
        hardware_model_2016a_B.kix = hardware_model_2016a_DW.Kix_l;
        hardware_model_2016a_B.kpx = hardware_model_2016a_DW.Kpx_l;
        hardware_model_2016a_B.kpax = hardware_model_2016a_DW.Kpax_l;
        hardware_model_2016a_DW.arrived = 0.0;
        hardware_model_2016a_DW.sustained = 0.0;
        hardware_model_2016a_B.SWX = hardware_model_2016a_DW.swx_l;
        hardware_model_2016a_B.SWY = hardware_model_2016a_DW.swy_l;
        break;

       case hardware_model_2016a_IN_S2_Move_to_waypoint:
        /* During 'S2_Move_to_waypoint': '<S2>:30' */
        /* Transition: '<S2>:73' */
        hardware_model_2016a_DW.is_c3_hardware_model_2016a =
          hardware_model_2016a_IN_S3_wait_for_arrival;
        hardware_model_2016a_DW.temporalCounter_i1 = 0U;

        /* Entry 'S3_wait_for_arrival': '<S2>:31' */
        hardware_model_2016a_DW.index++;
        break;

       case hardware_model_2016a_IN_S3_wait_for_arrival:
        /* During 'S3_wait_for_arrival': '<S2>:31' */
        if (hardware_model_2016a_DW.temporalCounter_i1 >= (uint32_T)ceil
            (hardware_model_2016a_B.time / 0.01 - 1.0E-10)) {
          /* Transition: '<S2>:72' */
          hardware_model_2016a_DW.is_c3_hardware_model_2016a =
            hardware_model_2016a_IN_S4_checkifdone;

          /* Entry 'S4_checkifdone': '<S2>:52' */
          hardware_model_2016a_func3_CheckDone(hardware_model_2016a_DW.index,
            hardware_model_2016a_B.total_waypoints);
          hardware_model_2016a_DW.waypoints_reached_l +=
            hardware_model_2016a_DW.arrived;
        } else if (hardware_model_2016a_DW.arrived == 1.0) {
          /* Transition: '<S2>:168' */
          hardware_model_2016a_DW.is_c3_hardware_model_2016a =
            hardware_model_2016a_IN_s3_delay;
        } else {
          hardware_model_2016a_func2_CheckArrival(hardware_model_2016a_B.XScale,
            hardware_model_2016a_B.YScale, hardware_model_2016a_DW.xlocal,
            hardware_model_2016a_DW.ylocal);
        }
        break;

       case hardware_model_2016a_IN_S4_checkifdone:
        /* During 'S4_checkifdone': '<S2>:52' */
        if (hardware_model_2016a_DW.finished == 1.0) {
          /* Transition: '<S2>:74' */
          hardware_model_2016a_DW.is_c3_hardware_model_2016a =
            hardware_model_2016a_IN_S5_done;

          /* Entry 'S5_done': '<S2>:62' */
          hardware_model_2016a_B.SWX = 0.0;
          hardware_model_2016a_B.SWY = 0.0;
          hardware_model_2016a_B.done = true;
          hardware_model_2016a_B.waypoints_reached =
            hardware_model_2016a_DW.waypoints_reached_l;
        } else {
          if (hardware_model_2016a_DW.finished == 0.0) {
            /* Transition: '<S2>:122' */
            hardware_model_2016a_DW.is_c3_hardware_model_2016a =
              hardware_model_2016a_IN_S1_Initialize;

            /* Entry Internal 'S1_Initialize': '<S2>:25' */
            hardware_model_2016a_DW.is_active_S1_setpoints1 = 1U;

            /* Entry 'S1_setpoints1': '<S2>:27' */
            hardware_model_2016a_DW.xlocal = hardware_model_2016a_B.xwaypoints
              [(int32_T)hardware_model_2016a_DW.index - 1];
            hardware_model_2016a_DW.ylocal = hardware_model_2016a_B.ywaypoints
              [(int32_T)hardware_model_2016a_DW.index - 1];
            hardware_model_2016a_DW.arrived = 0.0;
            hardware_model_2016a_DW.is_active_S1_setup_pidy1 = 1U;

            /* Entry 'S1_setup_pidy1': '<S2>:28' */
            hardware_model_2016a_func1_setpidy(hardware_model_2016a_B.YScale,
              hardware_model_2016a_B.ywaypoints[(int32_T)
              hardware_model_2016a_DW.index - 1]);
            hardware_model_2016a_DW.is_active_S1_setup_pidy = 1U;

            /* Entry 'S1_setup_pidy': '<S2>:29' */
            hardware_model_2016a_func1_setpidx(hardware_model_2016a_B.XScale,
              hardware_model_2016a_B.xwaypoints[(int32_T)
              hardware_model_2016a_DW.index - 1]);
          }
        }
        break;

       case hardware_model_2016a_IN_S5_done:
        /* During 'S5_done': '<S2>:62' */
        break;

       default:
        /* During 's3_delay': '<S2>:171' */
        /* Transition: '<S2>:174' */
        hardware_model_2016a_DW.is_c3_hardware_model_2016a =
          hardware_model_2016a_IN_S4_checkifdone;

        /* Entry 'S4_checkifdone': '<S2>:52' */
        hardware_model_2016a_func3_CheckDone(hardware_model_2016a_DW.index,
          hardware_model_2016a_B.total_waypoints);
        hardware_model_2016a_DW.waypoints_reached_l +=
          hardware_model_2016a_DW.arrived;
        break;
      }
    }

    /* End of Chart: '<Root>/HL_Controller' */

    /* Product: '<Root>/Product' */
    hardware_model_2016a_B.Product = hardware_model_2016a_B.kpax *
      hardware_model_2016a_B.XAngleScale;

    /* Sum: '<Root>/Add1' */
    rtb_Add1 = hardware_model_2016a_B.xref - hardware_model_2016a_B.XScale;

    /* Product: '<S4>/POut' */
    hardware_model_2016a_B.POut = rtb_Add1 * hardware_model_2016a_B.kpx;
  }

  /* Sum: '<Root>/Add' incorporates:
   *  Integrator: '<S4>/Integrator'
   *  Sum: '<S4>/Sum'
   */
  hardware_model_2016a_B.Add = (hardware_model_2016a_B.POut +
    hardware_model_2016a_X.Integrator_CSTATE) + hardware_model_2016a_B.Product;
  if (rtmIsMajorTimeStep(hardware_model_2016a_M)) {
    /* Product: '<Root>/Product1' */
    hardware_model_2016a_B.Product1 = hardware_model_2016a_B.YAngleScale *
      hardware_model_2016a_B.Kpay;

    /* Sum: '<Root>/Add2' */
    rtb_Add2 = hardware_model_2016a_B.yref - hardware_model_2016a_B.YScale;

    /* Product: '<S5>/POut' */
    hardware_model_2016a_B.POut_e = rtb_Add2 * hardware_model_2016a_B.Kpy;
  }

  /* Sum: '<Root>/Add3' incorporates:
   *  Integrator: '<S5>/Integrator'
   *  Sum: '<S5>/Sum'
   */
  hardware_model_2016a_B.Add3 = (hardware_model_2016a_B.POut_e +
    hardware_model_2016a_X.Integrator_CSTATE_n) +
    hardware_model_2016a_B.Product1;
  if (rtmIsMajorTimeStep(hardware_model_2016a_M)) {
    /* Stop: '<Root>/Stop Simulation' incorporates:
     *  Delay: '<Root>/Delay'
     */
    if (hardware_model_2016a_DW.Delay_DSTATE[0U]) {
      rtmSetStopRequested(hardware_model_2016a_M, 1);
    }

    /* End of Stop: '<Root>/Stop Simulation' */

    /* SignalConversion: '<Root>/TmpSignal ConversionAtTo Workspace1Inport1' */
    hardware_model_2016a_B.TmpSignalConversionAtToWorkspace1Inport1[0] =
      hardware_model_2016a_B.XScale;
    hardware_model_2016a_B.TmpSignalConversionAtToWorkspace1Inport1[1] =
      hardware_model_2016a_B.Derivatives[0];
    hardware_model_2016a_B.TmpSignalConversionAtToWorkspace1Inport1[2] =
      hardware_model_2016a_B.YScale;
    hardware_model_2016a_B.TmpSignalConversionAtToWorkspace1Inport1[3] =
      hardware_model_2016a_B.Derivatives[1];
    hardware_model_2016a_B.TmpSignalConversionAtToWorkspace1Inport1[4] =
      hardware_model_2016a_B.XAngleScale;
    hardware_model_2016a_B.TmpSignalConversionAtToWorkspace1Inport1[5] =
      hardware_model_2016a_B.Derivatives[3];
    hardware_model_2016a_B.TmpSignalConversionAtToWorkspace1Inport1[6] =
      hardware_model_2016a_B.YAngleScale;
    hardware_model_2016a_B.TmpSignalConversionAtToWorkspace1Inport1[7] =
      hardware_model_2016a_B.Derivatives[4];

    /* Level2 S-Function Block: '<S1>/PWM' (Crane3D_PWM) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[1];
      sfcnOutputs(rts, 1);
    }
  }

  /* Switch: '<Root>/Switchx' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  if (hardware_model_2016a_B.SWX > hardware_model_2016a_P.Switchx_Threshold) {
    /* Saturate: '<Root>/Saturation' */
    if (hardware_model_2016a_B.Add > hardware_model_2016a_P.Saturation_UpperSat)
    {
      rtb_Switchx = hardware_model_2016a_P.Saturation_UpperSat;
    } else if (hardware_model_2016a_B.Add <
               hardware_model_2016a_P.Saturation_LowerSat) {
      rtb_Switchx = hardware_model_2016a_P.Saturation_LowerSat;
    } else {
      rtb_Switchx = hardware_model_2016a_B.Add;
    }

    /* End of Saturate: '<Root>/Saturation' */
  } else {
    rtb_Switchx = hardware_model_2016a_P.Constant2_Value;
  }

  /* End of Switch: '<Root>/Switchx' */

  /* Switch: '<Root>/Switchy' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  if (hardware_model_2016a_B.SWY > hardware_model_2016a_P.Switchy_Threshold) {
    /* Saturate: '<Root>/Saturation1' */
    if (hardware_model_2016a_B.Add3 >
        hardware_model_2016a_P.Saturation1_UpperSat) {
      rtb_Switchy = hardware_model_2016a_P.Saturation1_UpperSat;
    } else if (hardware_model_2016a_B.Add3 <
               hardware_model_2016a_P.Saturation1_LowerSat) {
      rtb_Switchy = hardware_model_2016a_P.Saturation1_LowerSat;
    } else {
      rtb_Switchy = hardware_model_2016a_B.Add3;
    }

    /* End of Saturate: '<Root>/Saturation1' */
  } else {
    rtb_Switchy = hardware_model_2016a_P.Constant2_Value;
  }

  /* End of Switch: '<Root>/Switchy' */

  /* Saturate: '<S1>/Saturation' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  if (rtb_Switchx > hardware_model_2016a_P.Saturation_UpperSat_j) {
    hardware_model_2016a_B.Saturation[0] =
      hardware_model_2016a_P.Saturation_UpperSat_j;
  } else if (rtb_Switchx < hardware_model_2016a_P.Saturation_LowerSat_l) {
    hardware_model_2016a_B.Saturation[0] =
      hardware_model_2016a_P.Saturation_LowerSat_l;
  } else {
    hardware_model_2016a_B.Saturation[0] = rtb_Switchx;
  }

  if (rtb_Switchy > hardware_model_2016a_P.Saturation_UpperSat_j) {
    hardware_model_2016a_B.Saturation[1] =
      hardware_model_2016a_P.Saturation_UpperSat_j;
  } else if (rtb_Switchy < hardware_model_2016a_P.Saturation_LowerSat_l) {
    hardware_model_2016a_B.Saturation[1] =
      hardware_model_2016a_P.Saturation_LowerSat_l;
  } else {
    hardware_model_2016a_B.Saturation[1] = rtb_Switchy;
  }

  if (hardware_model_2016a_P.Constant2_Value >
      hardware_model_2016a_P.Saturation_UpperSat_j) {
    hardware_model_2016a_B.Saturation[2] =
      hardware_model_2016a_P.Saturation_UpperSat_j;
  } else if (hardware_model_2016a_P.Constant2_Value <
             hardware_model_2016a_P.Saturation_LowerSat_l) {
    hardware_model_2016a_B.Saturation[2] =
      hardware_model_2016a_P.Saturation_LowerSat_l;
  } else {
    hardware_model_2016a_B.Saturation[2] =
      hardware_model_2016a_P.Constant2_Value;
  }

  /* End of Saturate: '<S1>/Saturation' */
  if (rtmIsMajorTimeStep(hardware_model_2016a_M)) {
    /* Level2 S-Function Block: '<S1>/LimitFlag' (Crane3D_LimitFlag) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[2];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/LimitFlagSource' */
    hardware_model_2016a_B.LimitFlagSource[0] =
      hardware_model_2016a_P.LimitFlagSource_Value[0];

    /* Constant: '<S1>/LimitSource' */
    hardware_model_2016a_B.LimitSource[0] =
      hardware_model_2016a_P.LimitSource_Value[0];

    /* Constant: '<S1>/LimitFlagSource' */
    hardware_model_2016a_B.LimitFlagSource[1] =
      hardware_model_2016a_P.LimitFlagSource_Value[1];

    /* Constant: '<S1>/LimitSource' */
    hardware_model_2016a_B.LimitSource[1] =
      hardware_model_2016a_P.LimitSource_Value[1];

    /* Constant: '<S1>/LimitFlagSource' */
    hardware_model_2016a_B.LimitFlagSource[2] =
      hardware_model_2016a_P.LimitFlagSource_Value[2];

    /* Constant: '<S1>/LimitSource' */
    hardware_model_2016a_B.LimitSource[2] =
      hardware_model_2016a_P.LimitSource_Value[2];

    /* Level2 S-Function Block: '<S1>/SetLimit' (Crane3D_SetLimit) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[3];
      sfcnOutputs(rts, 1);
    }

    /* Level2 S-Function Block: '<S1>/LimitSwitch' (Crane3D_Switch) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[4];
      sfcnOutputs(rts, 1);
    }

    /* Level2 S-Function Block: '<S1>/PWMPrescaler' (Crane3D_PWMPrescaler) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[5];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/PWMPrescalerSource' */
    hardware_model_2016a_B.PWMPrescalerSource =
      hardware_model_2016a_P.PWMPrescalerSource_Value;

    /* Level2 S-Function Block: '<S1>/ResetEncoder' (Crane3D_ResetEncoder) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[6];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/ResetSource' */
    for (i = 0; i < 5; i++) {
      hardware_model_2016a_B.ResetSource[i] =
        hardware_model_2016a_P.ResetSource_Value[i];
    }

    /* End of Constant: '<S1>/ResetSource' */

    /* Level2 S-Function Block: '<S1>/ResetSwitchFlag ' (Crane3D_ResetSwitchFlag) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[7];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/ResetSwitchFlagSource' */
    hardware_model_2016a_B.ResetSwitchFlagSource[0] =
      hardware_model_2016a_P.ResetSwitchFlagSource_Value[0];
    hardware_model_2016a_B.ResetSwitchFlagSource[1] =
      hardware_model_2016a_P.ResetSwitchFlagSource_Value[1];
    hardware_model_2016a_B.ResetSwitchFlagSource[2] =
      hardware_model_2016a_P.ResetSwitchFlagSource_Value[2];

    /* Level2 S-Function Block: '<S1>/ThermFlag ' (Crane3D_ThermFlag) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[8];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/ThermFlagSource' */
    hardware_model_2016a_B.ThermFlagSource[0] =
      hardware_model_2016a_P.ThermFlagSource_Value[0];
    hardware_model_2016a_B.ThermFlagSource[1] =
      hardware_model_2016a_P.ThermFlagSource_Value[1];
    hardware_model_2016a_B.ThermFlagSource[2] =
      hardware_model_2016a_P.ThermFlagSource_Value[2];

    /* Product: '<S4>/IOut' */
    hardware_model_2016a_B.IOut = rtb_Add1 * hardware_model_2016a_B.kix;

    /* Product: '<S5>/IOut' */
    hardware_model_2016a_B.IOut_a = rtb_Add2 * hardware_model_2016a_B.Kiy;
  }
}

/* Model update function */
void hardware_model_2016a_update(void)
{
  int_T idxDelay;
  if (rtmIsMajorTimeStep(hardware_model_2016a_M)) {
    /* Update for UnitDelay: '<S3>/Unit Delay' */
    hardware_model_2016a_DW.UnitDelay_DSTATE[0] = hardware_model_2016a_B.XScale;
    hardware_model_2016a_DW.UnitDelay_DSTATE[1] = hardware_model_2016a_B.YScale;
    hardware_model_2016a_DW.UnitDelay_DSTATE[2] = hardware_model_2016a_B.ZScale;
    hardware_model_2016a_DW.UnitDelay_DSTATE[3] =
      hardware_model_2016a_B.XAngleScale;
    hardware_model_2016a_DW.UnitDelay_DSTATE[4] =
      hardware_model_2016a_B.YAngleScale;

    /* Update for Delay: '<Root>/Delay' */
    for (idxDelay = 0; idxDelay < 19; idxDelay++) {
      hardware_model_2016a_DW.Delay_DSTATE[idxDelay] =
        hardware_model_2016a_DW.Delay_DSTATE[idxDelay + 1];
    }

    hardware_model_2016a_DW.Delay_DSTATE[19] = hardware_model_2016a_B.done;

    /* End of Update for Delay: '<Root>/Delay' */
  }

  if (rtmIsMajorTimeStep(hardware_model_2016a_M)) {
    rt_ertODEUpdateContinuousStates(&hardware_model_2016a_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++hardware_model_2016a_M->Timing.clockTick0)) {
    ++hardware_model_2016a_M->Timing.clockTickH0;
  }

  hardware_model_2016a_M->Timing.t[0] = rtsiGetSolverStopTime
    (&hardware_model_2016a_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++hardware_model_2016a_M->Timing.clockTick1)) {
      ++hardware_model_2016a_M->Timing.clockTickH1;
    }

    hardware_model_2016a_M->Timing.t[1] =
      hardware_model_2016a_M->Timing.clockTick1 *
      hardware_model_2016a_M->Timing.stepSize1 +
      hardware_model_2016a_M->Timing.clockTickH1 *
      hardware_model_2016a_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void hardware_model_2016a_derivatives(void)
{
  XDot_hardware_model_2016a_T *_rtXdot;
  _rtXdot = ((XDot_hardware_model_2016a_T *)
             hardware_model_2016a_M->ModelData.derivs);

  /* Derivatives for Integrator: '<S4>/Integrator' */
  _rtXdot->Integrator_CSTATE = hardware_model_2016a_B.IOut;

  /* Derivatives for Integrator: '<S5>/Integrator' */
  _rtXdot->Integrator_CSTATE_n = hardware_model_2016a_B.IOut_a;
}

/* Model initialize function */
void hardware_model_2016a_initialize(void)
{
  {
    int32_T i;

    /* Start for Constant: '<Root>/xwaypoints' */
    memcpy(&hardware_model_2016a_B.xwaypoints[0],
           &hardware_model_2016a_P.xwaypoints_Value[0], sizeof(real_T) << 4U);

    /* Start for Constant: '<Root>/ywaypoints ' */
    memcpy(&hardware_model_2016a_B.ywaypoints[0],
           &hardware_model_2016a_P.ywaypoints_Value[0], sizeof(real_T) << 4U);

    /* Start for Constant: '<Root>/start_course' */
    hardware_model_2016a_B.start_course =
      hardware_model_2016a_P.start_course_Value;

    /* Start for Constant: '<Root>/total_waypoints ' */
    hardware_model_2016a_B.total_waypoints =
      hardware_model_2016a_P.total_waypoints_Value;

    /* Start for Constant: '<Root>/time' */
    hardware_model_2016a_B.time = hardware_model_2016a_P.time_Value;

    /* Start for Constant: '<S1>/LimitFlagSource' */
    hardware_model_2016a_B.LimitFlagSource[0] =
      hardware_model_2016a_P.LimitFlagSource_Value[0];

    /* Start for Constant: '<S1>/LimitSource' */
    hardware_model_2016a_B.LimitSource[0] =
      hardware_model_2016a_P.LimitSource_Value[0];

    /* Start for Constant: '<S1>/LimitFlagSource' */
    hardware_model_2016a_B.LimitFlagSource[1] =
      hardware_model_2016a_P.LimitFlagSource_Value[1];

    /* Start for Constant: '<S1>/LimitSource' */
    hardware_model_2016a_B.LimitSource[1] =
      hardware_model_2016a_P.LimitSource_Value[1];

    /* Start for Constant: '<S1>/LimitFlagSource' */
    hardware_model_2016a_B.LimitFlagSource[2] =
      hardware_model_2016a_P.LimitFlagSource_Value[2];

    /* Start for Constant: '<S1>/LimitSource' */
    hardware_model_2016a_B.LimitSource[2] =
      hardware_model_2016a_P.LimitSource_Value[2];

    /* Start for Constant: '<S1>/PWMPrescalerSource' */
    hardware_model_2016a_B.PWMPrescalerSource =
      hardware_model_2016a_P.PWMPrescalerSource_Value;

    /* Start for Constant: '<S1>/ResetSource' */
    for (i = 0; i < 5; i++) {
      hardware_model_2016a_B.ResetSource[i] =
        hardware_model_2016a_P.ResetSource_Value[i];
    }

    /* End of Start for Constant: '<S1>/ResetSource' */
    /* Start for Constant: '<S1>/ResetSwitchFlagSource' */
    hardware_model_2016a_B.ResetSwitchFlagSource[0] =
      hardware_model_2016a_P.ResetSwitchFlagSource_Value[0];
    hardware_model_2016a_B.ResetSwitchFlagSource[1] =
      hardware_model_2016a_P.ResetSwitchFlagSource_Value[1];
    hardware_model_2016a_B.ResetSwitchFlagSource[2] =
      hardware_model_2016a_P.ResetSwitchFlagSource_Value[2];

    /* Start for Constant: '<S1>/ThermFlagSource' */
    hardware_model_2016a_B.ThermFlagSource[0] =
      hardware_model_2016a_P.ThermFlagSource_Value[0];
    hardware_model_2016a_B.ThermFlagSource[1] =
      hardware_model_2016a_P.ThermFlagSource_Value[1];
    hardware_model_2016a_B.ThermFlagSource[2] =
      hardware_model_2016a_P.ThermFlagSource_Value[2];
  }

  {
    int32_T i;

    /* InitializeConditions for UnitDelay: '<S3>/Unit Delay' */
    for (i = 0; i < 5; i++) {
      hardware_model_2016a_DW.UnitDelay_DSTATE[i] =
        hardware_model_2016a_P.UnitDelay_InitialCondition[i];
    }

    /* End of InitializeConditions for UnitDelay: '<S3>/Unit Delay' */

    /* InitializeConditions for Integrator: '<S4>/Integrator' */
    hardware_model_2016a_X.Integrator_CSTATE =
      hardware_model_2016a_P.Integrator_IC;

    /* InitializeConditions for Integrator: '<S5>/Integrator' */
    hardware_model_2016a_X.Integrator_CSTATE_n =
      hardware_model_2016a_P.Integrator_IC_a;

    /* InitializeConditions for Delay: '<Root>/Delay' */
    for (i = 0; i < 20; i++) {
      hardware_model_2016a_DW.Delay_DSTATE[i] =
        hardware_model_2016a_P.Delay_InitialCondition;
    }

    /* End of InitializeConditions for Delay: '<Root>/Delay' */

    /* SystemInitialize for Chart: '<Root>/HL_Controller' */
    hardware_model_2016a_DW.sfEvent = hardware_model_2016a_CALL_EVENT;
    hardware_model_2016a_DW.is_active_S1_setpoints1 = 0U;
    hardware_model_2016a_DW.is_active_S1_setup_pidy = 0U;
    hardware_model_2016a_DW.is_active_S1_setup_pidy1 = 0U;
    hardware_model_2016a_DW.temporalCounter_i1 = 0U;
    hardware_model_2016a_DW.is_active_c3_hardware_model_2016a = 0U;
    hardware_model_2016a_DW.is_c3_hardware_model_2016a =
      hardware_model_2016a_IN_NO_ACTIVE_CHILD;
  }
}

/* Model terminate function */
void hardware_model_2016a_terminate(void)
{
  /* Level2 S-Function Block: '<S1>/Encoder' (Crane3D_Encoder) */
  {
    SimStruct *rts = hardware_model_2016a_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/PWM' (Crane3D_PWM) */
  {
    SimStruct *rts = hardware_model_2016a_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/LimitFlag' (Crane3D_LimitFlag) */
  {
    SimStruct *rts = hardware_model_2016a_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/SetLimit' (Crane3D_SetLimit) */
  {
    SimStruct *rts = hardware_model_2016a_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/LimitSwitch' (Crane3D_Switch) */
  {
    SimStruct *rts = hardware_model_2016a_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/PWMPrescaler' (Crane3D_PWMPrescaler) */
  {
    SimStruct *rts = hardware_model_2016a_M->childSfunctions[5];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/ResetEncoder' (Crane3D_ResetEncoder) */
  {
    SimStruct *rts = hardware_model_2016a_M->childSfunctions[6];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/ResetSwitchFlag ' (Crane3D_ResetSwitchFlag) */
  {
    SimStruct *rts = hardware_model_2016a_M->childSfunctions[7];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/ThermFlag ' (Crane3D_ThermFlag) */
  {
    SimStruct *rts = hardware_model_2016a_M->childSfunctions[8];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  hardware_model_2016a_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  hardware_model_2016a_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  hardware_model_2016a_initialize();
}

void MdlTerminate(void)
{
  hardware_model_2016a_terminate();
}

/* Registration function */
RT_MODEL_hardware_model_2016a_T *hardware_model_2016a(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)hardware_model_2016a_M, 0,
                sizeof(RT_MODEL_hardware_model_2016a_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&hardware_model_2016a_M->solverInfo,
                          &hardware_model_2016a_M->Timing.simTimeStep);
    rtsiSetTPtr(&hardware_model_2016a_M->solverInfo, &rtmGetTPtr
                (hardware_model_2016a_M));
    rtsiSetStepSizePtr(&hardware_model_2016a_M->solverInfo,
                       &hardware_model_2016a_M->Timing.stepSize0);
    rtsiSetdXPtr(&hardware_model_2016a_M->solverInfo,
                 &hardware_model_2016a_M->ModelData.derivs);
    rtsiSetContStatesPtr(&hardware_model_2016a_M->solverInfo, (real_T **)
                         &hardware_model_2016a_M->ModelData.contStates);
    rtsiSetNumContStatesPtr(&hardware_model_2016a_M->solverInfo,
      &hardware_model_2016a_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&hardware_model_2016a_M->solverInfo,
      &hardware_model_2016a_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&hardware_model_2016a_M->solverInfo,
      &hardware_model_2016a_M->ModelData.periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&hardware_model_2016a_M->solverInfo,
      &hardware_model_2016a_M->ModelData.periodicContStateRanges);
    rtsiSetErrorStatusPtr(&hardware_model_2016a_M->solverInfo,
                          (&rtmGetErrorStatus(hardware_model_2016a_M)));
    rtsiSetRTModelPtr(&hardware_model_2016a_M->solverInfo,
                      hardware_model_2016a_M);
  }

  rtsiSetSimTimeStep(&hardware_model_2016a_M->solverInfo, MAJOR_TIME_STEP);
  hardware_model_2016a_M->ModelData.intgData.y =
    hardware_model_2016a_M->ModelData.odeY;
  hardware_model_2016a_M->ModelData.intgData.f[0] =
    hardware_model_2016a_M->ModelData.odeF[0];
  hardware_model_2016a_M->ModelData.intgData.f[1] =
    hardware_model_2016a_M->ModelData.odeF[1];
  hardware_model_2016a_M->ModelData.intgData.f[2] =
    hardware_model_2016a_M->ModelData.odeF[2];
  hardware_model_2016a_M->ModelData.intgData.f[3] =
    hardware_model_2016a_M->ModelData.odeF[3];
  hardware_model_2016a_M->ModelData.intgData.f[4] =
    hardware_model_2016a_M->ModelData.odeF[4];
  hardware_model_2016a_M->ModelData.intgData.f[5] =
    hardware_model_2016a_M->ModelData.odeF[5];
  hardware_model_2016a_M->ModelData.contStates = ((real_T *)
    &hardware_model_2016a_X);
  rtsiSetSolverData(&hardware_model_2016a_M->solverInfo, (void *)
                    &hardware_model_2016a_M->ModelData.intgData);
  rtsiSetSolverName(&hardware_model_2016a_M->solverInfo,"ode5");
  hardware_model_2016a_M->solverInfoPtr = (&hardware_model_2016a_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = hardware_model_2016a_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    hardware_model_2016a_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    hardware_model_2016a_M->Timing.sampleTimes =
      (&hardware_model_2016a_M->Timing.sampleTimesArray[0]);
    hardware_model_2016a_M->Timing.offsetTimes =
      (&hardware_model_2016a_M->Timing.offsetTimesArray[0]);

    /* task periods */
    hardware_model_2016a_M->Timing.sampleTimes[0] = (0.0);
    hardware_model_2016a_M->Timing.sampleTimes[1] = (0.01);

    /* task offsets */
    hardware_model_2016a_M->Timing.offsetTimes[0] = (0.0);
    hardware_model_2016a_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(hardware_model_2016a_M, &hardware_model_2016a_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = hardware_model_2016a_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    hardware_model_2016a_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(hardware_model_2016a_M, 599.98);
  hardware_model_2016a_M->Timing.stepSize0 = 0.01;
  hardware_model_2016a_M->Timing.stepSize1 = 0.01;

  /* External mode info */
  hardware_model_2016a_M->Sizes.checksums[0] = (3949888350U);
  hardware_model_2016a_M->Sizes.checksums[1] = (3624964771U);
  hardware_model_2016a_M->Sizes.checksums[2] = (2767170567U);
  hardware_model_2016a_M->Sizes.checksums[3] = (2419688372U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[4];
    hardware_model_2016a_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(hardware_model_2016a_M->extModeInfo,
      &hardware_model_2016a_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(hardware_model_2016a_M->extModeInfo,
                        hardware_model_2016a_M->Sizes.checksums);
    rteiSetTPtr(hardware_model_2016a_M->extModeInfo, rtmGetTPtr
                (hardware_model_2016a_M));
  }

  hardware_model_2016a_M->solverInfoPtr = (&hardware_model_2016a_M->solverInfo);
  hardware_model_2016a_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&hardware_model_2016a_M->solverInfo, 0.01);
  rtsiSetSolverMode(&hardware_model_2016a_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  hardware_model_2016a_M->ModelData.blockIO = ((void *) &hardware_model_2016a_B);
  (void) memset(((void *) &hardware_model_2016a_B), 0,
                sizeof(B_hardware_model_2016a_T));

  {
    int32_T i;
    for (i = 0; i < 5; i++) {
      hardware_model_2016a_B.Encoder[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      hardware_model_2016a_B.Derivatives[i] = 0.0;
    }

    for (i = 0; i < 16; i++) {
      hardware_model_2016a_B.xwaypoints[i] = 0.0;
    }

    for (i = 0; i < 16; i++) {
      hardware_model_2016a_B.ywaypoints[i] = 0.0;
    }

    for (i = 0; i < 8; i++) {
      hardware_model_2016a_B.TmpSignalConversionAtToWorkspace1Inport1[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      hardware_model_2016a_B.ResetEncoder[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      hardware_model_2016a_B.ResetSource[i] = 0.0;
    }

    hardware_model_2016a_B.XScale = 0.0;
    hardware_model_2016a_B.YScale = 0.0;
    hardware_model_2016a_B.ZScale = 0.0;
    hardware_model_2016a_B.XAngleScale = 0.0;
    hardware_model_2016a_B.YAngleScale = 0.0;
    hardware_model_2016a_B.start_course = 0.0;
    hardware_model_2016a_B.total_waypoints = 0.0;
    hardware_model_2016a_B.time = 0.0;
    hardware_model_2016a_B.Product = 0.0;
    hardware_model_2016a_B.POut = 0.0;
    hardware_model_2016a_B.Add = 0.0;
    hardware_model_2016a_B.Product1 = 0.0;
    hardware_model_2016a_B.POut_e = 0.0;
    hardware_model_2016a_B.Add3 = 0.0;
    hardware_model_2016a_B.PWM[0] = 0.0;
    hardware_model_2016a_B.PWM[1] = 0.0;
    hardware_model_2016a_B.PWM[2] = 0.0;
    hardware_model_2016a_B.Saturation[0] = 0.0;
    hardware_model_2016a_B.Saturation[1] = 0.0;
    hardware_model_2016a_B.Saturation[2] = 0.0;
    hardware_model_2016a_B.LimitFlag[0] = 0.0;
    hardware_model_2016a_B.LimitFlag[1] = 0.0;
    hardware_model_2016a_B.LimitFlag[2] = 0.0;
    hardware_model_2016a_B.LimitFlagSource[0] = 0.0;
    hardware_model_2016a_B.LimitFlagSource[1] = 0.0;
    hardware_model_2016a_B.LimitFlagSource[2] = 0.0;
    hardware_model_2016a_B.LimitSource[0] = 0.0;
    hardware_model_2016a_B.LimitSource[1] = 0.0;
    hardware_model_2016a_B.LimitSource[2] = 0.0;
    hardware_model_2016a_B.SetLimit[0] = 0.0;
    hardware_model_2016a_B.SetLimit[1] = 0.0;
    hardware_model_2016a_B.SetLimit[2] = 0.0;
    hardware_model_2016a_B.LimitSwitch[0] = 0.0;
    hardware_model_2016a_B.LimitSwitch[1] = 0.0;
    hardware_model_2016a_B.LimitSwitch[2] = 0.0;
    hardware_model_2016a_B.PWMPrescaler = 0.0;
    hardware_model_2016a_B.PWMPrescalerSource = 0.0;
    hardware_model_2016a_B.ResetSwitchFlag[0] = 0.0;
    hardware_model_2016a_B.ResetSwitchFlag[1] = 0.0;
    hardware_model_2016a_B.ResetSwitchFlag[2] = 0.0;
    hardware_model_2016a_B.ResetSwitchFlagSource[0] = 0.0;
    hardware_model_2016a_B.ResetSwitchFlagSource[1] = 0.0;
    hardware_model_2016a_B.ResetSwitchFlagSource[2] = 0.0;
    hardware_model_2016a_B.ThermFlag[0] = 0.0;
    hardware_model_2016a_B.ThermFlag[1] = 0.0;
    hardware_model_2016a_B.ThermFlag[2] = 0.0;
    hardware_model_2016a_B.ThermFlagSource[0] = 0.0;
    hardware_model_2016a_B.ThermFlagSource[1] = 0.0;
    hardware_model_2016a_B.ThermFlagSource[2] = 0.0;
    hardware_model_2016a_B.IOut = 0.0;
    hardware_model_2016a_B.IOut_a = 0.0;
    hardware_model_2016a_B.kpax = 0.0;
    hardware_model_2016a_B.xref = 0.0;
    hardware_model_2016a_B.kpx = 0.0;
    hardware_model_2016a_B.kix = 0.0;
    hardware_model_2016a_B.Kpy = 0.0;
    hardware_model_2016a_B.Kiy = 0.0;
    hardware_model_2016a_B.SWX = 0.0;
    hardware_model_2016a_B.SWY = 0.0;
    hardware_model_2016a_B.yref = 0.0;
    hardware_model_2016a_B.Kpay = 0.0;
    hardware_model_2016a_B.waypoints_reached = 0.0;
  }

  /* parameters */
  hardware_model_2016a_M->ModelData.defaultParam = ((real_T *)
    &hardware_model_2016a_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &hardware_model_2016a_X;
    hardware_model_2016a_M->ModelData.contStates = (x);
    (void) memset((void *)&hardware_model_2016a_X, 0,
                  sizeof(X_hardware_model_2016a_T));
  }

  /* states (dwork) */
  hardware_model_2016a_M->ModelData.dwork = ((void *) &hardware_model_2016a_DW);
  (void) memset((void *)&hardware_model_2016a_DW, 0,
                sizeof(DW_hardware_model_2016a_T));

  {
    int32_T i;
    for (i = 0; i < 5; i++) {
      hardware_model_2016a_DW.UnitDelay_DSTATE[i] = 0.0;
    }
  }

  hardware_model_2016a_DW.finished = 0.0;
  hardware_model_2016a_DW.xlocal = 0.0;
  hardware_model_2016a_DW.ylocal = 0.0;
  hardware_model_2016a_DW.Ki_l = 0.0;
  hardware_model_2016a_DW.Kpx_l = 0.0;
  hardware_model_2016a_DW.Kpa_l = 0.0;
  hardware_model_2016a_DW.index = 0.0;
  hardware_model_2016a_DW.Kp_l = 0.0;
  hardware_model_2016a_DW.Kpax_l = 0.0;
  hardware_model_2016a_DW.Kix_l = 0.0;
  hardware_model_2016a_DW.arrived = 0.0;
  hardware_model_2016a_DW.waypoints_reached_l = 0.0;
  hardware_model_2016a_DW.swx_l = 0.0;
  hardware_model_2016a_DW.swy_l = 0.0;
  hardware_model_2016a_DW.sustained = 0.0;

  /* external outputs */
  hardware_model_2016a_M->ModelData.outputs = (&hardware_model_2016a_Y);

  {
    int32_T i;
    for (i = 0; i < 10; i++) {
      hardware_model_2016a_Y.u[i] = 0.0;
    }
  }

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    hardware_model_2016a_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &hardware_model_2016a_M->NonInlinedSFcns.sfcnInfo;
    hardware_model_2016a_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(hardware_model_2016a_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo,
      &hardware_model_2016a_M->Sizes.numSampTimes);
    hardware_model_2016a_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (hardware_model_2016a_M)[0]);
    hardware_model_2016a_M->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr
      (hardware_model_2016a_M)[1]);
    rtssSetTPtrPtr(sfcnInfo,hardware_model_2016a_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(hardware_model_2016a_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(hardware_model_2016a_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (hardware_model_2016a_M));
    rtssSetStepSizePtr(sfcnInfo, &hardware_model_2016a_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested
      (hardware_model_2016a_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &hardware_model_2016a_M->ModelData.derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &hardware_model_2016a_M->ModelData.zCCacheNeedsReset);
    rtssSetBlkStateChangePtr(sfcnInfo,
      &hardware_model_2016a_M->ModelData.blkStateChange);
    rtssSetSampleHitsPtr(sfcnInfo, &hardware_model_2016a_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &hardware_model_2016a_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &hardware_model_2016a_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &hardware_model_2016a_M->solverInfoPtr);
  }

  hardware_model_2016a_M->Sizes.numSFcns = (9);

  /* register each child */
  {
    (void) memset((void *)
                  &hardware_model_2016a_M->NonInlinedSFcns.childSFunctions[0], 0,
                  9*sizeof(SimStruct));
    hardware_model_2016a_M->childSfunctions =
      (&hardware_model_2016a_M->NonInlinedSFcns.childSFunctionPtrs[0]);

    {
      int_T i;
      for (i = 0; i < 9; i++) {
        hardware_model_2016a_M->childSfunctions[i] =
          (&hardware_model_2016a_M->NonInlinedSFcns.childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: hardware_model_2016a/<S1>/Encoder (Crane3D_Encoder) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = hardware_model_2016a_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &hardware_model_2016a_M->NonInlinedSFcns.blkInfo2
                         [0]);
      }

      ssSetRTWSfcnInfo(rts, hardware_model_2016a_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &hardware_model_2016a_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            hardware_model_2016a_B.Encoder));
        }
      }

      /* path info */
      ssSetModelName(rts, "Encoder");
      ssSetPath(rts, "hardware_model_2016a/Crane 3D/Encoder");
      ssSetRTModel(rts,hardware_model_2016a_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)hardware_model_2016a_P.Encoder_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)hardware_model_2016a_P.Encoder_P2_Size);
      }

      /* registration */
      Crane3D_Encoder(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: hardware_model_2016a/<S1>/PWM (Crane3D_PWM) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = hardware_model_2016a_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &hardware_model_2016a_M->NonInlinedSFcns.blkInfo2
                         [1]);
      }

      ssSetRTWSfcnInfo(rts, hardware_model_2016a_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &hardware_model_2016a_M->NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &hardware_model_2016a_M->NonInlinedSFcns.Sfcn1.UPtrs0;
          sfcnUPtrs[0] = hardware_model_2016a_B.Saturation;
          sfcnUPtrs[1] = &hardware_model_2016a_B.Saturation[1];
          sfcnUPtrs[2] = &hardware_model_2016a_B.Saturation[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *) hardware_model_2016a_B.PWM));
        }
      }

      /* path info */
      ssSetModelName(rts, "PWM");
      ssSetPath(rts, "hardware_model_2016a/Crane 3D/PWM");
      ssSetRTModel(rts,hardware_model_2016a_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)hardware_model_2016a_P.PWM_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)hardware_model_2016a_P.PWM_P2_Size);
      }

      /* registration */
      Crane3D_PWM(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: hardware_model_2016a/<S1>/LimitFlag (Crane3D_LimitFlag) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = hardware_model_2016a_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &hardware_model_2016a_M->NonInlinedSFcns.blkInfo2
                         [2]);
      }

      ssSetRTWSfcnInfo(rts, hardware_model_2016a_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &hardware_model_2016a_M->NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn2.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &hardware_model_2016a_M->NonInlinedSFcns.Sfcn2.UPtrs0;
          sfcnUPtrs[0] = hardware_model_2016a_B.LimitFlagSource;
          sfcnUPtrs[1] = &hardware_model_2016a_B.LimitFlagSource[1];
          sfcnUPtrs[2] = &hardware_model_2016a_B.LimitFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            hardware_model_2016a_B.LimitFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "LimitFlag");
      ssSetPath(rts, "hardware_model_2016a/Crane 3D/LimitFlag");
      ssSetRTModel(rts,hardware_model_2016a_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       hardware_model_2016a_P.LimitFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       hardware_model_2016a_P.LimitFlag_P2_Size);
      }

      /* registration */
      Crane3D_LimitFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: hardware_model_2016a/<S1>/SetLimit (Crane3D_SetLimit) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap = hardware_model_2016a_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &hardware_model_2016a_M->NonInlinedSFcns.blkInfo2
                         [3]);
      }

      ssSetRTWSfcnInfo(rts, hardware_model_2016a_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &hardware_model_2016a_M->NonInlinedSFcns.statesInfo2[3]);
        ssSetPeriodicStatesInfo(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.periodicStatesInfo[3]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn3.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &hardware_model_2016a_M->NonInlinedSFcns.Sfcn3.UPtrs0;
          sfcnUPtrs[0] = hardware_model_2016a_B.LimitSource;
          sfcnUPtrs[1] = &hardware_model_2016a_B.LimitSource[1];
          sfcnUPtrs[2] = &hardware_model_2016a_B.LimitSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn3.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            hardware_model_2016a_B.SetLimit));
        }
      }

      /* path info */
      ssSetModelName(rts, "SetLimit");
      ssSetPath(rts, "hardware_model_2016a/Crane 3D/SetLimit");
      ssSetRTModel(rts,hardware_model_2016a_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)hardware_model_2016a_P.SetLimit_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)hardware_model_2016a_P.SetLimit_P2_Size);
      }

      /* registration */
      Crane3D_SetLimit(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: hardware_model_2016a/<S1>/LimitSwitch (Crane3D_Switch) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap = hardware_model_2016a_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &hardware_model_2016a_M->NonInlinedSFcns.blkInfo2
                         [4]);
      }

      ssSetRTWSfcnInfo(rts, hardware_model_2016a_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods2[4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods3[4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &hardware_model_2016a_M->NonInlinedSFcns.statesInfo2[4]);
        ssSetPeriodicStatesInfo(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.periodicStatesInfo[4]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn4.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            hardware_model_2016a_B.LimitSwitch));
        }
      }

      /* path info */
      ssSetModelName(rts, "LimitSwitch");
      ssSetPath(rts, "hardware_model_2016a/Crane 3D/LimitSwitch");
      ssSetRTModel(rts,hardware_model_2016a_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       hardware_model_2016a_P.LimitSwitch_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       hardware_model_2016a_P.LimitSwitch_P2_Size);
      }

      /* registration */
      Crane3D_Switch(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: hardware_model_2016a/<S1>/PWMPrescaler (Crane3D_PWMPrescaler) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[5];

      /* timing info */
      time_T *sfcnPeriod =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn5.sfcnPeriod;
      time_T *sfcnOffset =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn5.sfcnOffset;
      int_T *sfcnTsMap = hardware_model_2016a_M->NonInlinedSFcns.Sfcn5.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &hardware_model_2016a_M->NonInlinedSFcns.blkInfo2
                         [5]);
      }

      ssSetRTWSfcnInfo(rts, hardware_model_2016a_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods2[5]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods3[5]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &hardware_model_2016a_M->NonInlinedSFcns.statesInfo2[5]);
        ssSetPeriodicStatesInfo(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.periodicStatesInfo[5]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn5.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &hardware_model_2016a_M->NonInlinedSFcns.Sfcn5.UPtrs0;
          sfcnUPtrs[0] = &hardware_model_2016a_B.PWMPrescalerSource;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn5.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &hardware_model_2016a_B.PWMPrescaler));
        }
      }

      /* path info */
      ssSetModelName(rts, "PWMPrescaler");
      ssSetPath(rts, "hardware_model_2016a/Crane 3D/PWMPrescaler");
      ssSetRTModel(rts,hardware_model_2016a_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn5.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       hardware_model_2016a_P.PWMPrescaler_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       hardware_model_2016a_P.PWMPrescaler_P2_Size);
      }

      /* registration */
      Crane3D_PWMPrescaler(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: hardware_model_2016a/<S1>/ResetEncoder (Crane3D_ResetEncoder) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[6];

      /* timing info */
      time_T *sfcnPeriod =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn6.sfcnPeriod;
      time_T *sfcnOffset =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn6.sfcnOffset;
      int_T *sfcnTsMap = hardware_model_2016a_M->NonInlinedSFcns.Sfcn6.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &hardware_model_2016a_M->NonInlinedSFcns.blkInfo2
                         [6]);
      }

      ssSetRTWSfcnInfo(rts, hardware_model_2016a_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods2[6]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods3[6]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &hardware_model_2016a_M->NonInlinedSFcns.statesInfo2[6]);
        ssSetPeriodicStatesInfo(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.periodicStatesInfo[6]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn6.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &hardware_model_2016a_M->NonInlinedSFcns.Sfcn6.UPtrs0;

          {
            int_T i1;
            const real_T *u0 = hardware_model_2016a_B.ResetSource;
            for (i1=0; i1 < 5; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }

          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 5);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn6.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            hardware_model_2016a_B.ResetEncoder));
        }
      }

      /* path info */
      ssSetModelName(rts, "ResetEncoder");
      ssSetPath(rts, "hardware_model_2016a/Crane 3D/ResetEncoder");
      ssSetRTModel(rts,hardware_model_2016a_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn6.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       hardware_model_2016a_P.ResetEncoder_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       hardware_model_2016a_P.ResetEncoder_P2_Size);
      }

      /* registration */
      Crane3D_ResetEncoder(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: hardware_model_2016a/<S1>/ResetSwitchFlag  (Crane3D_ResetSwitchFlag) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[7];

      /* timing info */
      time_T *sfcnPeriod =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn7.sfcnPeriod;
      time_T *sfcnOffset =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn7.sfcnOffset;
      int_T *sfcnTsMap = hardware_model_2016a_M->NonInlinedSFcns.Sfcn7.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &hardware_model_2016a_M->NonInlinedSFcns.blkInfo2
                         [7]);
      }

      ssSetRTWSfcnInfo(rts, hardware_model_2016a_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods2[7]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods3[7]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &hardware_model_2016a_M->NonInlinedSFcns.statesInfo2[7]);
        ssSetPeriodicStatesInfo(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.periodicStatesInfo[7]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn7.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &hardware_model_2016a_M->NonInlinedSFcns.Sfcn7.UPtrs0;
          sfcnUPtrs[0] = hardware_model_2016a_B.ResetSwitchFlagSource;
          sfcnUPtrs[1] = &hardware_model_2016a_B.ResetSwitchFlagSource[1];
          sfcnUPtrs[2] = &hardware_model_2016a_B.ResetSwitchFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn7.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            hardware_model_2016a_B.ResetSwitchFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "ResetSwitchFlag ");
      ssSetPath(rts, "hardware_model_2016a/Crane 3D/ResetSwitchFlag ");
      ssSetRTModel(rts,hardware_model_2016a_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn7.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       hardware_model_2016a_P.ResetSwitchFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       hardware_model_2016a_P.ResetSwitchFlag_P2_Size);
      }

      /* registration */
      Crane3D_ResetSwitchFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: hardware_model_2016a/<S1>/ThermFlag  (Crane3D_ThermFlag) */
    {
      SimStruct *rts = hardware_model_2016a_M->childSfunctions[8];

      /* timing info */
      time_T *sfcnPeriod =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn8.sfcnPeriod;
      time_T *sfcnOffset =
        hardware_model_2016a_M->NonInlinedSFcns.Sfcn8.sfcnOffset;
      int_T *sfcnTsMap = hardware_model_2016a_M->NonInlinedSFcns.Sfcn8.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &hardware_model_2016a_M->NonInlinedSFcns.blkInfo2
                         [8]);
      }

      ssSetRTWSfcnInfo(rts, hardware_model_2016a_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods2[8]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &hardware_model_2016a_M->NonInlinedSFcns.methods3[8]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &hardware_model_2016a_M->NonInlinedSFcns.statesInfo2[8]);
        ssSetPeriodicStatesInfo(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.periodicStatesInfo[8]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn8.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &hardware_model_2016a_M->NonInlinedSFcns.Sfcn8.UPtrs0;
          sfcnUPtrs[0] = hardware_model_2016a_B.ThermFlagSource;
          sfcnUPtrs[1] = &hardware_model_2016a_B.ThermFlagSource[1];
          sfcnUPtrs[2] = &hardware_model_2016a_B.ThermFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn8.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            hardware_model_2016a_B.ThermFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "ThermFlag ");
      ssSetPath(rts, "hardware_model_2016a/Crane 3D/ThermFlag ");
      ssSetRTModel(rts,hardware_model_2016a_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &hardware_model_2016a_M->NonInlinedSFcns.Sfcn8.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       hardware_model_2016a_P.ThermFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       hardware_model_2016a_P.ThermFlag_P2_Size);
      }

      /* registration */
      Crane3D_ThermFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }
  }

  /* Initialize Sizes */
  hardware_model_2016a_M->Sizes.numContStates = (2);/* Number of continuous states */
  hardware_model_2016a_M->Sizes.numPeriodicContStates = (0);/* Number of periodic continuous states */
  hardware_model_2016a_M->Sizes.numY = (10);/* Number of model outputs */
  hardware_model_2016a_M->Sizes.numU = (0);/* Number of model inputs */
  hardware_model_2016a_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  hardware_model_2016a_M->Sizes.numSampTimes = (2);/* Number of sample times */
  hardware_model_2016a_M->Sizes.numBlocks = (67);/* Number of blocks */
  hardware_model_2016a_M->Sizes.numBlockIO = (48);/* Number of block outputs */
  hardware_model_2016a_M->Sizes.numBlockPrms = (132);/* Sum of parameter "widths" */
  return hardware_model_2016a_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
