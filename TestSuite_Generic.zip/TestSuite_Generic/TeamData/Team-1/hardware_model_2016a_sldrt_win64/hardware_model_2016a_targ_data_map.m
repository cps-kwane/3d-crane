  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 3;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (hardware_model_2016a_P)
    ;%
      section.nData     = 66;
      section.data(66)  = dumData; %prealloc
      
	  ;% hardware_model_2016a_P.Saturation1_UpperSat
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% hardware_model_2016a_P.Saturation1_LowerSat
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% hardware_model_2016a_P.Saturation_UpperSat
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% hardware_model_2016a_P.Saturation_LowerSat
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% hardware_model_2016a_P.Encoder_P1_Size
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% hardware_model_2016a_P.Encoder_P1
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 6;
	
	  ;% hardware_model_2016a_P.Encoder_P2_Size
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 7;
	
	  ;% hardware_model_2016a_P.Encoder_P2
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 9;
	
	  ;% hardware_model_2016a_P.Encoder500PPR_Gain
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 10;
	
	  ;% hardware_model_2016a_P.XScale_Gain
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 11;
	
	  ;% hardware_model_2016a_P.UnitDelay_InitialCondition
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 12;
	
	  ;% hardware_model_2016a_P.YScale_Gain
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 17;
	
	  ;% hardware_model_2016a_P.ZScale_Gain
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 18;
	
	  ;% hardware_model_2016a_P.XAngleScale_Gain
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 19;
	
	  ;% hardware_model_2016a_P.YAngleScale_Gain
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 20;
	
	  ;% hardware_model_2016a_P.GainZ1_Gain
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 21;
	
	  ;% hardware_model_2016a_P.xwaypoints_Value
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 22;
	
	  ;% hardware_model_2016a_P.ywaypoints_Value
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 38;
	
	  ;% hardware_model_2016a_P.start_course_Value
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 54;
	
	  ;% hardware_model_2016a_P.total_waypoints_Value
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 55;
	
	  ;% hardware_model_2016a_P.time_Value
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 56;
	
	  ;% hardware_model_2016a_P.Integrator_IC
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 57;
	
	  ;% hardware_model_2016a_P.Integrator_IC_a
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 58;
	
	  ;% hardware_model_2016a_P.Constant2_Value
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 59;
	
	  ;% hardware_model_2016a_P.PWM_P1_Size
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 60;
	
	  ;% hardware_model_2016a_P.PWM_P1
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 62;
	
	  ;% hardware_model_2016a_P.PWM_P2_Size
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 63;
	
	  ;% hardware_model_2016a_P.PWM_P2
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 65;
	
	  ;% hardware_model_2016a_P.Switchx_Threshold
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 66;
	
	  ;% hardware_model_2016a_P.Switchy_Threshold
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 67;
	
	  ;% hardware_model_2016a_P.Saturation_UpperSat_j
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 68;
	
	  ;% hardware_model_2016a_P.Saturation_LowerSat_l
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 69;
	
	  ;% hardware_model_2016a_P.LimitFlag_P1_Size
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 70;
	
	  ;% hardware_model_2016a_P.LimitFlag_P1
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 72;
	
	  ;% hardware_model_2016a_P.LimitFlag_P2_Size
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 73;
	
	  ;% hardware_model_2016a_P.LimitFlag_P2
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 75;
	
	  ;% hardware_model_2016a_P.LimitFlagSource_Value
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 76;
	
	  ;% hardware_model_2016a_P.LimitSource_Value
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 79;
	
	  ;% hardware_model_2016a_P.SetLimit_P1_Size
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 82;
	
	  ;% hardware_model_2016a_P.SetLimit_P1
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 84;
	
	  ;% hardware_model_2016a_P.SetLimit_P2_Size
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 85;
	
	  ;% hardware_model_2016a_P.SetLimit_P2
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 87;
	
	  ;% hardware_model_2016a_P.LimitSwitch_P1_Size
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 88;
	
	  ;% hardware_model_2016a_P.LimitSwitch_P1
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 90;
	
	  ;% hardware_model_2016a_P.LimitSwitch_P2_Size
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 91;
	
	  ;% hardware_model_2016a_P.LimitSwitch_P2
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 93;
	
	  ;% hardware_model_2016a_P.PWMPrescaler_P1_Size
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 94;
	
	  ;% hardware_model_2016a_P.PWMPrescaler_P1
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 96;
	
	  ;% hardware_model_2016a_P.PWMPrescaler_P2_Size
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 97;
	
	  ;% hardware_model_2016a_P.PWMPrescaler_P2
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 99;
	
	  ;% hardware_model_2016a_P.PWMPrescalerSource_Value
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 100;
	
	  ;% hardware_model_2016a_P.ResetEncoder_P1_Size
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 101;
	
	  ;% hardware_model_2016a_P.ResetEncoder_P1
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 103;
	
	  ;% hardware_model_2016a_P.ResetEncoder_P2_Size
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 104;
	
	  ;% hardware_model_2016a_P.ResetEncoder_P2
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 106;
	
	  ;% hardware_model_2016a_P.ResetSource_Value
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 107;
	
	  ;% hardware_model_2016a_P.ResetSwitchFlag_P1_Size
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 112;
	
	  ;% hardware_model_2016a_P.ResetSwitchFlag_P1
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 114;
	
	  ;% hardware_model_2016a_P.ResetSwitchFlag_P2_Size
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 115;
	
	  ;% hardware_model_2016a_P.ResetSwitchFlag_P2
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 117;
	
	  ;% hardware_model_2016a_P.ResetSwitchFlagSource_Value
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 118;
	
	  ;% hardware_model_2016a_P.ThermFlag_P1_Size
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 121;
	
	  ;% hardware_model_2016a_P.ThermFlag_P1
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 123;
	
	  ;% hardware_model_2016a_P.ThermFlag_P2_Size
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 124;
	
	  ;% hardware_model_2016a_P.ThermFlag_P2
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 126;
	
	  ;% hardware_model_2016a_P.ThermFlagSource_Value
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 127;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hardware_model_2016a_P.Delay_DelayLength
	  section.data(1).logicalSrcIdx = 66;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(2) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hardware_model_2016a_P.Delay_InitialCondition
	  section.data(1).logicalSrcIdx = 67;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(3) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 2;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (hardware_model_2016a_B)
    ;%
      section.nData     = 47;
      section.data(47)  = dumData; %prealloc
      
	  ;% hardware_model_2016a_B.Encoder
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% hardware_model_2016a_B.XScale
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 5;
	
	  ;% hardware_model_2016a_B.YScale
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 6;
	
	  ;% hardware_model_2016a_B.ZScale
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 7;
	
	  ;% hardware_model_2016a_B.XAngleScale
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 8;
	
	  ;% hardware_model_2016a_B.YAngleScale
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 9;
	
	  ;% hardware_model_2016a_B.Derivatives
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 10;
	
	  ;% hardware_model_2016a_B.xwaypoints
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 15;
	
	  ;% hardware_model_2016a_B.ywaypoints
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 31;
	
	  ;% hardware_model_2016a_B.start_course
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 47;
	
	  ;% hardware_model_2016a_B.total_waypoints
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 48;
	
	  ;% hardware_model_2016a_B.time
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 49;
	
	  ;% hardware_model_2016a_B.Product
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 50;
	
	  ;% hardware_model_2016a_B.POut
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 51;
	
	  ;% hardware_model_2016a_B.Add
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 52;
	
	  ;% hardware_model_2016a_B.Product1
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 53;
	
	  ;% hardware_model_2016a_B.POut_e
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 54;
	
	  ;% hardware_model_2016a_B.Add3
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 55;
	
	  ;% hardware_model_2016a_B.TmpSignalConversionAtToWorkspace1Inport1
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 56;
	
	  ;% hardware_model_2016a_B.PWM
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 64;
	
	  ;% hardware_model_2016a_B.Saturation
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 67;
	
	  ;% hardware_model_2016a_B.LimitFlag
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 70;
	
	  ;% hardware_model_2016a_B.LimitFlagSource
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 73;
	
	  ;% hardware_model_2016a_B.LimitSource
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 76;
	
	  ;% hardware_model_2016a_B.SetLimit
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 79;
	
	  ;% hardware_model_2016a_B.LimitSwitch
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 82;
	
	  ;% hardware_model_2016a_B.PWMPrescaler
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 85;
	
	  ;% hardware_model_2016a_B.PWMPrescalerSource
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 86;
	
	  ;% hardware_model_2016a_B.ResetEncoder
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 87;
	
	  ;% hardware_model_2016a_B.ResetSource
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 92;
	
	  ;% hardware_model_2016a_B.ResetSwitchFlag
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 97;
	
	  ;% hardware_model_2016a_B.ResetSwitchFlagSource
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 100;
	
	  ;% hardware_model_2016a_B.ThermFlag
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 103;
	
	  ;% hardware_model_2016a_B.ThermFlagSource
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 106;
	
	  ;% hardware_model_2016a_B.IOut
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 109;
	
	  ;% hardware_model_2016a_B.IOut_a
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 110;
	
	  ;% hardware_model_2016a_B.kpax
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 111;
	
	  ;% hardware_model_2016a_B.xref
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 112;
	
	  ;% hardware_model_2016a_B.kpx
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 113;
	
	  ;% hardware_model_2016a_B.kix
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 114;
	
	  ;% hardware_model_2016a_B.Kpy
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 115;
	
	  ;% hardware_model_2016a_B.Kiy
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 116;
	
	  ;% hardware_model_2016a_B.SWX
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 117;
	
	  ;% hardware_model_2016a_B.SWY
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 118;
	
	  ;% hardware_model_2016a_B.yref
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 119;
	
	  ;% hardware_model_2016a_B.Kpay
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 120;
	
	  ;% hardware_model_2016a_B.waypoints_reached
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 121;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hardware_model_2016a_B.done
	  section.data(1).logicalSrcIdx = 47;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 6;
    sectIdxOffset = 2;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (hardware_model_2016a_DW)
    ;%
      section.nData     = 16;
      section.data(16)  = dumData; %prealloc
      
	  ;% hardware_model_2016a_DW.UnitDelay_DSTATE
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% hardware_model_2016a_DW.finished
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 5;
	
	  ;% hardware_model_2016a_DW.xlocal
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 6;
	
	  ;% hardware_model_2016a_DW.ylocal
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 7;
	
	  ;% hardware_model_2016a_DW.Ki_l
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 8;
	
	  ;% hardware_model_2016a_DW.Kpx_l
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 9;
	
	  ;% hardware_model_2016a_DW.Kpa_l
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 10;
	
	  ;% hardware_model_2016a_DW.index
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 11;
	
	  ;% hardware_model_2016a_DW.Kp_l
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 12;
	
	  ;% hardware_model_2016a_DW.Kpax_l
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 13;
	
	  ;% hardware_model_2016a_DW.Kix_l
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 14;
	
	  ;% hardware_model_2016a_DW.arrived
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 15;
	
	  ;% hardware_model_2016a_DW.waypoints_reached_l
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 16;
	
	  ;% hardware_model_2016a_DW.swx_l
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 17;
	
	  ;% hardware_model_2016a_DW.swy_l
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 18;
	
	  ;% hardware_model_2016a_DW.sustained
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 19;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 9;
      section.data(9)  = dumData; %prealloc
      
	  ;% hardware_model_2016a_DW.Scope_PWORK.LoggedData
	  section.data(1).logicalSrcIdx = 16;
	  section.data(1).dtTransOffset = 0;
	
	  ;% hardware_model_2016a_DW.Scope1_PWORK.LoggedData
	  section.data(2).logicalSrcIdx = 17;
	  section.data(2).dtTransOffset = 3;
	
	  ;% hardware_model_2016a_DW.Scope2_PWORK.LoggedData
	  section.data(3).logicalSrcIdx = 18;
	  section.data(3).dtTransOffset = 6;
	
	  ;% hardware_model_2016a_DW.Scope3_PWORK.LoggedData
	  section.data(4).logicalSrcIdx = 19;
	  section.data(4).dtTransOffset = 7;
	
	  ;% hardware_model_2016a_DW.ToWorkspace1_PWORK.LoggedData
	  section.data(5).logicalSrcIdx = 20;
	  section.data(5).dtTransOffset = 8;
	
	  ;% hardware_model_2016a_DW.anglex_PWORK.LoggedData
	  section.data(6).logicalSrcIdx = 21;
	  section.data(6).dtTransOffset = 9;
	
	  ;% hardware_model_2016a_DW.angley_PWORK.LoggedData
	  section.data(7).logicalSrcIdx = 22;
	  section.data(7).dtTransOffset = 10;
	
	  ;% hardware_model_2016a_DW.xpos_PWORK.LoggedData
	  section.data(8).logicalSrcIdx = 23;
	  section.data(8).dtTransOffset = 11;
	
	  ;% hardware_model_2016a_DW.ypos_PWORK.LoggedData
	  section.data(9).logicalSrcIdx = 24;
	  section.data(9).dtTransOffset = 12;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hardware_model_2016a_DW.sfEvent
	  section.data(1).logicalSrcIdx = 25;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hardware_model_2016a_DW.temporalCounter_i1
	  section.data(1).logicalSrcIdx = 26;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% hardware_model_2016a_DW.Delay_DSTATE
	  section.data(1).logicalSrcIdx = 27;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(5) = section;
      clear section
      
      section.nData     = 5;
      section.data(5)  = dumData; %prealloc
      
	  ;% hardware_model_2016a_DW.is_active_c3_hardware_model_2016a
	  section.data(1).logicalSrcIdx = 28;
	  section.data(1).dtTransOffset = 0;
	
	  ;% hardware_model_2016a_DW.is_c3_hardware_model_2016a
	  section.data(2).logicalSrcIdx = 29;
	  section.data(2).dtTransOffset = 1;
	
	  ;% hardware_model_2016a_DW.is_active_S1_setpoints1
	  section.data(3).logicalSrcIdx = 30;
	  section.data(3).dtTransOffset = 2;
	
	  ;% hardware_model_2016a_DW.is_active_S1_setup_pidy1
	  section.data(4).logicalSrcIdx = 31;
	  section.data(4).dtTransOffset = 3;
	
	  ;% hardware_model_2016a_DW.is_active_S1_setup_pidy
	  section.data(5).logicalSrcIdx = 32;
	  section.data(5).dtTransOffset = 4;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(6) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 3949888350;
  targMap.checksum1 = 3624964771;
  targMap.checksum2 = 2767170567;
  targMap.checksum3 = 2419688372;

