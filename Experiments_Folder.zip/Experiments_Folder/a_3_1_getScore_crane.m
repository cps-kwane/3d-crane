%% Plotting Function Parameters
showPlot='on';

%% Get List of Obstacles & Targets
[obstacles,targets]=getCourseFromCSV(filename);
[score, tarN, obsN, payloadX, payloadY, alphaX, alphaY] = ...
    getScore_crane(obstacles, targets,xpos,ypos,anglex,angley,xwaypoints,ywaypoints,course, showPlot)