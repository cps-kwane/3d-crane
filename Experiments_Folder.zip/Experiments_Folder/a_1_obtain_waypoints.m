%% Set this to 1 for random course generation
generate_random_course=1;
course=1;
flag=0;

%% Python Must be included in path when running at Imperial
% pyversion 'O:\\python.exe';


%% Generate Random Course or specify fixed csv input
% Random
if(generate_random_course==1)
flag=py.create_csv_course.produce_fn();
course=0;
while(flag~=2)
flag=flag
end
filename='course_.csv';
else
% Custom Course
%filename='my_course.csv';
filename=strcat('courses/my_course',int2str(course),'.csv'); 
end

%% Solve Course
waypoints_list= py.solve_course_csv.find_result(filename);


% %% Alternatively manually set:
% targets=[3,3;3,47;7,47;47,47];
% obstacles=[];
% 
% %% Generate Path
% xwaypoints=targets(:,1)/100;
% ywaypoints=targets(:,2)/100;