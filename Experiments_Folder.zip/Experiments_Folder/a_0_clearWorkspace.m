%%% Given Setup Script
clear variables
close all
clc