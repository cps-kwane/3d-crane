/*
 * kwane_DevDriv.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "kwane_DevDriv".
 *
 * Model version              : 1.123
 * Simulink Coder version : 8.10 (R2016a) 10-Feb-2016
 * C source code generated on : Mon Dec 18 10:28:23 2017
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "kwane_DevDriv.h"
#include "kwane_DevDriv_private.h"
#include "kwane_DevDriv_dt.h"

/* Named constants for Chart: '<Root>/Controller' */
#define kwane_DevDriv_CALL_EVENT       (-1)
#define kwane_DevDriv_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define kwane_DevDriv_IN_S0_IDLE       ((uint8_T)1U)
#define kwane_DevDriv_IN_S1_Initialize ((uint8_T)2U)
#define kwane_DevDriv_IN_S2_Move_to_waypoint ((uint8_T)3U)
#define kwane_DevDriv_IN_S3_log_stats_delay ((uint8_T)4U)
#define kwane_DevDriv_IN_S4_checkifdone ((uint8_T)5U)
#define kwane_DevDriv_IN_S5_done       ((uint8_T)6U)

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.01, 0.0,
};

/* Block signals (auto storage) */
B_kwane_DevDriv_T kwane_DevDriv_B;

/* Continuous states */
X_kwane_DevDriv_T kwane_DevDriv_X;

/* Block states (auto storage) */
DW_kwane_DevDriv_T kwane_DevDriv_DW;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_kwane_DevDriv_T kwane_DevDriv_Y;

/* Real-time model */
RT_MODEL_kwane_DevDriv_T kwane_DevDriv_M_;
RT_MODEL_kwane_DevDriv_T *const kwane_DevDriv_M = &kwane_DevDriv_M_;

/* Forward declaration for local functions */
static void kwane_DevDriv_setpidy(real_T ycurrent, real_T ydest, real_T *Ki,
  real_T *Kpa, real_T *Kp, real_T *tsy);
static void kwane_DevDriv_func1_setpidy(real_T ycurrent, real_T ydest);
static void kwane_DevDriv_setpidx(real_T xcurrent, real_T xdest, real_T *Kix,
  real_T *Kpax, real_T *Kpx, real_T *tsx);
static void kwane_DevDriv_func1_setpidx(real_T xcurrent, real_T xdest);
static void kwane_DevDriv_func2_CheckArrival(real_T currentx, real_T currenty,
  real_T xdest, real_T ydest);
static void kwane_DevDriv_func3_CheckDone(real_T count, real_T total);

/*
 * This function updates continuous states using the ODE5 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE5_A[6] = {
    1.0/5.0, 3.0/10.0, 4.0/5.0, 8.0/9.0, 1.0, 1.0
  };

  static const real_T rt_ODE5_B[6][6] = {
    { 1.0/5.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 3.0/40.0, 9.0/40.0, 0.0, 0.0, 0.0, 0.0 },

    { 44.0/45.0, -56.0/15.0, 32.0/9.0, 0.0, 0.0, 0.0 },

    { 19372.0/6561.0, -25360.0/2187.0, 64448.0/6561.0, -212.0/729.0, 0.0, 0.0 },

    { 9017.0/3168.0, -355.0/33.0, 46732.0/5247.0, 49.0/176.0, -5103.0/18656.0,
      0.0 },

    { 35.0/384.0, 0.0, 500.0/1113.0, 125.0/192.0, -2187.0/6784.0, 11.0/84.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE5_IntgData *id = (ODE5_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T *f4 = id->f[4];
  real_T *f5 = id->f[5];
  real_T hB[6];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  kwane_DevDriv_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE5_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[0]);
  rtsiSetdX(si, f1);
  kwane_DevDriv_output();
  kwane_DevDriv_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE5_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[1]);
  rtsiSetdX(si, f2);
  kwane_DevDriv_output();
  kwane_DevDriv_derivatives();

  /* f(:,4) = feval(odefile, t + hA(3), y + f*hB(:,3), args(:)(*)); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE5_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[2]);
  rtsiSetdX(si, f3);
  kwane_DevDriv_output();
  kwane_DevDriv_derivatives();

  /* f(:,5) = feval(odefile, t + hA(4), y + f*hB(:,4), args(:)(*)); */
  for (i = 0; i <= 3; i++) {
    hB[i] = h * rt_ODE5_B[3][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[3]);
  rtsiSetdX(si, f4);
  kwane_DevDriv_output();
  kwane_DevDriv_derivatives();

  /* f(:,6) = feval(odefile, t + hA(5), y + f*hB(:,5), args(:)(*)); */
  for (i = 0; i <= 4; i++) {
    hB[i] = h * rt_ODE5_B[4][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f5);
  kwane_DevDriv_output();
  kwane_DevDriv_derivatives();

  /* tnew = t + hA(6);
     ynew = y + f*hB(:,6); */
  for (i = 0; i <= 5; i++) {
    hB[i] = h * rt_ODE5_B[5][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4] + f5[i]*hB[5]);
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/* Function for Chart: '<Root>/Controller' */
static void kwane_DevDriv_setpidy(real_T ycurrent, real_T ydest, real_T *Ki,
  real_T *Kpa, real_T *Kp, real_T *tsy)
{
  real_T temp;

  /* MATLAB Function 'setpidy': '<S1>:29' */
  /* '<S1>:29:2' */
  /* '<S1>:29:3' */
  temp = rt_roundd_snf(fabs(ycurrent - ydest) * 100.0);
  if (temp == 0.0) {
    /* '<S1>:29:4' */
    /* '<S1>:29:5' */
    *Ki = 0.0;

    /* '<S1>:29:6' */
    *Kpa = 0.0;

    /* '<S1>:29:7' */
    *Kp = 0.0;

    /* '<S1>:29:8' */
    *tsy = 0.0;
  } else if (temp == 1.0) {
    /* '<S1>:29:9' */
    /* '<S1>:29:10' */
    *Ki = 0.0;

    /* '<S1>:29:11' */
    *Kpa = 21.4621;

    /* '<S1>:29:12' */
    *Kp = 23.7;

    /* '<S1>:29:13' */
    *tsy = 3.0;
  } else if (temp == 2.0) {
    /* '<S1>:29:14' */
    /* '<S1>:29:15' */
    *Ki = 0.0;

    /* '<S1>:29:16' */
    *Kpa = 18.7134;

    /* '<S1>:29:17' */
    *Kp = 12.8789;

    /* '<S1>:29:18' */
    *tsy = 3.0;
  } else if (temp == 3.0) {
    /* '<S1>:29:19' */
    /* '<S1>:29:20' */
    *Ki = 0.0;

    /* '<S1>:29:21' */
    *Kpa = 19.2515;

    /* '<S1>:29:22' */
    *Kp = 8.8615;

    /* '<S1>:29:23' */
    *tsy = 3.0;
  } else if (temp == 4.0) {
    /* '<S1>:29:24' */
    /* '<S1>:29:25' */
    *Ki = 0.0;

    /* '<S1>:29:26' */
    *Kpa = 19.815;

    /* '<S1>:29:27' */
    *Kp = 7.0;

    /* '<S1>:29:28' */
    *tsy = 3.0;
  } else if (temp <= 7.0) {
    /* '<S1>:29:29' */
    /* '<S1>:29:30' */
    *Ki = 0.0;

    /* '<S1>:29:31' */
    *Kpa = 30.0;

    /* '<S1>:29:32' */
    *Kp = 4.921;

    /* '<S1>:29:33' */
    *tsy = 4.5;
  } else if (temp <= 10.0) {
    /* '<S1>:29:34' */
    /* '<S1>:29:35' */
    *Ki = 0.0789;

    /* '<S1>:29:36' */
    *Kpa = 22.9519;

    /* '<S1>:29:37' */
    *Kp = 3.6548;

    /* '<S1>:29:38' */
    *tsy = 4.5;
  } else if (temp <= 15.0) {
    /* '<S1>:29:39' */
    /* '<S1>:29:40' */
    *Ki = 0.0694;

    /* '<S1>:29:41' */
    *Kpa = 19.6705;

    /* '<S1>:29:42' */
    *Kp = 3.005;

    /* '<S1>:29:43' */
    *tsy = 5.5;
  } else if (temp <= 20.0) {
    /* '<S1>:29:44' */
    /* '<S1>:29:45' */
    *Ki = 0.0723;

    /* '<S1>:29:46' */
    *Kpa = 19.8372;

    /* '<S1>:29:47' */
    *Kp = 2.2143;

    /* '<S1>:29:48' */
    *tsy = 5.5;
  } else if (temp <= 25.0) {
    /* '<S1>:29:49' */
    /* '<S1>:29:50' */
    *Ki = 0.031;

    /* '<S1>:29:51' */
    *Kpa = 22.8874;

    /* '<S1>:29:52' */
    *Kp = 1.9582;

    /* '<S1>:29:53' */
    *tsy = 5.5;
  } else if (temp <= 30.0) {
    /* '<S1>:29:54' */
    /* '<S1>:29:55' */
    *Ki = 0.1018;

    /* '<S1>:29:56' */
    *Kpa = 16.9781;

    /* '<S1>:29:57' */
    *Kp = 1.538;

    /* '<S1>:29:58' */
    *tsy = 5.5;
  } else if (temp <= 35.0) {
    /* '<S1>:29:59' */
    /* '<S1>:29:60' */
    *Ki = 0.1017;

    /* '<S1>:29:61' */
    *Kpa = 15.6134;

    /* '<S1>:29:62' */
    *Kp = 1.3479;

    /* '<S1>:29:63' */
    *tsy = 6.0;
  } else if (temp <= 40.0) {
    /* '<S1>:29:64' */
    /* '<S1>:29:65' */
    *Ki = 0.097;

    /* '<S1>:29:66' */
    *Kpa = 13.6476;

    /* '<S1>:29:67' */
    *Kp = 1.1919;

    /* '<S1>:29:68' */
    *tsy = 6.0;
  } else if (temp <= 45.0) {
    /* '<S1>:29:69' */
    /* '<S1>:29:70' */
    *Ki = 0.0553;

    /* '<S1>:29:71' */
    *Kpa = 20.0;

    /* '<S1>:29:72' */
    *Kp = 1.2126;

    /* '<S1>:29:73' */
    *tsy = 6.0;
  } else if (temp <= 47.0) {
    /* '<S1>:29:74' */
    /* '<S1>:29:75' */
    *Ki = 0.0526;

    /* '<S1>:29:76' */
    *Kpa = 19.8667;

    /* '<S1>:29:77' */
    *Kp = 1.1418;

    /* '<S1>:29:78' */
    *tsy = 6.0;
  } else {
    /* '<S1>:29:80' */
    *Ki = 0.0;

    /* '<S1>:29:81' */
    *Kpa = 0.0;

    /* '<S1>:29:82' */
    *Kp = 0.0;

    /* '<S1>:29:83' */
    *tsy = 0.0;
  }
}

/* Function for Chart: '<Root>/Controller' */
static void kwane_DevDriv_func1_setpidy(real_T ycurrent, real_T ydest)
{
  real_T Ki_l;
  real_T Kpa_l;
  real_T Kp_l;
  real_T tsy_l;

  /* MATLAB Function 'func1_setpidy': '<S1>:22' */
  /* Graphical Function 'func1_setpidy': '<S1>:22' */
  /* '<S1>:36:1' */
  kwane_DevDriv_setpidy(ycurrent, ydest, &Ki_l, &Kpa_l, &Kp_l, &tsy_l);

  /* '<S1>:36:1' */
  kwane_DevDriv_DW.Ki_l = Ki_l;

  /* '<S1>:36:1' */
  kwane_DevDriv_DW.Kpa_l = Kpa_l;

  /* '<S1>:36:1' */
  kwane_DevDriv_DW.Kp_l = Kp_l;

  /* '<S1>:36:1' */
  kwane_DevDriv_DW.tsy_l = tsy_l;
}

/* Function for Chart: '<Root>/Controller' */
static void kwane_DevDriv_setpidx(real_T xcurrent, real_T xdest, real_T *Kix,
  real_T *Kpax, real_T *Kpx, real_T *tsx)
{
  real_T temp;

  /* MATLAB Function 'setpidx': '<S1>:46' */
  /* '<S1>:46:2' */
  /* '<S1>:46:3' */
  temp = rt_roundd_snf(fabs(xcurrent - xdest) * 100.0);
  if (temp == 0.0) {
    /* '<S1>:46:4' */
    /* '<S1>:46:5' */
    *Kix = 0.0;

    /* '<S1>:46:6' */
    *Kpax = 0.0;

    /* '<S1>:46:7' */
    *Kpx = 0.0;

    /* '<S1>:46:8' */
    *tsx = 0.0;
  } else if (temp == 1.0) {
    /* '<S1>:46:9' */
    /* '<S1>:46:10' */
    *Kix = 0.0;

    /* '<S1>:46:11' */
    *Kpax = 35.913;

    /* '<S1>:46:12' */
    *Kpx = 29.9661;

    /* '<S1>:46:13' */
    *tsx = 3.0;
  } else if (temp == 2.0) {
    /* '<S1>:46:14' */
    /* '<S1>:46:15' */
    *Kix = 0.0;

    /* '<S1>:46:16' */
    *Kpax = 31.4919;

    /* '<S1>:46:17' */
    *Kpx = 16.0003;

    /* '<S1>:46:18' */
    *tsx = 3.0;
  } else if (temp == 3.0) {
    /* '<S1>:46:19' */
    /* '<S1>:46:20' */
    *Kix = 0.0;

    /* '<S1>:46:21' */
    *Kpax = 28.7753;

    /* '<S1>:46:22' */
    *Kpx = 10.9142;

    /* '<S1>:46:23' */
    *tsx = 3.0;
  } else if (temp == 4.0) {
    /* '<S1>:46:24' */
    /* '<S1>:46:25' */
    *Kix = 0.0;

    /* '<S1>:46:26' */
    *Kpax = 27.0726;

    /* '<S1>:46:27' */
    *Kpx = 8.2798;

    /* '<S1>:46:28' */
    *tsx = 3.0;
  } else if (temp <= 7.0) {
    /* '<S1>:46:29' */
    /* '<S1>:46:30' */
    *Kix = 0.0;

    /* '<S1>:46:31' */
    *Kpax = 28.8807;

    /* '<S1>:46:32' */
    *Kpx = 6.8;

    /* '<S1>:46:33' */
    *tsx = 4.5;
  } else if (temp <= 10.0) {
    /* '<S1>:46:34' */
    /* '<S1>:46:35' */
    *Kix = -0.1337;

    /* '<S1>:46:36' */
    *Kpax = 29.9504;

    /* '<S1>:46:37' */
    *Kpx = 5.1631;

    /* '<S1>:46:38' */
    *tsx = 4.5;
  } else if (temp <= 15.0) {
    /* '<S1>:46:39' */
    /* '<S1>:46:40' */
    *Kix = -0.1312;

    /* '<S1>:46:41' */
    *Kpax = 29.7874;

    /* '<S1>:46:42' */
    *Kpx = 3.8515;

    /* '<S1>:46:43' */
    *tsx = 5.5;
  } else if (temp <= 20.0) {
    /* '<S1>:46:44' */
    /* '<S1>:46:45' */
    *Kix = -0.1315;

    /* '<S1>:46:46' */
    *Kpax = 29.7281;

    /* '<S1>:46:47' */
    *Kpx = 3.2651;

    /* '<S1>:46:48' */
    *tsx = 5.5;
  } else if (temp <= 25.0) {
    /* '<S1>:46:49' */
    /* '<S1>:46:50' */
    *Kix = -0.0549;

    /* '<S1>:46:51' */
    *Kpax = 35.0;

    /* '<S1>:46:52' */
    *Kpx = 2.49;

    /* '<S1>:46:53' */
    *tsx = 5.5;
  } else if (temp <= 30.0) {
    /* '<S1>:46:54' */
    /* '<S1>:46:55' */
    *Kix = -0.0757;

    /* '<S1>:46:56' */
    *Kpax = 40.0;

    /* '<S1>:46:57' */
    *Kpx = 2.24;

    /* '<S1>:46:58' */
    *tsx = 5.5;
  } else if (temp <= 35.0) {
    /* '<S1>:46:59' */
    /* '<S1>:46:60' */
    *Kix = -0.0613;

    /* '<S1>:46:61' */
    *Kpax = 41.2866;

    /* '<S1>:46:62' */
    *Kpx = 2.0264;

    /* '<S1>:46:63' */
    *tsx = 6.0;
  } else if (temp <= 40.0) {
    /* '<S1>:46:64' */
    /* '<S1>:46:65' */
    *Kix = -0.0536;

    /* '<S1>:46:66' */
    *Kpax = 42.2712;

    /* '<S1>:46:67' */
    *Kpx = 1.8435;

    /* '<S1>:46:68' */
    *tsx = 6.0;
  } else if (temp <= 45.0) {
    /* '<S1>:46:69' */
    /* '<S1>:46:70' */
    *Kix = -0.0026;

    /* '<S1>:46:71' */
    *Kpax = 35.2599;

    /* '<S1>:46:72' */
    *Kpx = 1.5553;

    /* '<S1>:46:73' */
    *tsx = 6.0;
  } else if (temp <= 47.0) {
    /* '<S1>:46:74' */
    /* '<S1>:46:75' */
    *Kix = -0.001;

    /* '<S1>:46:76' */
    *Kpax = 35.2696;

    /* '<S1>:46:77' */
    *Kpx = 1.4588;

    /* '<S1>:46:78' */
    *tsx = 6.0;
  } else {
    /* '<S1>:46:80' */
    *Kix = 0.0;

    /* '<S1>:46:81' */
    *Kpax = 0.0;

    /* '<S1>:46:82' */
    *Kpx = 0.0;

    /* '<S1>:46:83' */
    *tsx = 0.0;
  }
}

/* Function for Chart: '<Root>/Controller' */
static void kwane_DevDriv_func1_setpidx(real_T xcurrent, real_T xdest)
{
  real_T Kix_l;
  real_T Kpax_l;
  real_T Kpx_l;
  real_T tsx_l;

  /* MATLAB Function 'func1_setpidx': '<S1>:39' */
  /* Graphical Function 'func1_setpidx': '<S1>:39' */
  /* '<S1>:16:1' */
  kwane_DevDriv_setpidx(xcurrent, xdest, &Kix_l, &Kpax_l, &Kpx_l, &tsx_l);

  /* '<S1>:16:1' */
  kwane_DevDriv_DW.Kix_l = Kix_l;

  /* '<S1>:16:1' */
  kwane_DevDriv_DW.Kpax_l = Kpax_l;

  /* '<S1>:16:1' */
  kwane_DevDriv_DW.Kpx_l = Kpx_l;

  /* '<S1>:16:1' */
  kwane_DevDriv_DW.tsx_l = tsx_l;
}

/* Function for Chart: '<Root>/Controller' */
static void kwane_DevDriv_func2_CheckArrival(real_T currentx, real_T currenty,
  real_T xdest, real_T ydest)
{
  boolean_T sf_internal_predicateOutput;

  /* MATLAB Function 'func2_CheckArrival': '<S1>:34' */
  /* Graphical Function 'func2_CheckArrival': '<S1>:34' */
  /*  checks for steady state */
  if ((fabs(xdest - currentx) <= 0.01) && (fabs(ydest - currenty) <= 0.01)) {
    /* '<S1>:65:1' */
    sf_internal_predicateOutput = true;
  } else {
    /* '<S1>:65:1' */
    sf_internal_predicateOutput = false;
  }

  if (sf_internal_predicateOutput) {
    /* '<S1>:65:1' */
    /* '<S1>:47:1' */
    kwane_DevDriv_DW.arrived = 1.0;
  } else {
    /* '<S1>:67:1' */
    kwane_DevDriv_DW.arrived = 0.0;
  }
}

/* Function for Chart: '<Root>/Controller' */
static void kwane_DevDriv_func3_CheckDone(real_T count, real_T total)
{
  /* MATLAB Function 'func3_CheckDone': '<S1>:56' */
  /* Graphical Function 'func3_CheckDone': '<S1>:56' */
  /* '<S1>:57:1' */
  if (count > total) {
    /* '<S1>:62:1' */
    kwane_DevDriv_DW.finished = 1.0;
  } else {
    /* '<S1>:58:1' */
    kwane_DevDriv_DW.finished = 0.0;
  }
}

/* Model output function */
void kwane_DevDriv_output(void)
{
  real_T rtb_Encoder500PPR[5];
  real_T rtb_Add1;
  real_T rtb_Add2;
  int32_T i;
  real_T u0;
  if (rtmIsMajorTimeStep(kwane_DevDriv_M)) {
    /* set solver stop time */
    if (!(kwane_DevDriv_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&kwane_DevDriv_M->solverInfo,
                            ((kwane_DevDriv_M->Timing.clockTickH0 + 1) *
        kwane_DevDriv_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&kwane_DevDriv_M->solverInfo,
                            ((kwane_DevDriv_M->Timing.clockTick0 + 1) *
        kwane_DevDriv_M->Timing.stepSize0 + kwane_DevDriv_M->Timing.clockTickH0 *
        kwane_DevDriv_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(kwane_DevDriv_M)) {
    kwane_DevDriv_M->Timing.t[0] = rtsiGetT(&kwane_DevDriv_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(kwane_DevDriv_M)) {
    /* Level2 S-Function Block: '<S2>/Encoder' (Crane3D_Encoder) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[0];
      sfcnOutputs(rts, 1);
    }

    /* Gain: '<S2>/Encoder 500PPR' */
    for (i = 0; i < 5; i++) {
      rtb_Encoder500PPR[i] = kwane_DevDriv_P.Encoder500PPR_Gain *
        kwane_DevDriv_B.Encoder[i];
    }

    /* End of Gain: '<S2>/Encoder 500PPR' */

    /* Gain: '<S2>/X Scale' */
    kwane_DevDriv_B.XScale = kwane_DevDriv_P.XScale_Gain * rtb_Encoder500PPR[0];
    for (i = 0; i < 6; i++) {
      /* Constant: '<Root>/xwaypoints' */
      kwane_DevDriv_B.xwaypoints[i] = kwane_DevDriv_P.xwaypoints[i];

      /* Constant: '<Root>/ywaypoints ' */
      kwane_DevDriv_B.ywaypoints[i] = kwane_DevDriv_P.ywaypoints[i];
    }

    /* Constant: '<Root>/start_course' */
    kwane_DevDriv_B.start_course = kwane_DevDriv_P.start_course;

    /* Constant: '<Root>/total_waypoints ' */
    kwane_DevDriv_B.total_waypoints = kwane_DevDriv_P.total_waypoints;

    /* Gain: '<S2>/Y Scale' */
    kwane_DevDriv_B.YScale = kwane_DevDriv_P.YScale_Gain * rtb_Encoder500PPR[1];

    /* Chart: '<Root>/Controller' */
    if (kwane_DevDriv_DW.temporalCounter_i1 < MAX_uint32_T) {
      kwane_DevDriv_DW.temporalCounter_i1++;
    }

    /* Gateway: Controller */
    kwane_DevDriv_DW.sfEvent = kwane_DevDriv_CALL_EVENT;

    /* During: Controller */
    if (kwane_DevDriv_DW.is_active_c1_kwane_DevDriv == 0U) {
      /* Entry: Controller */
      kwane_DevDriv_DW.is_active_c1_kwane_DevDriv = 1U;

      /* Entry Internal: Controller */
      /* Transition: '<S1>:6' */
      kwane_DevDriv_DW.is_c1_kwane_DevDriv = kwane_DevDriv_IN_S0_IDLE;

      /* Entry 'S0_IDLE': '<S1>:5' */
      kwane_DevDriv_DW.xlocal = 0.0;
      kwane_DevDriv_DW.ylocal = 0.0;
      kwane_DevDriv_B.done = false;
      kwane_DevDriv_DW.index = 1.0;
      kwane_DevDriv_DW.Kp_l = 0.0;
      kwane_DevDriv_DW.Ki_l = 0.0;
      kwane_DevDriv_DW.Kpa_l = 0.0;
      kwane_DevDriv_DW.Kix_l = 0.0;
      kwane_DevDriv_DW.Kpx_l = 0.0;
      kwane_DevDriv_DW.Kpax_l = 0.0;
      kwane_DevDriv_DW.tsy_l = 0.0;
      kwane_DevDriv_DW.tsx_l = 0.0;
      kwane_DevDriv_DW.waypoints_reached_l = 0.0;
      kwane_DevDriv_DW.ts = 0.0;
    } else {
      switch (kwane_DevDriv_DW.is_c1_kwane_DevDriv) {
       case kwane_DevDriv_IN_S0_IDLE:
        /* During 'S0_IDLE': '<S1>:5' */
        if (kwane_DevDriv_B.start_course == 1.0) {
          /* Transition: '<S1>:8' */
          kwane_DevDriv_DW.is_c1_kwane_DevDriv = kwane_DevDriv_IN_S1_Initialize;

          /* Entry Internal 'S1_Initialize': '<S1>:7' */
          kwane_DevDriv_DW.is_active_S1_setpoints1 = 1U;

          /* Entry 'S1_setpoints1': '<S1>:12' */
          kwane_DevDriv_DW.xlocal = kwane_DevDriv_B.xwaypoints[(int32_T)
            kwane_DevDriv_DW.index - 1];
          kwane_DevDriv_DW.ylocal = kwane_DevDriv_B.ywaypoints[(int32_T)
            kwane_DevDriv_DW.index - 1];
          kwane_DevDriv_DW.arrived = 0.0;
          kwane_DevDriv_DW.is_active_S1_setup_pidy1 = 1U;

          /* Entry 'S1_setup_pidy1': '<S1>:11' */
          kwane_DevDriv_func1_setpidy(kwane_DevDriv_B.YScale,
            kwane_DevDriv_B.ywaypoints[(int32_T)kwane_DevDriv_DW.index - 1]);
          kwane_DevDriv_DW.is_active_S1_setup_pidy = 1U;

          /* Entry 'S1_setup_pidy': '<S1>:13' */
          kwane_DevDriv_func1_setpidx(kwane_DevDriv_B.XScale,
            kwane_DevDriv_B.xwaypoints[(int32_T)kwane_DevDriv_DW.index - 1]);
        }
        break;

       case kwane_DevDriv_IN_S1_Initialize:
        /* During 'S1_Initialize': '<S1>:7' */
        /* Transition: '<S1>:79' */
        /* Exit Internal 'S1_Initialize': '<S1>:7' */
        kwane_DevDriv_DW.is_active_S1_setup_pidy = 0U;
        kwane_DevDriv_DW.is_active_S1_setup_pidy1 = 0U;
        kwane_DevDriv_DW.is_active_S1_setpoints1 = 0U;
        kwane_DevDriv_DW.is_c1_kwane_DevDriv =
          kwane_DevDriv_IN_S2_Move_to_waypoint;

        /* Entry 'S2_Move_to_waypoint': '<S1>:78' */
        kwane_DevDriv_B.xref = kwane_DevDriv_DW.xlocal;
        kwane_DevDriv_B.yref = kwane_DevDriv_DW.ylocal;
        kwane_DevDriv_B.Kpy = kwane_DevDriv_DW.Kp_l;
        kwane_DevDriv_B.Kiy = kwane_DevDriv_DW.Ki_l;
        kwane_DevDriv_B.Kpay = kwane_DevDriv_DW.Kpa_l;
        kwane_DevDriv_B.kix = kwane_DevDriv_DW.Kix_l;
        kwane_DevDriv_B.kpx = kwane_DevDriv_DW.Kpx_l;
        kwane_DevDriv_B.kpax = kwane_DevDriv_DW.Kpax_l;
        if ((kwane_DevDriv_DW.tsy_l >= kwane_DevDriv_DW.tsx_l) || rtIsNaN
            (kwane_DevDriv_DW.tsx_l)) {
          kwane_DevDriv_DW.ts = kwane_DevDriv_DW.tsy_l;
        } else {
          kwane_DevDriv_DW.ts = kwane_DevDriv_DW.tsx_l;
        }

        kwane_DevDriv_DW.arrived = 0.0;
        break;

       case kwane_DevDriv_IN_S2_Move_to_waypoint:
        /* During 'S2_Move_to_waypoint': '<S1>:78' */
        /* Transition: '<S1>:82' */
        kwane_DevDriv_DW.is_c1_kwane_DevDriv =
          kwane_DevDriv_IN_S3_log_stats_delay;
        kwane_DevDriv_DW.temporalCounter_i1 = 0U;

        /* Entry 'S3_log_stats_delay': '<S1>:80' */
        kwane_DevDriv_DW.index++;
        break;

       case kwane_DevDriv_IN_S3_log_stats_delay:
        /* During 'S3_log_stats_delay': '<S1>:80' */
        if (kwane_DevDriv_DW.temporalCounter_i1 >= (uint32_T)ceil
            (kwane_DevDriv_DW.ts / 0.01 - 1.0E-10)) {
          /* Transition: '<S1>:84' */
          kwane_DevDriv_DW.is_c1_kwane_DevDriv = kwane_DevDriv_IN_S4_checkifdone;

          /* Entry 'S4_checkifdone': '<S1>:83' */
          kwane_DevDriv_func3_CheckDone(kwane_DevDriv_DW.index,
            kwane_DevDriv_B.total_waypoints);
          kwane_DevDriv_DW.waypoints_reached_l += kwane_DevDriv_DW.arrived;
        } else {
          kwane_DevDriv_func2_CheckArrival(kwane_DevDriv_B.XScale,
            kwane_DevDriv_B.YScale, kwane_DevDriv_DW.xlocal,
            kwane_DevDriv_DW.ylocal);
        }
        break;

       case kwane_DevDriv_IN_S4_checkifdone:
        /* During 'S4_checkifdone': '<S1>:83' */
        if (kwane_DevDriv_DW.finished == 0.0) {
          /* Transition: '<S1>:85' */
          kwane_DevDriv_DW.is_c1_kwane_DevDriv = kwane_DevDriv_IN_S1_Initialize;

          /* Entry Internal 'S1_Initialize': '<S1>:7' */
          kwane_DevDriv_DW.is_active_S1_setpoints1 = 1U;

          /* Entry 'S1_setpoints1': '<S1>:12' */
          kwane_DevDriv_DW.xlocal = kwane_DevDriv_B.xwaypoints[(int32_T)
            kwane_DevDriv_DW.index - 1];
          kwane_DevDriv_DW.ylocal = kwane_DevDriv_B.ywaypoints[(int32_T)
            kwane_DevDriv_DW.index - 1];
          kwane_DevDriv_DW.arrived = 0.0;
          kwane_DevDriv_DW.is_active_S1_setup_pidy1 = 1U;

          /* Entry 'S1_setup_pidy1': '<S1>:11' */
          kwane_DevDriv_func1_setpidy(kwane_DevDriv_B.YScale,
            kwane_DevDriv_B.ywaypoints[(int32_T)kwane_DevDriv_DW.index - 1]);
          kwane_DevDriv_DW.is_active_S1_setup_pidy = 1U;

          /* Entry 'S1_setup_pidy': '<S1>:13' */
          kwane_DevDriv_func1_setpidx(kwane_DevDriv_B.XScale,
            kwane_DevDriv_B.xwaypoints[(int32_T)kwane_DevDriv_DW.index - 1]);
        } else {
          if (kwane_DevDriv_DW.finished == 1.0) {
            /* Transition: '<S1>:88' */
            kwane_DevDriv_DW.is_c1_kwane_DevDriv = kwane_DevDriv_IN_S5_done;

            /* Entry 'S5_done': '<S1>:86' */
            kwane_DevDriv_B.done = true;
            kwane_DevDriv_B.waypoints_reached =
              kwane_DevDriv_DW.waypoints_reached_l;
          }
        }
        break;

       default:
        /* During 'S5_done': '<S1>:86' */
        break;
      }
    }

    /* End of Chart: '<Root>/Controller' */

    /* Outport: '<Root>/waypoints_reached ' */
    kwane_DevDriv_Y.waypoints_reached = kwane_DevDriv_B.waypoints_reached;

    /* Gain: '<S2>/X Angle Scale' */
    kwane_DevDriv_B.XAngleScale = kwane_DevDriv_P.XAngleScale_Gain *
      rtb_Encoder500PPR[3];

    /* Gain: '<S2>/Y Angle Scale' */
    kwane_DevDriv_B.YAngleScale = kwane_DevDriv_P.YAngleScale_Gain *
      rtb_Encoder500PPR[4];

    /* Product: '<Root>/Product' */
    kwane_DevDriv_B.Product = kwane_DevDriv_B.kpax * kwane_DevDriv_B.XAngleScale;

    /* Sum: '<Root>/Add1' */
    rtb_Add1 = kwane_DevDriv_B.xref - kwane_DevDriv_B.XScale;

    /* Product: '<S3>/POut' */
    kwane_DevDriv_B.POut = rtb_Add1 * kwane_DevDriv_B.kpx;
  }

  /* Sum: '<Root>/Add' incorporates:
   *  Integrator: '<S3>/Integrator'
   *  Sum: '<S3>/Sum'
   */
  kwane_DevDriv_B.Add = (kwane_DevDriv_B.POut +
    kwane_DevDriv_X.Integrator_CSTATE) + kwane_DevDriv_B.Product;
  if (rtmIsMajorTimeStep(kwane_DevDriv_M)) {
    /* Product: '<Root>/Product1' */
    kwane_DevDriv_B.Product1 = kwane_DevDriv_B.YAngleScale *
      kwane_DevDriv_B.Kpay;

    /* Sum: '<Root>/Add2' */
    rtb_Add2 = kwane_DevDriv_B.yref - kwane_DevDriv_B.YScale;

    /* Product: '<S4>/POut' */
    kwane_DevDriv_B.POut_f = rtb_Add2 * kwane_DevDriv_B.Kpy;
  }

  /* Sum: '<Root>/Add3' incorporates:
   *  Integrator: '<S4>/Integrator'
   *  Sum: '<S4>/Sum'
   */
  kwane_DevDriv_B.Add3 = (kwane_DevDriv_B.POut_f +
    kwane_DevDriv_X.Integrator_CSTATE_g) + kwane_DevDriv_B.Product1;
  if (rtmIsMajorTimeStep(kwane_DevDriv_M)) {
    /* Stop: '<Root>/Stop Simulation' */
    if (kwane_DevDriv_B.done) {
      rtmSetStopRequested(kwane_DevDriv_M, 1);
    }

    /* End of Stop: '<Root>/Stop Simulation' */

    /* Level2 S-Function Block: '<S2>/PWM' (Crane3D_PWM) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[1];
      sfcnOutputs(rts, 1);
    }
  }

  /* Saturate: '<Root>/Saturation' */
  if (kwane_DevDriv_B.Add > kwane_DevDriv_P.Saturation_UpperSat) {
    u0 = kwane_DevDriv_P.Saturation_UpperSat;
  } else if (kwane_DevDriv_B.Add < kwane_DevDriv_P.Saturation_LowerSat) {
    u0 = kwane_DevDriv_P.Saturation_LowerSat;
  } else {
    u0 = kwane_DevDriv_B.Add;
  }

  /* End of Saturate: '<Root>/Saturation' */

  /* Saturate: '<S2>/Saturation' */
  if (u0 > kwane_DevDriv_P.Saturation_UpperSat_j) {
    kwane_DevDriv_B.Saturation[0] = kwane_DevDriv_P.Saturation_UpperSat_j;
  } else if (u0 < kwane_DevDriv_P.Saturation_LowerSat_l) {
    kwane_DevDriv_B.Saturation[0] = kwane_DevDriv_P.Saturation_LowerSat_l;
  } else {
    kwane_DevDriv_B.Saturation[0] = u0;
  }

  /* Saturate: '<Root>/Saturation1' */
  if (kwane_DevDriv_B.Add3 > kwane_DevDriv_P.Saturation1_UpperSat) {
    u0 = kwane_DevDriv_P.Saturation1_UpperSat;
  } else if (kwane_DevDriv_B.Add3 < kwane_DevDriv_P.Saturation1_LowerSat) {
    u0 = kwane_DevDriv_P.Saturation1_LowerSat;
  } else {
    u0 = kwane_DevDriv_B.Add3;
  }

  /* End of Saturate: '<Root>/Saturation1' */

  /* Saturate: '<S2>/Saturation' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  if (u0 > kwane_DevDriv_P.Saturation_UpperSat_j) {
    kwane_DevDriv_B.Saturation[1] = kwane_DevDriv_P.Saturation_UpperSat_j;
  } else if (u0 < kwane_DevDriv_P.Saturation_LowerSat_l) {
    kwane_DevDriv_B.Saturation[1] = kwane_DevDriv_P.Saturation_LowerSat_l;
  } else {
    kwane_DevDriv_B.Saturation[1] = u0;
  }

  if (kwane_DevDriv_P.Constant2_Value > kwane_DevDriv_P.Saturation_UpperSat_j) {
    kwane_DevDriv_B.Saturation[2] = kwane_DevDriv_P.Saturation_UpperSat_j;
  } else if (kwane_DevDriv_P.Constant2_Value <
             kwane_DevDriv_P.Saturation_LowerSat_l) {
    kwane_DevDriv_B.Saturation[2] = kwane_DevDriv_P.Saturation_LowerSat_l;
  } else {
    kwane_DevDriv_B.Saturation[2] = kwane_DevDriv_P.Constant2_Value;
  }

  if (rtmIsMajorTimeStep(kwane_DevDriv_M)) {
    /* Level2 S-Function Block: '<S2>/LimitFlag' (Crane3D_LimitFlag) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[2];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S2>/LimitFlagSource' */
    kwane_DevDriv_B.LimitFlagSource[0] = kwane_DevDriv_P.LimitFlagSource_Value[0];

    /* Constant: '<S2>/LimitSource' */
    kwane_DevDriv_B.LimitSource[0] = kwane_DevDriv_P.LimitSource_Value[0];

    /* Constant: '<S2>/LimitFlagSource' */
    kwane_DevDriv_B.LimitFlagSource[1] = kwane_DevDriv_P.LimitFlagSource_Value[1];

    /* Constant: '<S2>/LimitSource' */
    kwane_DevDriv_B.LimitSource[1] = kwane_DevDriv_P.LimitSource_Value[1];

    /* Constant: '<S2>/LimitFlagSource' */
    kwane_DevDriv_B.LimitFlagSource[2] = kwane_DevDriv_P.LimitFlagSource_Value[2];

    /* Constant: '<S2>/LimitSource' */
    kwane_DevDriv_B.LimitSource[2] = kwane_DevDriv_P.LimitSource_Value[2];

    /* Level2 S-Function Block: '<S2>/SetLimit' (Crane3D_SetLimit) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[3];
      sfcnOutputs(rts, 1);
    }

    /* Level2 S-Function Block: '<S2>/LimitSwitch' (Crane3D_Switch) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[4];
      sfcnOutputs(rts, 1);
    }

    /* Level2 S-Function Block: '<S2>/PWMPrescaler' (Crane3D_PWMPrescaler) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[5];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S2>/PWMPrescalerSource' */
    kwane_DevDriv_B.PWMPrescalerSource =
      kwane_DevDriv_P.PWMPrescalerSource_Value;

    /* Level2 S-Function Block: '<S2>/ResetEncoder' (Crane3D_ResetEncoder) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[6];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S2>/ResetSource' */
    for (i = 0; i < 5; i++) {
      kwane_DevDriv_B.ResetSource[i] = kwane_DevDriv_P.ResetSource_Value[i];
    }

    /* End of Constant: '<S2>/ResetSource' */

    /* Level2 S-Function Block: '<S2>/ResetSwitchFlag ' (Crane3D_ResetSwitchFlag) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[7];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S2>/ResetSwitchFlagSource' */
    kwane_DevDriv_B.ResetSwitchFlagSource[0] =
      kwane_DevDriv_P.ResetSwitchFlagSource_Value[0];
    kwane_DevDriv_B.ResetSwitchFlagSource[1] =
      kwane_DevDriv_P.ResetSwitchFlagSource_Value[1];
    kwane_DevDriv_B.ResetSwitchFlagSource[2] =
      kwane_DevDriv_P.ResetSwitchFlagSource_Value[2];

    /* Level2 S-Function Block: '<S2>/ThermFlag ' (Crane3D_ThermFlag) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[8];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S2>/ThermFlagSource' */
    kwane_DevDriv_B.ThermFlagSource[0] = kwane_DevDriv_P.ThermFlagSource_Value[0];
    kwane_DevDriv_B.ThermFlagSource[1] = kwane_DevDriv_P.ThermFlagSource_Value[1];
    kwane_DevDriv_B.ThermFlagSource[2] = kwane_DevDriv_P.ThermFlagSource_Value[2];

    /* Product: '<S3>/IOut' */
    kwane_DevDriv_B.IOut = rtb_Add1 * kwane_DevDriv_B.kix;

    /* Product: '<S4>/IOut' */
    kwane_DevDriv_B.IOut_o = rtb_Add2 * kwane_DevDriv_B.Kiy;
  }
}

/* Model update function */
void kwane_DevDriv_update(void)
{
  if (rtmIsMajorTimeStep(kwane_DevDriv_M)) {
    rt_ertODEUpdateContinuousStates(&kwane_DevDriv_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++kwane_DevDriv_M->Timing.clockTick0)) {
    ++kwane_DevDriv_M->Timing.clockTickH0;
  }

  kwane_DevDriv_M->Timing.t[0] = rtsiGetSolverStopTime
    (&kwane_DevDriv_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++kwane_DevDriv_M->Timing.clockTick1)) {
      ++kwane_DevDriv_M->Timing.clockTickH1;
    }

    kwane_DevDriv_M->Timing.t[1] = kwane_DevDriv_M->Timing.clockTick1 *
      kwane_DevDriv_M->Timing.stepSize1 + kwane_DevDriv_M->Timing.clockTickH1 *
      kwane_DevDriv_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void kwane_DevDriv_derivatives(void)
{
  XDot_kwane_DevDriv_T *_rtXdot;
  _rtXdot = ((XDot_kwane_DevDriv_T *) kwane_DevDriv_M->ModelData.derivs);

  /* Derivatives for Integrator: '<S3>/Integrator' */
  _rtXdot->Integrator_CSTATE = kwane_DevDriv_B.IOut;

  /* Derivatives for Integrator: '<S4>/Integrator' */
  _rtXdot->Integrator_CSTATE_g = kwane_DevDriv_B.IOut_o;
}

/* Model initialize function */
void kwane_DevDriv_initialize(void)
{
  {
    int32_T i;
    for (i = 0; i < 6; i++) {
      /* Start for Constant: '<Root>/xwaypoints' */
      kwane_DevDriv_B.xwaypoints[i] = kwane_DevDriv_P.xwaypoints[i];

      /* Start for Constant: '<Root>/ywaypoints ' */
      kwane_DevDriv_B.ywaypoints[i] = kwane_DevDriv_P.ywaypoints[i];
    }

    kwane_DevDriv_B.start_course = kwane_DevDriv_P.start_course;

    /* Start for Constant: '<Root>/total_waypoints ' */
    kwane_DevDriv_B.total_waypoints = kwane_DevDriv_P.total_waypoints;

    /* Start for Constant: '<S2>/LimitFlagSource' */
    kwane_DevDriv_B.LimitFlagSource[0] = kwane_DevDriv_P.LimitFlagSource_Value[0];

    /* Start for Constant: '<S2>/LimitSource' */
    kwane_DevDriv_B.LimitSource[0] = kwane_DevDriv_P.LimitSource_Value[0];

    /* Start for Constant: '<S2>/LimitFlagSource' */
    kwane_DevDriv_B.LimitFlagSource[1] = kwane_DevDriv_P.LimitFlagSource_Value[1];

    /* Start for Constant: '<S2>/LimitSource' */
    kwane_DevDriv_B.LimitSource[1] = kwane_DevDriv_P.LimitSource_Value[1];

    /* Start for Constant: '<S2>/LimitFlagSource' */
    kwane_DevDriv_B.LimitFlagSource[2] = kwane_DevDriv_P.LimitFlagSource_Value[2];

    /* Start for Constant: '<S2>/LimitSource' */
    kwane_DevDriv_B.LimitSource[2] = kwane_DevDriv_P.LimitSource_Value[2];

    /* Start for Constant: '<S2>/PWMPrescalerSource' */
    kwane_DevDriv_B.PWMPrescalerSource =
      kwane_DevDriv_P.PWMPrescalerSource_Value;

    /* Start for Constant: '<S2>/ResetSource' */
    for (i = 0; i < 5; i++) {
      kwane_DevDriv_B.ResetSource[i] = kwane_DevDriv_P.ResetSource_Value[i];
    }

    /* End of Start for Constant: '<S2>/ResetSource' */
    /* Start for Constant: '<S2>/ResetSwitchFlagSource' */
    kwane_DevDriv_B.ResetSwitchFlagSource[0] =
      kwane_DevDriv_P.ResetSwitchFlagSource_Value[0];
    kwane_DevDriv_B.ResetSwitchFlagSource[1] =
      kwane_DevDriv_P.ResetSwitchFlagSource_Value[1];
    kwane_DevDriv_B.ResetSwitchFlagSource[2] =
      kwane_DevDriv_P.ResetSwitchFlagSource_Value[2];

    /* Start for Constant: '<S2>/ThermFlagSource' */
    kwane_DevDriv_B.ThermFlagSource[0] = kwane_DevDriv_P.ThermFlagSource_Value[0];
    kwane_DevDriv_B.ThermFlagSource[1] = kwane_DevDriv_P.ThermFlagSource_Value[1];
    kwane_DevDriv_B.ThermFlagSource[2] = kwane_DevDriv_P.ThermFlagSource_Value[2];
  }

  /* InitializeConditions for Integrator: '<S3>/Integrator' */
  kwane_DevDriv_X.Integrator_CSTATE = kwane_DevDriv_P.Integrator_IC;

  /* InitializeConditions for Integrator: '<S4>/Integrator' */
  kwane_DevDriv_X.Integrator_CSTATE_g = kwane_DevDriv_P.Integrator_IC_o;

  /* SystemInitialize for Chart: '<Root>/Controller' */
  kwane_DevDriv_DW.sfEvent = kwane_DevDriv_CALL_EVENT;
  kwane_DevDriv_DW.is_active_S1_setpoints1 = 0U;
  kwane_DevDriv_DW.is_active_S1_setup_pidy = 0U;
  kwane_DevDriv_DW.is_active_S1_setup_pidy1 = 0U;
  kwane_DevDriv_DW.temporalCounter_i1 = 0U;
  kwane_DevDriv_DW.is_active_c1_kwane_DevDriv = 0U;
  kwane_DevDriv_DW.is_c1_kwane_DevDriv = kwane_DevDriv_IN_NO_ACTIVE_CHILD;
}

/* Model terminate function */
void kwane_DevDriv_terminate(void)
{
  /* Level2 S-Function Block: '<S2>/Encoder' (Crane3D_Encoder) */
  {
    SimStruct *rts = kwane_DevDriv_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/PWM' (Crane3D_PWM) */
  {
    SimStruct *rts = kwane_DevDriv_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/LimitFlag' (Crane3D_LimitFlag) */
  {
    SimStruct *rts = kwane_DevDriv_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/SetLimit' (Crane3D_SetLimit) */
  {
    SimStruct *rts = kwane_DevDriv_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/LimitSwitch' (Crane3D_Switch) */
  {
    SimStruct *rts = kwane_DevDriv_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/PWMPrescaler' (Crane3D_PWMPrescaler) */
  {
    SimStruct *rts = kwane_DevDriv_M->childSfunctions[5];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/ResetEncoder' (Crane3D_ResetEncoder) */
  {
    SimStruct *rts = kwane_DevDriv_M->childSfunctions[6];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/ResetSwitchFlag ' (Crane3D_ResetSwitchFlag) */
  {
    SimStruct *rts = kwane_DevDriv_M->childSfunctions[7];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S2>/ThermFlag ' (Crane3D_ThermFlag) */
  {
    SimStruct *rts = kwane_DevDriv_M->childSfunctions[8];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  kwane_DevDriv_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  kwane_DevDriv_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  kwane_DevDriv_initialize();
}

void MdlTerminate(void)
{
  kwane_DevDriv_terminate();
}

/* Registration function */
RT_MODEL_kwane_DevDriv_T *kwane_DevDriv(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)kwane_DevDriv_M, 0,
                sizeof(RT_MODEL_kwane_DevDriv_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&kwane_DevDriv_M->solverInfo,
                          &kwane_DevDriv_M->Timing.simTimeStep);
    rtsiSetTPtr(&kwane_DevDriv_M->solverInfo, &rtmGetTPtr(kwane_DevDriv_M));
    rtsiSetStepSizePtr(&kwane_DevDriv_M->solverInfo,
                       &kwane_DevDriv_M->Timing.stepSize0);
    rtsiSetdXPtr(&kwane_DevDriv_M->solverInfo,
                 &kwane_DevDriv_M->ModelData.derivs);
    rtsiSetContStatesPtr(&kwane_DevDriv_M->solverInfo, (real_T **)
                         &kwane_DevDriv_M->ModelData.contStates);
    rtsiSetNumContStatesPtr(&kwane_DevDriv_M->solverInfo,
      &kwane_DevDriv_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&kwane_DevDriv_M->solverInfo,
      &kwane_DevDriv_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&kwane_DevDriv_M->solverInfo,
      &kwane_DevDriv_M->ModelData.periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&kwane_DevDriv_M->solverInfo,
      &kwane_DevDriv_M->ModelData.periodicContStateRanges);
    rtsiSetErrorStatusPtr(&kwane_DevDriv_M->solverInfo, (&rtmGetErrorStatus
      (kwane_DevDriv_M)));
    rtsiSetRTModelPtr(&kwane_DevDriv_M->solverInfo, kwane_DevDriv_M);
  }

  rtsiSetSimTimeStep(&kwane_DevDriv_M->solverInfo, MAJOR_TIME_STEP);
  kwane_DevDriv_M->ModelData.intgData.y = kwane_DevDriv_M->ModelData.odeY;
  kwane_DevDriv_M->ModelData.intgData.f[0] = kwane_DevDriv_M->ModelData.odeF[0];
  kwane_DevDriv_M->ModelData.intgData.f[1] = kwane_DevDriv_M->ModelData.odeF[1];
  kwane_DevDriv_M->ModelData.intgData.f[2] = kwane_DevDriv_M->ModelData.odeF[2];
  kwane_DevDriv_M->ModelData.intgData.f[3] = kwane_DevDriv_M->ModelData.odeF[3];
  kwane_DevDriv_M->ModelData.intgData.f[4] = kwane_DevDriv_M->ModelData.odeF[4];
  kwane_DevDriv_M->ModelData.intgData.f[5] = kwane_DevDriv_M->ModelData.odeF[5];
  kwane_DevDriv_M->ModelData.contStates = ((real_T *) &kwane_DevDriv_X);
  rtsiSetSolverData(&kwane_DevDriv_M->solverInfo, (void *)
                    &kwane_DevDriv_M->ModelData.intgData);
  rtsiSetSolverName(&kwane_DevDriv_M->solverInfo,"ode5");
  kwane_DevDriv_M->solverInfoPtr = (&kwane_DevDriv_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = kwane_DevDriv_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    kwane_DevDriv_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    kwane_DevDriv_M->Timing.sampleTimes =
      (&kwane_DevDriv_M->Timing.sampleTimesArray[0]);
    kwane_DevDriv_M->Timing.offsetTimes =
      (&kwane_DevDriv_M->Timing.offsetTimesArray[0]);

    /* task periods */
    kwane_DevDriv_M->Timing.sampleTimes[0] = (0.0);
    kwane_DevDriv_M->Timing.sampleTimes[1] = (0.01);

    /* task offsets */
    kwane_DevDriv_M->Timing.offsetTimes[0] = (0.0);
    kwane_DevDriv_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(kwane_DevDriv_M, &kwane_DevDriv_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = kwane_DevDriv_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    kwane_DevDriv_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(kwane_DevDriv_M, -1);
  kwane_DevDriv_M->Timing.stepSize0 = 0.01;
  kwane_DevDriv_M->Timing.stepSize1 = 0.01;

  /* External mode info */
  kwane_DevDriv_M->Sizes.checksums[0] = (3022426340U);
  kwane_DevDriv_M->Sizes.checksums[1] = (2887038166U);
  kwane_DevDriv_M->Sizes.checksums[2] = (1485030111U);
  kwane_DevDriv_M->Sizes.checksums[3] = (2348937789U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[2];
    kwane_DevDriv_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(kwane_DevDriv_M->extModeInfo,
      &kwane_DevDriv_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(kwane_DevDriv_M->extModeInfo,
                        kwane_DevDriv_M->Sizes.checksums);
    rteiSetTPtr(kwane_DevDriv_M->extModeInfo, rtmGetTPtr(kwane_DevDriv_M));
  }

  kwane_DevDriv_M->solverInfoPtr = (&kwane_DevDriv_M->solverInfo);
  kwane_DevDriv_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&kwane_DevDriv_M->solverInfo, 0.01);
  rtsiSetSolverMode(&kwane_DevDriv_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  kwane_DevDriv_M->ModelData.blockIO = ((void *) &kwane_DevDriv_B);
  (void) memset(((void *) &kwane_DevDriv_B), 0,
                sizeof(B_kwane_DevDriv_T));

  {
    int32_T i;
    for (i = 0; i < 5; i++) {
      kwane_DevDriv_B.Encoder[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      kwane_DevDriv_B.xwaypoints[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      kwane_DevDriv_B.ywaypoints[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      kwane_DevDriv_B.ResetEncoder[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      kwane_DevDriv_B.ResetSource[i] = 0.0;
    }

    kwane_DevDriv_B.XScale = 0.0;
    kwane_DevDriv_B.start_course = 0.0;
    kwane_DevDriv_B.total_waypoints = 0.0;
    kwane_DevDriv_B.YScale = 0.0;
    kwane_DevDriv_B.XAngleScale = 0.0;
    kwane_DevDriv_B.YAngleScale = 0.0;
    kwane_DevDriv_B.Product = 0.0;
    kwane_DevDriv_B.POut = 0.0;
    kwane_DevDriv_B.Add = 0.0;
    kwane_DevDriv_B.Product1 = 0.0;
    kwane_DevDriv_B.POut_f = 0.0;
    kwane_DevDriv_B.Add3 = 0.0;
    kwane_DevDriv_B.PWM[0] = 0.0;
    kwane_DevDriv_B.PWM[1] = 0.0;
    kwane_DevDriv_B.PWM[2] = 0.0;
    kwane_DevDriv_B.Saturation[0] = 0.0;
    kwane_DevDriv_B.Saturation[1] = 0.0;
    kwane_DevDriv_B.Saturation[2] = 0.0;
    kwane_DevDriv_B.LimitFlag[0] = 0.0;
    kwane_DevDriv_B.LimitFlag[1] = 0.0;
    kwane_DevDriv_B.LimitFlag[2] = 0.0;
    kwane_DevDriv_B.LimitFlagSource[0] = 0.0;
    kwane_DevDriv_B.LimitFlagSource[1] = 0.0;
    kwane_DevDriv_B.LimitFlagSource[2] = 0.0;
    kwane_DevDriv_B.LimitSource[0] = 0.0;
    kwane_DevDriv_B.LimitSource[1] = 0.0;
    kwane_DevDriv_B.LimitSource[2] = 0.0;
    kwane_DevDriv_B.SetLimit[0] = 0.0;
    kwane_DevDriv_B.SetLimit[1] = 0.0;
    kwane_DevDriv_B.SetLimit[2] = 0.0;
    kwane_DevDriv_B.LimitSwitch[0] = 0.0;
    kwane_DevDriv_B.LimitSwitch[1] = 0.0;
    kwane_DevDriv_B.LimitSwitch[2] = 0.0;
    kwane_DevDriv_B.PWMPrescaler = 0.0;
    kwane_DevDriv_B.PWMPrescalerSource = 0.0;
    kwane_DevDriv_B.ResetSwitchFlag[0] = 0.0;
    kwane_DevDriv_B.ResetSwitchFlag[1] = 0.0;
    kwane_DevDriv_B.ResetSwitchFlag[2] = 0.0;
    kwane_DevDriv_B.ResetSwitchFlagSource[0] = 0.0;
    kwane_DevDriv_B.ResetSwitchFlagSource[1] = 0.0;
    kwane_DevDriv_B.ResetSwitchFlagSource[2] = 0.0;
    kwane_DevDriv_B.ThermFlag[0] = 0.0;
    kwane_DevDriv_B.ThermFlag[1] = 0.0;
    kwane_DevDriv_B.ThermFlag[2] = 0.0;
    kwane_DevDriv_B.ThermFlagSource[0] = 0.0;
    kwane_DevDriv_B.ThermFlagSource[1] = 0.0;
    kwane_DevDriv_B.ThermFlagSource[2] = 0.0;
    kwane_DevDriv_B.IOut = 0.0;
    kwane_DevDriv_B.IOut_o = 0.0;
    kwane_DevDriv_B.kpax = 0.0;
    kwane_DevDriv_B.xref = 0.0;
    kwane_DevDriv_B.kpx = 0.0;
    kwane_DevDriv_B.kix = 0.0;
    kwane_DevDriv_B.yref = 0.0;
    kwane_DevDriv_B.Kpy = 0.0;
    kwane_DevDriv_B.Kiy = 0.0;
    kwane_DevDriv_B.Kpay = 0.0;
    kwane_DevDriv_B.waypoints_reached = 0.0;
  }

  /* parameters */
  kwane_DevDriv_M->ModelData.defaultParam = ((real_T *)&kwane_DevDriv_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &kwane_DevDriv_X;
    kwane_DevDriv_M->ModelData.contStates = (x);
    (void) memset((void *)&kwane_DevDriv_X, 0,
                  sizeof(X_kwane_DevDriv_T));
  }

  /* states (dwork) */
  kwane_DevDriv_M->ModelData.dwork = ((void *) &kwane_DevDriv_DW);
  (void) memset((void *)&kwane_DevDriv_DW, 0,
                sizeof(DW_kwane_DevDriv_T));
  kwane_DevDriv_DW.finished = 0.0;
  kwane_DevDriv_DW.waypoints_reached_l = 0.0;
  kwane_DevDriv_DW.ylocal = 0.0;
  kwane_DevDriv_DW.index = 0.0;
  kwane_DevDriv_DW.xlocal = 0.0;
  kwane_DevDriv_DW.Kpa_l = 0.0;
  kwane_DevDriv_DW.tsy_l = 0.0;
  kwane_DevDriv_DW.Kix_l = 0.0;
  kwane_DevDriv_DW.ts = 0.0;
  kwane_DevDriv_DW.Kpx_l = 0.0;
  kwane_DevDriv_DW.Ki_l = 0.0;
  kwane_DevDriv_DW.Kpax_l = 0.0;
  kwane_DevDriv_DW.Kp_l = 0.0;
  kwane_DevDriv_DW.tsx_l = 0.0;
  kwane_DevDriv_DW.arrived = 0.0;

  /* external outputs */
  kwane_DevDriv_M->ModelData.outputs = (&kwane_DevDriv_Y);
  kwane_DevDriv_Y.waypoints_reached = 0.0;

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    kwane_DevDriv_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &kwane_DevDriv_M->NonInlinedSFcns.sfcnInfo;
    kwane_DevDriv_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(kwane_DevDriv_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo, &kwane_DevDriv_M->Sizes.numSampTimes);
    kwane_DevDriv_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (kwane_DevDriv_M)[0]);
    kwane_DevDriv_M->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr
      (kwane_DevDriv_M)[1]);
    rtssSetTPtrPtr(sfcnInfo,kwane_DevDriv_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(kwane_DevDriv_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(kwane_DevDriv_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput(kwane_DevDriv_M));
    rtssSetStepSizePtr(sfcnInfo, &kwane_DevDriv_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(kwane_DevDriv_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &kwane_DevDriv_M->ModelData.derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &kwane_DevDriv_M->ModelData.zCCacheNeedsReset);
    rtssSetBlkStateChangePtr(sfcnInfo,
      &kwane_DevDriv_M->ModelData.blkStateChange);
    rtssSetSampleHitsPtr(sfcnInfo, &kwane_DevDriv_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &kwane_DevDriv_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &kwane_DevDriv_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &kwane_DevDriv_M->solverInfoPtr);
  }

  kwane_DevDriv_M->Sizes.numSFcns = (9);

  /* register each child */
  {
    (void) memset((void *)&kwane_DevDriv_M->NonInlinedSFcns.childSFunctions[0],
                  0,
                  9*sizeof(SimStruct));
    kwane_DevDriv_M->childSfunctions =
      (&kwane_DevDriv_M->NonInlinedSFcns.childSFunctionPtrs[0]);

    {
      int_T i;
      for (i = 0; i < 9; i++) {
        kwane_DevDriv_M->childSfunctions[i] =
          (&kwane_DevDriv_M->NonInlinedSFcns.childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: kwane_DevDriv/<S2>/Encoder (Crane3D_Encoder) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = kwane_DevDriv_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = kwane_DevDriv_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = kwane_DevDriv_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &kwane_DevDriv_M->NonInlinedSFcns.blkInfo2[0]);
      }

      ssSetRTWSfcnInfo(rts, kwane_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &kwane_DevDriv_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((real_T *) kwane_DevDriv_B.Encoder));
        }
      }

      /* path info */
      ssSetModelName(rts, "Encoder");
      ssSetPath(rts, "kwane_DevDriv/Crane 3D/Encoder");
      ssSetRTModel(rts,kwane_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)kwane_DevDriv_P.Encoder_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)kwane_DevDriv_P.Encoder_P2_Size);
      }

      /* registration */
      Crane3D_Encoder(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: kwane_DevDriv/<S2>/PWM (Crane3D_PWM) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod = kwane_DevDriv_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset = kwane_DevDriv_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = kwane_DevDriv_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &kwane_DevDriv_M->NonInlinedSFcns.blkInfo2[1]);
      }

      ssSetRTWSfcnInfo(rts, kwane_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &kwane_DevDriv_M->NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &kwane_DevDriv_M->NonInlinedSFcns.Sfcn1.UPtrs0;
          sfcnUPtrs[0] = kwane_DevDriv_B.Saturation;
          sfcnUPtrs[1] = &kwane_DevDriv_B.Saturation[1];
          sfcnUPtrs[2] = &kwane_DevDriv_B.Saturation[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *) kwane_DevDriv_B.PWM));
        }
      }

      /* path info */
      ssSetModelName(rts, "PWM");
      ssSetPath(rts, "kwane_DevDriv/Crane 3D/PWM");
      ssSetRTModel(rts,kwane_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)kwane_DevDriv_P.PWM_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)kwane_DevDriv_P.PWM_P2_Size);
      }

      /* registration */
      Crane3D_PWM(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: kwane_DevDriv/<S2>/LimitFlag (Crane3D_LimitFlag) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod = kwane_DevDriv_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset = kwane_DevDriv_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = kwane_DevDriv_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &kwane_DevDriv_M->NonInlinedSFcns.blkInfo2[2]);
      }

      ssSetRTWSfcnInfo(rts, kwane_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &kwane_DevDriv_M->NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn2.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &kwane_DevDriv_M->NonInlinedSFcns.Sfcn2.UPtrs0;
          sfcnUPtrs[0] = kwane_DevDriv_B.LimitFlagSource;
          sfcnUPtrs[1] = &kwane_DevDriv_B.LimitFlagSource[1];
          sfcnUPtrs[2] = &kwane_DevDriv_B.LimitFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *) kwane_DevDriv_B.LimitFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "LimitFlag");
      ssSetPath(rts, "kwane_DevDriv/Crane 3D/LimitFlag");
      ssSetRTModel(rts,kwane_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)kwane_DevDriv_P.LimitFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)kwane_DevDriv_P.LimitFlag_P2_Size);
      }

      /* registration */
      Crane3D_LimitFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: kwane_DevDriv/<S2>/SetLimit (Crane3D_SetLimit) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod = kwane_DevDriv_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset = kwane_DevDriv_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap = kwane_DevDriv_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &kwane_DevDriv_M->NonInlinedSFcns.blkInfo2[3]);
      }

      ssSetRTWSfcnInfo(rts, kwane_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &kwane_DevDriv_M->NonInlinedSFcns.statesInfo2[3]);
        ssSetPeriodicStatesInfo(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[3]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn3.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &kwane_DevDriv_M->NonInlinedSFcns.Sfcn3.UPtrs0;
          sfcnUPtrs[0] = kwane_DevDriv_B.LimitSource;
          sfcnUPtrs[1] = &kwane_DevDriv_B.LimitSource[1];
          sfcnUPtrs[2] = &kwane_DevDriv_B.LimitSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn3.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *) kwane_DevDriv_B.SetLimit));
        }
      }

      /* path info */
      ssSetModelName(rts, "SetLimit");
      ssSetPath(rts, "kwane_DevDriv/Crane 3D/SetLimit");
      ssSetRTModel(rts,kwane_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)kwane_DevDriv_P.SetLimit_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)kwane_DevDriv_P.SetLimit_P2_Size);
      }

      /* registration */
      Crane3D_SetLimit(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: kwane_DevDriv/<S2>/LimitSwitch (Crane3D_Switch) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod = kwane_DevDriv_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset = kwane_DevDriv_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap = kwane_DevDriv_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &kwane_DevDriv_M->NonInlinedSFcns.blkInfo2[4]);
      }

      ssSetRTWSfcnInfo(rts, kwane_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods2[4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods3[4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &kwane_DevDriv_M->NonInlinedSFcns.statesInfo2[4]);
        ssSetPeriodicStatesInfo(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[4]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn4.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *) kwane_DevDriv_B.LimitSwitch));
        }
      }

      /* path info */
      ssSetModelName(rts, "LimitSwitch");
      ssSetPath(rts, "kwane_DevDriv/Crane 3D/LimitSwitch");
      ssSetRTModel(rts,kwane_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)kwane_DevDriv_P.LimitSwitch_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)kwane_DevDriv_P.LimitSwitch_P2_Size);
      }

      /* registration */
      Crane3D_Switch(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: kwane_DevDriv/<S2>/PWMPrescaler (Crane3D_PWMPrescaler) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[5];

      /* timing info */
      time_T *sfcnPeriod = kwane_DevDriv_M->NonInlinedSFcns.Sfcn5.sfcnPeriod;
      time_T *sfcnOffset = kwane_DevDriv_M->NonInlinedSFcns.Sfcn5.sfcnOffset;
      int_T *sfcnTsMap = kwane_DevDriv_M->NonInlinedSFcns.Sfcn5.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &kwane_DevDriv_M->NonInlinedSFcns.blkInfo2[5]);
      }

      ssSetRTWSfcnInfo(rts, kwane_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods2[5]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods3[5]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &kwane_DevDriv_M->NonInlinedSFcns.statesInfo2[5]);
        ssSetPeriodicStatesInfo(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[5]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn5.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &kwane_DevDriv_M->NonInlinedSFcns.Sfcn5.UPtrs0;
          sfcnUPtrs[0] = &kwane_DevDriv_B.PWMPrescalerSource;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn5.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &kwane_DevDriv_B.PWMPrescaler));
        }
      }

      /* path info */
      ssSetModelName(rts, "PWMPrescaler");
      ssSetPath(rts, "kwane_DevDriv/Crane 3D/PWMPrescaler");
      ssSetRTModel(rts,kwane_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn5.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)kwane_DevDriv_P.PWMPrescaler_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)kwane_DevDriv_P.PWMPrescaler_P2_Size);
      }

      /* registration */
      Crane3D_PWMPrescaler(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: kwane_DevDriv/<S2>/ResetEncoder (Crane3D_ResetEncoder) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[6];

      /* timing info */
      time_T *sfcnPeriod = kwane_DevDriv_M->NonInlinedSFcns.Sfcn6.sfcnPeriod;
      time_T *sfcnOffset = kwane_DevDriv_M->NonInlinedSFcns.Sfcn6.sfcnOffset;
      int_T *sfcnTsMap = kwane_DevDriv_M->NonInlinedSFcns.Sfcn6.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &kwane_DevDriv_M->NonInlinedSFcns.blkInfo2[6]);
      }

      ssSetRTWSfcnInfo(rts, kwane_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods2[6]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods3[6]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &kwane_DevDriv_M->NonInlinedSFcns.statesInfo2[6]);
        ssSetPeriodicStatesInfo(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[6]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn6.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &kwane_DevDriv_M->NonInlinedSFcns.Sfcn6.UPtrs0;

          {
            int_T i1;
            const real_T *u0 = kwane_DevDriv_B.ResetSource;
            for (i1=0; i1 < 5; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }

          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 5);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn6.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((real_T *) kwane_DevDriv_B.ResetEncoder));
        }
      }

      /* path info */
      ssSetModelName(rts, "ResetEncoder");
      ssSetPath(rts, "kwane_DevDriv/Crane 3D/ResetEncoder");
      ssSetRTModel(rts,kwane_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn6.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)kwane_DevDriv_P.ResetEncoder_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)kwane_DevDriv_P.ResetEncoder_P2_Size);
      }

      /* registration */
      Crane3D_ResetEncoder(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: kwane_DevDriv/<S2>/ResetSwitchFlag  (Crane3D_ResetSwitchFlag) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[7];

      /* timing info */
      time_T *sfcnPeriod = kwane_DevDriv_M->NonInlinedSFcns.Sfcn7.sfcnPeriod;
      time_T *sfcnOffset = kwane_DevDriv_M->NonInlinedSFcns.Sfcn7.sfcnOffset;
      int_T *sfcnTsMap = kwane_DevDriv_M->NonInlinedSFcns.Sfcn7.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &kwane_DevDriv_M->NonInlinedSFcns.blkInfo2[7]);
      }

      ssSetRTWSfcnInfo(rts, kwane_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods2[7]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods3[7]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &kwane_DevDriv_M->NonInlinedSFcns.statesInfo2[7]);
        ssSetPeriodicStatesInfo(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[7]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn7.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &kwane_DevDriv_M->NonInlinedSFcns.Sfcn7.UPtrs0;
          sfcnUPtrs[0] = kwane_DevDriv_B.ResetSwitchFlagSource;
          sfcnUPtrs[1] = &kwane_DevDriv_B.ResetSwitchFlagSource[1];
          sfcnUPtrs[2] = &kwane_DevDriv_B.ResetSwitchFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn7.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            kwane_DevDriv_B.ResetSwitchFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "ResetSwitchFlag ");
      ssSetPath(rts, "kwane_DevDriv/Crane 3D/ResetSwitchFlag ");
      ssSetRTModel(rts,kwane_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn7.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)kwane_DevDriv_P.ResetSwitchFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)kwane_DevDriv_P.ResetSwitchFlag_P2_Size);
      }

      /* registration */
      Crane3D_ResetSwitchFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: kwane_DevDriv/<S2>/ThermFlag  (Crane3D_ThermFlag) */
    {
      SimStruct *rts = kwane_DevDriv_M->childSfunctions[8];

      /* timing info */
      time_T *sfcnPeriod = kwane_DevDriv_M->NonInlinedSFcns.Sfcn8.sfcnPeriod;
      time_T *sfcnOffset = kwane_DevDriv_M->NonInlinedSFcns.Sfcn8.sfcnOffset;
      int_T *sfcnTsMap = kwane_DevDriv_M->NonInlinedSFcns.Sfcn8.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts, &kwane_DevDriv_M->NonInlinedSFcns.blkInfo2[8]);
      }

      ssSetRTWSfcnInfo(rts, kwane_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods2[8]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &kwane_DevDriv_M->NonInlinedSFcns.methods3[8]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &kwane_DevDriv_M->NonInlinedSFcns.statesInfo2[8]);
        ssSetPeriodicStatesInfo(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[8]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn8.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &kwane_DevDriv_M->NonInlinedSFcns.Sfcn8.UPtrs0;
          sfcnUPtrs[0] = kwane_DevDriv_B.ThermFlagSource;
          sfcnUPtrs[1] = &kwane_DevDriv_B.ThermFlagSource[1];
          sfcnUPtrs[2] = &kwane_DevDriv_B.ThermFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn8.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *) kwane_DevDriv_B.ThermFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "ThermFlag ");
      ssSetPath(rts, "kwane_DevDriv/Crane 3D/ThermFlag ");
      ssSetRTModel(rts,kwane_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &kwane_DevDriv_M->NonInlinedSFcns.Sfcn8.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)kwane_DevDriv_P.ThermFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)kwane_DevDriv_P.ThermFlag_P2_Size);
      }

      /* registration */
      Crane3D_ThermFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }
  }

  /* Initialize Sizes */
  kwane_DevDriv_M->Sizes.numContStates = (2);/* Number of continuous states */
  kwane_DevDriv_M->Sizes.numPeriodicContStates = (0);/* Number of periodic continuous states */
  kwane_DevDriv_M->Sizes.numY = (1);   /* Number of model outputs */
  kwane_DevDriv_M->Sizes.numU = (0);   /* Number of model inputs */
  kwane_DevDriv_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  kwane_DevDriv_M->Sizes.numSampTimes = (2);/* Number of sample times */
  kwane_DevDriv_M->Sizes.numBlocks = (55);/* Number of blocks */
  kwane_DevDriv_M->Sizes.numBlockIO = (42);/* Number of block outputs */
  kwane_DevDriv_M->Sizes.numBlockPrms = (100);/* Sum of parameter "widths" */
  return kwane_DevDriv_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
