/*
 * optimis_Crane3D_DevDriv.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "optimis_Crane3D_DevDriv".
 *
 * Model version              : 1.122
 * Simulink Coder version : 8.10 (R2016a) 10-Feb-2016
 * C source code generated on : Mon Dec 18 10:35:49 2017
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "optimis_Crane3D_DevDriv.h"
#include "optimis_Crane3D_DevDriv_private.h"
#include "optimis_Crane3D_DevDriv_dt.h"

/* Named constants for Chart: '<Root>/HL Controller' */
#define optimis_Crane3D_DevDriv_CALL_EVENT (-1)
#define optimis_Crane3D_DevDriv_IN_Idle ((uint8_T)1U)
#define optimis_Crane3D_DevDriv_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define optimis_Crane3D_DevDriv_IN_S1_initialize ((uint8_T)2U)
#define optimis_Crane3D_DevDriv_IN_S2_move_it ((uint8_T)3U)
#define optimis_Crane3D_DevDriv_IN_S3_new_input ((uint8_T)4U)
#define optimis_Crane3D_DevDriv_IN_S4_wait1 ((uint8_T)5U)
#define optimis_Crane3D_DevDriv_IN_S5_checkifdone ((uint8_T)6U)
#define optimis_Crane3D_DevDriv_IN_S6_done ((uint8_T)7U)

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.01, 0.0,
};

/* Block signals (auto storage) */
B_optimis_Crane3D_DevDriv_T optimis_Crane3D_DevDriv_B;

/* Continuous states */
X_optimis_Crane3D_DevDriv_T optimis_Crane3D_DevDriv_X;

/* Block states (auto storage) */
DW_optimis_Crane3D_DevDriv_T optimis_Crane3D_DevDriv_DW;

/* Real-time model */
RT_MODEL_optimis_Crane3D_DevDriv_T optimis_Crane3D_DevDriv_M_;
RT_MODEL_optimis_Crane3D_DevDriv_T *const optimis_Crane3D_DevDriv_M =
  &optimis_Crane3D_DevDriv_M_;

/* Forward declaration for local functions */
static void optimis_Crane3D_DevDriv_setpidy(real_T ycurrent, real_T ydest,
  real_T *Kd, real_T *Kp, real_T *Ki, real_T *Kpa);
static void optimis_Crane3D_DevDriv_func1_setpidy(real_T ycurrent, real_T ydest);
static void optimis_Crane3D_DevDriv_setpidx(real_T xcurrent, real_T xdest,
  real_T *Kix, real_T *Kpx, real_T *Kpax);
static void optimis_Crane3D_DevDriv_func1_setpidx(real_T xcurrent, real_T xdest);
static void optimis_Crane3D_DevDriv_func2_CheckArrival(real_T currentx, real_T
  currenty, real_T xdest, real_T ydest);
static void optimis_Crane3D_DevDriv_func3_CheckDone(real_T count, real_T total);

/*
 * This function updates continuous states using the ODE5 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE5_A[6] = {
    1.0/5.0, 3.0/10.0, 4.0/5.0, 8.0/9.0, 1.0, 1.0
  };

  static const real_T rt_ODE5_B[6][6] = {
    { 1.0/5.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 3.0/40.0, 9.0/40.0, 0.0, 0.0, 0.0, 0.0 },

    { 44.0/45.0, -56.0/15.0, 32.0/9.0, 0.0, 0.0, 0.0 },

    { 19372.0/6561.0, -25360.0/2187.0, 64448.0/6561.0, -212.0/729.0, 0.0, 0.0 },

    { 9017.0/3168.0, -355.0/33.0, 46732.0/5247.0, 49.0/176.0, -5103.0/18656.0,
      0.0 },

    { 35.0/384.0, 0.0, 500.0/1113.0, 125.0/192.0, -2187.0/6784.0, 11.0/84.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE5_IntgData *id = (ODE5_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T *f4 = id->f[4];
  real_T *f5 = id->f[5];
  real_T hB[6];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  optimis_Crane3D_DevDriv_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE5_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[0]);
  rtsiSetdX(si, f1);
  optimis_Crane3D_DevDriv_output();
  optimis_Crane3D_DevDriv_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE5_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[1]);
  rtsiSetdX(si, f2);
  optimis_Crane3D_DevDriv_output();
  optimis_Crane3D_DevDriv_derivatives();

  /* f(:,4) = feval(odefile, t + hA(3), y + f*hB(:,3), args(:)(*)); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE5_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[2]);
  rtsiSetdX(si, f3);
  optimis_Crane3D_DevDriv_output();
  optimis_Crane3D_DevDriv_derivatives();

  /* f(:,5) = feval(odefile, t + hA(4), y + f*hB(:,4), args(:)(*)); */
  for (i = 0; i <= 3; i++) {
    hB[i] = h * rt_ODE5_B[3][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[3]);
  rtsiSetdX(si, f4);
  optimis_Crane3D_DevDriv_output();
  optimis_Crane3D_DevDriv_derivatives();

  /* f(:,6) = feval(odefile, t + hA(5), y + f*hB(:,5), args(:)(*)); */
  for (i = 0; i <= 4; i++) {
    hB[i] = h * rt_ODE5_B[4][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f5);
  optimis_Crane3D_DevDriv_output();
  optimis_Crane3D_DevDriv_derivatives();

  /* tnew = t + hA(6);
     ynew = y + f*hB(:,6); */
  for (i = 0; i <= 5; i++) {
    hB[i] = h * rt_ODE5_B[5][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4] + f5[i]*hB[5]);
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_setpidy(real_T ycurrent, real_T ydest,
  real_T *Kd, real_T *Kp, real_T *Ki, real_T *Kpa)
{
  real_T temp;

  /* MATLAB Function 'setpidy': '<S2>:371' */
  /* '<S2>:371:2' */
  temp = fabs(ycurrent - ydest);
  if (temp == 0.0) {
    /* '<S2>:371:3' */
    /* '<S2>:371:4' */
    *Kd = 0.0;

    /* '<S2>:371:5' */
    *Kp = 0.0;

    /* '<S2>:371:6' */
    *Ki = 0.0;

    /* '<S2>:371:7' */
    *Kpa = 0.0;
  } else if (temp <= 0.02) {
    /* '<S2>:371:8' */
    /* '<S2>:371:9' */
    *Kd = -0.00013983;

    /* '<S2>:371:10' */
    *Kp = 35.0;

    /* '<S2>:371:11' */
    *Ki = 2.0;

    /* '<S2>:371:12' */
    *Kpa = 0.0;
  } else if (temp <= 0.04) {
    /* '<S2>:371:13' */
    /* '<S2>:371:14' */
    *Kd = -0.2543;

    /* '<S2>:371:15' */
    *Kp = 5.1432;

    /* '<S2>:371:16' */
    *Ki = -0.0242;

    /* '<S2>:371:17' */
    *Kpa = 6.7982;
  } else if (temp <= 0.09) {
    /* '<S2>:371:18' */
    /* '<S2>:371:19' */
    *Kd = -0.2515;

    /* '<S2>:371:20' */
    *Kp = 5.1432;

    /* '<S2>:371:21' */
    *Ki = -0.0268;

    /* '<S2>:371:22' */
    *Kpa = 6.7982;
  } else if (temp <= 0.14) {
    /* '<S2>:371:23' */
    /* '<S2>:371:24' */
    *Kd = 0.3539;

    /* '<S2>:371:25' */
    *Kp = 4.2986;

    /* '<S2>:371:26' */
    *Ki = 0.0954;

    /* '<S2>:371:27' */
    *Kpa = 6.9524;
  } else if (temp <= 0.19) {
    /* '<S2>:371:28' */
    /* '<S2>:371:29' */
    *Kd = -0.0808;

    /* '<S2>:371:30' */
    *Kp = 4.2171;

    /* '<S2>:371:31' */
    *Ki = -0.0742;

    /* '<S2>:371:32' */
    *Kpa = 6.7859;
  } else if (temp <= 0.24) {
    /* '<S2>:371:33' */
    /* '<S2>:371:34' */
    *Kd = -0.0762;

    /* '<S2>:371:35' */
    *Kp = 3.5884;

    /* '<S2>:371:36' */
    *Ki = 0.0463;

    /* '<S2>:371:37' */
    *Kpa = 6.6922;
  } else if (temp <= 0.29) {
    /* '<S2>:371:38' */
    /* '<S2>:371:39' */
    *Kd = 0.0659;

    /* '<S2>:371:40' */
    *Kp = 3.4205;

    /* '<S2>:371:41' */
    *Ki = -0.002;

    /* '<S2>:371:42' */
    *Kpa = 6.7035;
  } else if (temp <= 0.34) {
    /* '<S2>:371:43' */
    /* '<S2>:371:44' */
    *Kd = -0.032;

    /* '<S2>:371:45' */
    *Kp = 2.8951;

    /* '<S2>:371:46' */
    *Ki = 0.0262;

    /* '<S2>:371:47' */
    *Kpa = 7.0725;
  } else if (temp <= 0.39) {
    /* '<S2>:371:48' */
    /* '<S2>:371:49' */
    *Kd = 0.0417;

    /* '<S2>:371:50' */
    *Kp = 2.8599;

    /* '<S2>:371:51' */
    *Ki = 0.0234;

    /* '<S2>:371:52' */
    *Kpa = 7.0674;
  } else if (temp <= 0.44) {
    /* '<S2>:371:53' */
    /* '<S2>:371:54' */
    *Kd = 0.042;

    /* '<S2>:371:55' */
    *Kp = 2.7403;

    /* '<S2>:371:56' */
    *Ki = 0.0169;

    /* '<S2>:371:57' */
    *Kpa = 7.0866;
  } else {
    /* '<S2>:371:59' */
    *Kd = 0.1158;

    /* '<S2>:371:60' */
    *Kp = 2.6958;

    /* '<S2>:371:61' */
    *Ki = 0.0135;

    /* '<S2>:371:62' */
    *Kpa = 7.1027;
  }
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_func1_setpidy(real_T ycurrent, real_T ydest)
{
  real_T Kd_l;
  real_T Kp_l;
  real_T Ki_l;
  real_T Kpa_l;

  /* MATLAB Function 'func1_setpidy': '<S2>:396' */
  /* Graphical Function 'func1_setpidy': '<S2>:396' */
  /* '<S2>:397:1' */
  optimis_Crane3D_DevDriv_setpidy(ycurrent, ydest, &Kd_l, &Kp_l, &Ki_l, &Kpa_l);

  /* '<S2>:397:1' */
  optimis_Crane3D_DevDriv_DW.Kd_l = Kd_l;

  /* '<S2>:397:1' */
  optimis_Crane3D_DevDriv_DW.Kp_l = Kp_l;

  /* '<S2>:397:1' */
  optimis_Crane3D_DevDriv_DW.Ki_l = Ki_l;

  /* '<S2>:397:1' */
  optimis_Crane3D_DevDriv_DW.Kpa_l = Kpa_l;
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_setpidx(real_T xcurrent, real_T xdest,
  real_T *Kix, real_T *Kpx, real_T *Kpax)
{
  real_T temp;

  /* MATLAB Function 'setpidx': '<S2>:405' */
  /* '<S2>:405:2' */
  temp = fabs(xcurrent - xdest);
  if (temp == 0.0) {
    /* '<S2>:405:3' */
    /* '<S2>:405:4' */
    *Kix = 0.0;

    /* '<S2>:405:5' */
    *Kpx = 0.0;

    /* '<S2>:405:6' */
    *Kpax = 0.0;
  } else if (temp <= 0.01) {
    /* '<S2>:405:7' */
    /* '<S2>:405:8' */
    *Kix = 0.004;

    /* '<S2>:405:9' */
    *Kpx = 12.0;

    /* '<S2>:405:10' */
    *Kpax = 12.0;
  } else if (temp <= 0.09) {
    /* '<S2>:405:11' */
    /* %used that of 0.05 */
    /* '<S2>:405:12' */
    *Kix = 0.004;

    /* '<S2>:405:13' */
    *Kpx = 7.9;

    /* '<S2>:405:14' */
    *Kpax = 12.0;
  } else if (temp == 0.1) {
    /* '<S2>:405:15' */
    /* '<S2>:405:16' */
    *Kix = 0.0214;

    /* '<S2>:405:17' */
    *Kpx = 5.19131;

    /* '<S2>:405:18' */
    *Kpax = 6.5867;
  } else if (temp <= 0.15) {
    /* '<S2>:405:19' */
    /* '<S2>:405:20' */
    *Kix = 0.00527;

    /* '<S2>:405:21' */
    *Kpx = 4.1917;

    /* '<S2>:405:22' */
    *Kpax = 8.314;
  } else if (temp <= 0.2) {
    /* '<S2>:405:23' */
    /* '<S2>:405:24' */
    *Kix = 0.0053;

    /* '<S2>:405:25' */
    *Kpx = 4.1826;

    /* '<S2>:405:26' */
    *Kpax = 6.8172;
  } else if (temp <= 0.25) {
    /* '<S2>:405:27' */
    /* '<S2>:405:28' */
    *Kix = 0.0155;

    /* '<S2>:405:29' */
    *Kpx = 3.6125;

    /* '<S2>:405:30' */
    *Kpax = 7.1256;
  } else if (temp <= 0.3) {
    /* '<S2>:405:31' */
    /* '<S2>:405:32' */
    *Kix = 0.0155;

    /* '<S2>:405:33' */
    *Kpx = 3.2684;

    /* '<S2>:405:34' */
    *Kpax = 7.1256;
  } else if (temp <= 0.35) {
    /* '<S2>:405:35' */
    /* '<S2>:405:36' */
    *Kix = 0.0152;

    /* '<S2>:405:37' */
    *Kpx = 3.1918;

    /* '<S2>:405:38' */
    *Kpax = 7.1093;
  } else if (temp <= 0.42) {
    /* '<S2>:405:39' */
    /* '<S2>:405:40' */
    *Kix = 0.0082;

    /* '<S2>:405:41' */
    *Kpx = 3.039;

    /* '<S2>:405:42' */
    *Kpax = 7.0203;
  } else {
    /* '<S2>:405:44' */
    *Kix = 0.0078;

    /* '<S2>:405:45' */
    *Kpx = 3.1393;

    /* '<S2>:405:46' */
    *Kpax = 5.232;
  }
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_func1_setpidx(real_T xcurrent, real_T xdest)
{
  real_T Kix_l;
  real_T Kpx_l;
  real_T Kpax_l;

  /* MATLAB Function 'func1_setpidx': '<S2>:408' */
  /* Graphical Function 'func1_setpidx': '<S2>:408' */
  /* '<S2>:409:1' */
  optimis_Crane3D_DevDriv_setpidx(xcurrent, xdest, &Kix_l, &Kpx_l, &Kpax_l);

  /* '<S2>:409:1' */
  optimis_Crane3D_DevDriv_DW.Kix_l = Kix_l;

  /* '<S2>:409:1' */
  optimis_Crane3D_DevDriv_DW.Kpx_l = Kpx_l;

  /* '<S2>:409:1' */
  optimis_Crane3D_DevDriv_DW.Kpax_l = Kpax_l;
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_func2_CheckArrival(real_T currentx, real_T
  currenty, real_T xdest, real_T ydest)
{
  boolean_T sf_internal_predicateOutput;

  /* MATLAB Function 'func2_CheckArrival': '<S2>:48' */
  /* Graphical Function 'func2_CheckArrival': '<S2>:48' */
  /*  checks for steady state */
  if ((fabs(xdest - currentx) <= 0.01) && (fabs(ydest - currenty) <= 0.01)) {
    /* '<S2>:54:1' */
    sf_internal_predicateOutput = true;
  } else {
    /* '<S2>:54:1' */
    sf_internal_predicateOutput = false;
  }

  if (sf_internal_predicateOutput) {
    /* '<S2>:54:1' */
    /* '<S2>:56:1' */
    optimis_Crane3D_DevDriv_DW.arrived = 1.0;
  } else {
    /* '<S2>:55:1' */
    optimis_Crane3D_DevDriv_DW.arrived = 0.0;
  }
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_func3_CheckDone(real_T count, real_T total)
{
  /* MATLAB Function 'func3_CheckDone': '<S2>:129' */
  /* Graphical Function 'func3_CheckDone': '<S2>:129' */
  /* '<S2>:142:1' */
  if (count > total) {
    /* '<S2>:144:1' */
    optimis_Crane3D_DevDriv_DW.finished = 1.0;
  } else {
    /* '<S2>:143:1' */
    optimis_Crane3D_DevDriv_DW.finished = 0.0;
  }
}

/* Model output function */
void optimis_Crane3D_DevDriv_output(void)
{
  real_T *lastU;
  real_T rtb_Encoder500PPR[5];
  real_T rtb_Sum_n;
  real_T rtb_Saturation;
  int32_T i;
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* set solver stop time */
    if (!(optimis_Crane3D_DevDriv_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&optimis_Crane3D_DevDriv_M->solverInfo,
                            ((optimis_Crane3D_DevDriv_M->Timing.clockTickH0 + 1)
        * optimis_Crane3D_DevDriv_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&optimis_Crane3D_DevDriv_M->solverInfo,
                            ((optimis_Crane3D_DevDriv_M->Timing.clockTick0 + 1) *
        optimis_Crane3D_DevDriv_M->Timing.stepSize0 +
        optimis_Crane3D_DevDriv_M->Timing.clockTickH0 *
        optimis_Crane3D_DevDriv_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(optimis_Crane3D_DevDriv_M)) {
    optimis_Crane3D_DevDriv_M->Timing.t[0] = rtsiGetT
      (&optimis_Crane3D_DevDriv_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Constant: '<Root>/start_course' */
    optimis_Crane3D_DevDriv_B.start_course =
      optimis_Crane3D_DevDriv_P.start_course;
    for (i = 0; i < 6; i++) {
      /* Constant: '<Root>/xwaypoints' */
      optimis_Crane3D_DevDriv_B.xwaypoints[i] =
        optimis_Crane3D_DevDriv_P.xwaypoints[i];

      /* Constant: '<Root>/ywaypoints ' */
      optimis_Crane3D_DevDriv_B.ywaypoints[i] =
        optimis_Crane3D_DevDriv_P.ywaypoints[i];
    }

    /* Constant: '<Root>/total_waypoints ' */
    optimis_Crane3D_DevDriv_B.total_waypoints =
      optimis_Crane3D_DevDriv_P.total_waypoints;

    /* Level2 S-Function Block: '<S1>/Encoder' (Crane3D_Encoder) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[0];
      sfcnOutputs(rts, 1);
    }

    /* Gain: '<S1>/Encoder 500PPR' */
    for (i = 0; i < 5; i++) {
      rtb_Encoder500PPR[i] = optimis_Crane3D_DevDriv_P.Encoder500PPR_Gain *
        optimis_Crane3D_DevDriv_B.Encoder[i];
    }

    /* End of Gain: '<S1>/Encoder 500PPR' */

    /* Gain: '<S1>/X Scale' */
    optimis_Crane3D_DevDriv_B.XScale = optimis_Crane3D_DevDriv_P.XScale_Gain *
      rtb_Encoder500PPR[0];

    /* Constant: '<Root>/settling_time ' */
    optimis_Crane3D_DevDriv_B.settling_time =
      optimis_Crane3D_DevDriv_P.settling_time_Value;

    /* Gain: '<S1>/Y Scale' */
    optimis_Crane3D_DevDriv_B.YScale = optimis_Crane3D_DevDriv_P.YScale_Gain *
      rtb_Encoder500PPR[1];

    /* Chart: '<Root>/HL Controller' */
    if (optimis_Crane3D_DevDriv_DW.temporalCounter_i1 < MAX_uint32_T) {
      optimis_Crane3D_DevDriv_DW.temporalCounter_i1++;
    }

    /* Gateway: HL Controller */
    optimis_Crane3D_DevDriv_DW.sfEvent = optimis_Crane3D_DevDriv_CALL_EVENT;

    /* During: HL Controller */
    if (optimis_Crane3D_DevDriv_DW.is_active_c3_optimis_Crane3D_DevDriv == 0U) {
      /* Entry: HL Controller */
      optimis_Crane3D_DevDriv_DW.is_active_c3_optimis_Crane3D_DevDriv = 1U;

      /* Entry Internal: HL Controller */
      /* Transition: '<S2>:3' */
      optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
        optimis_Crane3D_DevDriv_IN_Idle;

      /* Entry 'Idle': '<S2>:1' */
      optimis_Crane3D_DevDriv_DW.xlocal = 0.0;
      optimis_Crane3D_DevDriv_DW.ylocal = 0.0;
      optimis_Crane3D_DevDriv_B.done = 0.0;
      optimis_Crane3D_DevDriv_DW.index = 1.0;
      optimis_Crane3D_DevDriv_DW.Kd_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Kp_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Ki_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Kpa_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Kix_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Kpx_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Kpax_l = 0.0;
    } else {
      switch (optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv) {
       case optimis_Crane3D_DevDriv_IN_Idle:
        /* During 'Idle': '<S2>:1' */
        if (optimis_Crane3D_DevDriv_B.start_course == 1.0) {
          /* Transition: '<S2>:158' */
          /* Exit 'Idle': '<S2>:1' */
          optimis_Crane3D_DevDriv_B.close_switch = 0.0;
          optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
            optimis_Crane3D_DevDriv_IN_S1_initialize;

          /* Entry Internal 'S1_initialize': '<S2>:26' */
          optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidy = 1U;

          /* Entry 'S1_setup_pidy': '<S2>:328' */
          optimis_Crane3D_DevDriv_func1_setpidy(optimis_Crane3D_DevDriv_B.YScale,
            optimis_Crane3D_DevDriv_B.ywaypoints[(int32_T)
            optimis_Crane3D_DevDriv_DW.index - 1]);
          optimis_Crane3D_DevDriv_DW.is_active_S1_setpoints = 1U;

          /* Entry 'S1_setpoints': '<S2>:334' */
          optimis_Crane3D_DevDriv_DW.xlocal =
            optimis_Crane3D_DevDriv_B.xwaypoints[(int32_T)
            optimis_Crane3D_DevDriv_DW.index - 1];
          optimis_Crane3D_DevDriv_DW.ylocal =
            optimis_Crane3D_DevDriv_B.ywaypoints[(int32_T)
            optimis_Crane3D_DevDriv_DW.index - 1];
          optimis_Crane3D_DevDriv_DW.arrived = 0.0;
          optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidx = 1U;

          /* Entry 'S1_setup_pidx': '<S2>:411' */
          optimis_Crane3D_DevDriv_func1_setpidx(optimis_Crane3D_DevDriv_B.XScale,
            optimis_Crane3D_DevDriv_B.xwaypoints[(int32_T)
            optimis_Crane3D_DevDriv_DW.index - 1]);
        }
        break;

       case optimis_Crane3D_DevDriv_IN_S1_initialize:
        /* During 'S1_initialize': '<S2>:26' */
        /* Transition: '<S2>:43' */
        /* Exit Internal 'S1_initialize': '<S2>:26' */
        optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidx = 0U;
        optimis_Crane3D_DevDriv_DW.is_active_S1_setpoints = 0U;
        optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidy = 0U;
        optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
          optimis_Crane3D_DevDriv_IN_S2_move_it;

        /* Entry 'S2_move_it': '<S2>:42' */
        optimis_Crane3D_DevDriv_B.xref = optimis_Crane3D_DevDriv_DW.xlocal;
        optimis_Crane3D_DevDriv_B.yref = optimis_Crane3D_DevDriv_DW.ylocal;
        optimis_Crane3D_DevDriv_B.at_waypoint = 0.0;
        optimis_Crane3D_DevDriv_B.Kdy = optimis_Crane3D_DevDriv_DW.Kd_l;
        optimis_Crane3D_DevDriv_B.Kpy = optimis_Crane3D_DevDriv_DW.Kp_l;
        optimis_Crane3D_DevDriv_B.Kiy = optimis_Crane3D_DevDriv_DW.Ki_l;
        optimis_Crane3D_DevDriv_B.Kpay = optimis_Crane3D_DevDriv_DW.Kpa_l;
        optimis_Crane3D_DevDriv_B.kix = optimis_Crane3D_DevDriv_DW.Kix_l;
        optimis_Crane3D_DevDriv_B.kpx = optimis_Crane3D_DevDriv_DW.Kpx_l;
        optimis_Crane3D_DevDriv_B.kpax = optimis_Crane3D_DevDriv_DW.Kpax_l;
        break;

       case optimis_Crane3D_DevDriv_IN_S2_move_it:
        /* During 'S2_move_it': '<S2>:42' */
        /* Transition: '<S2>:385' */
        /* Exit 'S2_move_it': '<S2>:42' */
        optimis_Crane3D_DevDriv_B.close_switch = 1.0;
        optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
          optimis_Crane3D_DevDriv_IN_S3_new_input;
        optimis_Crane3D_DevDriv_DW.temporalCounter_i1 = 0U;

        /* Entry 'S3_new_input': '<S2>:68' */
        optimis_Crane3D_DevDriv_DW.arrived = 0.0;
        break;

       case optimis_Crane3D_DevDriv_IN_S3_new_input:
        /* During 'S3_new_input': '<S2>:68' */
        if (optimis_Crane3D_DevDriv_DW.temporalCounter_i1 >= (uint32_T)ceil
            (optimis_Crane3D_DevDriv_B.settling_time / 0.01 - 1.0E-10)) {
          /* Transition: '<S2>:86' */
          optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
            optimis_Crane3D_DevDriv_IN_S4_wait1;

          /* Entry 'S4_wait1': '<S2>:84' */
          optimis_Crane3D_DevDriv_DW.index++;
          optimis_Crane3D_DevDriv_B.at_waypoint =
            optimis_Crane3D_DevDriv_DW.arrived;
        } else {
          optimis_Crane3D_DevDriv_func2_CheckArrival
            (optimis_Crane3D_DevDriv_B.XScale, optimis_Crane3D_DevDriv_B.YScale,
             optimis_Crane3D_DevDriv_DW.xlocal,
             optimis_Crane3D_DevDriv_DW.ylocal);
        }
        break;

       case optimis_Crane3D_DevDriv_IN_S4_wait1:
        /* During 'S4_wait1': '<S2>:84' */
        /* Transition: '<S2>:118' */
        optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
          optimis_Crane3D_DevDriv_IN_S5_checkifdone;

        /* Entry 'S5_checkifdone': '<S2>:117' */
        optimis_Crane3D_DevDriv_func3_CheckDone(optimis_Crane3D_DevDriv_DW.index,
          optimis_Crane3D_DevDriv_B.total_waypoints);
        break;

       case optimis_Crane3D_DevDriv_IN_S5_checkifdone:
        /* During 'S5_checkifdone': '<S2>:117' */
        if (optimis_Crane3D_DevDriv_DW.finished == 1.0) {
          /* Transition: '<S2>:156' */
          optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
            optimis_Crane3D_DevDriv_IN_S6_done;

          /* Entry 'S6_done': '<S2>:154' */
          optimis_Crane3D_DevDriv_B.done = 1.0;
        } else {
          if (optimis_Crane3D_DevDriv_DW.finished == 0.0) {
            /* Transition: '<S2>:157' */
            optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
              optimis_Crane3D_DevDriv_IN_S1_initialize;

            /* Entry Internal 'S1_initialize': '<S2>:26' */
            optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidy = 1U;

            /* Entry 'S1_setup_pidy': '<S2>:328' */
            optimis_Crane3D_DevDriv_func1_setpidy
              (optimis_Crane3D_DevDriv_B.YScale,
               optimis_Crane3D_DevDriv_B.ywaypoints[(int32_T)
               optimis_Crane3D_DevDriv_DW.index - 1]);
            optimis_Crane3D_DevDriv_DW.is_active_S1_setpoints = 1U;

            /* Entry 'S1_setpoints': '<S2>:334' */
            optimis_Crane3D_DevDriv_DW.xlocal =
              optimis_Crane3D_DevDriv_B.xwaypoints[(int32_T)
              optimis_Crane3D_DevDriv_DW.index - 1];
            optimis_Crane3D_DevDriv_DW.ylocal =
              optimis_Crane3D_DevDriv_B.ywaypoints[(int32_T)
              optimis_Crane3D_DevDriv_DW.index - 1];
            optimis_Crane3D_DevDriv_DW.arrived = 0.0;
            optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidx = 1U;

            /* Entry 'S1_setup_pidx': '<S2>:411' */
            optimis_Crane3D_DevDriv_func1_setpidx
              (optimis_Crane3D_DevDriv_B.XScale,
               optimis_Crane3D_DevDriv_B.xwaypoints[(int32_T)
               optimis_Crane3D_DevDriv_DW.index - 1]);
          }
        }
        break;

       default:
        /* During 'S6_done': '<S2>:154' */
        break;
      }
    }

    /* End of Chart: '<Root>/HL Controller' */

    /* Gain: '<S1>/X Angle Scale' */
    optimis_Crane3D_DevDriv_B.XAngleScale =
      optimis_Crane3D_DevDriv_P.XAngleScale_Gain * rtb_Encoder500PPR[3];

    /* Gain: '<S1>/Y Angle Scale' */
    optimis_Crane3D_DevDriv_B.YAngleScale =
      optimis_Crane3D_DevDriv_P.YAngleScale_Gain * rtb_Encoder500PPR[4];

    /* Sum: '<Root>/Sum' */
    rtb_Sum_n = optimis_Crane3D_DevDriv_B.xref -
      optimis_Crane3D_DevDriv_B.XScale;

    /* Product: '<S3>/Product2' */
    optimis_Crane3D_DevDriv_B.Product2 = optimis_Crane3D_DevDriv_B.kpx *
      rtb_Sum_n;
  }

  /* Integrator: '<S3>/Integrator' */
  /* Limited  Integrator  */
  if (optimis_Crane3D_DevDriv_X.Integrator_CSTATE >=
      optimis_Crane3D_DevDriv_P.Integrator_UpperSat) {
    optimis_Crane3D_DevDriv_X.Integrator_CSTATE =
      optimis_Crane3D_DevDriv_P.Integrator_UpperSat;
  } else {
    if (optimis_Crane3D_DevDriv_X.Integrator_CSTATE <=
        optimis_Crane3D_DevDriv_P.Integrator_LowerSat) {
      optimis_Crane3D_DevDriv_X.Integrator_CSTATE =
        optimis_Crane3D_DevDriv_P.Integrator_LowerSat;
    }
  }

  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Product: '<S3>/Product1' incorporates:
     *  Constant: '<Root>/Constant'
     */
    optimis_Crane3D_DevDriv_B.Product1 = rtb_Sum_n *
      optimis_Crane3D_DevDriv_P.Constant_Value;
  }

  /* Derivative: '<S3>/Derivative' */
  if ((optimis_Crane3D_DevDriv_DW.TimeStampA >=
       optimis_Crane3D_DevDriv_M->Timing.t[0]) &&
      (optimis_Crane3D_DevDriv_DW.TimeStampB >=
       optimis_Crane3D_DevDriv_M->Timing.t[0])) {
    rtb_Saturation = 0.0;
  } else {
    rtb_Saturation = optimis_Crane3D_DevDriv_DW.TimeStampA;
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA;
    if (optimis_Crane3D_DevDriv_DW.TimeStampA <
        optimis_Crane3D_DevDriv_DW.TimeStampB) {
      if (optimis_Crane3D_DevDriv_DW.TimeStampB <
          optimis_Crane3D_DevDriv_M->Timing.t[0]) {
        rtb_Saturation = optimis_Crane3D_DevDriv_DW.TimeStampB;
        lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB;
      }
    } else {
      if (optimis_Crane3D_DevDriv_DW.TimeStampA >=
          optimis_Crane3D_DevDriv_M->Timing.t[0]) {
        rtb_Saturation = optimis_Crane3D_DevDriv_DW.TimeStampB;
        lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB;
      }
    }

    rtb_Saturation = (optimis_Crane3D_DevDriv_B.Product1 - *lastU) /
      (optimis_Crane3D_DevDriv_M->Timing.t[0] - rtb_Saturation);
  }

  /* End of Derivative: '<S3>/Derivative' */
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Product: '<Root>/Product' */
    optimis_Crane3D_DevDriv_B.Product = optimis_Crane3D_DevDriv_B.XAngleScale *
      optimis_Crane3D_DevDriv_B.kpax;
  }

  /* Sum: '<Root>/Add' incorporates:
   *  Integrator: '<S3>/Integrator'
   *  Sum: '<S3>/Sum'
   */
  optimis_Crane3D_DevDriv_B.Add = ((optimis_Crane3D_DevDriv_B.Product2 +
    optimis_Crane3D_DevDriv_X.Integrator_CSTATE) + rtb_Saturation) +
    optimis_Crane3D_DevDriv_B.Product;
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Sum: '<Root>/Sum1' */
    optimis_Crane3D_DevDriv_B.Sum1 = optimis_Crane3D_DevDriv_B.yref -
      optimis_Crane3D_DevDriv_B.YScale;

    /* Product: '<S4>/Product2' */
    optimis_Crane3D_DevDriv_B.Product2_k = optimis_Crane3D_DevDriv_B.Kpy *
      optimis_Crane3D_DevDriv_B.Sum1;
  }

  /* Integrator: '<S4>/Integrator' */
  /* Limited  Integrator  */
  if (optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f >=
      optimis_Crane3D_DevDriv_P.Integrator_UpperSat_g) {
    optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f =
      optimis_Crane3D_DevDriv_P.Integrator_UpperSat_g;
  } else {
    if (optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f <=
        optimis_Crane3D_DevDriv_P.Integrator_LowerSat_d) {
      optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f =
        optimis_Crane3D_DevDriv_P.Integrator_LowerSat_d;
    }
  }

  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Product: '<S4>/Product1' */
    optimis_Crane3D_DevDriv_B.Product1_i = optimis_Crane3D_DevDriv_B.Sum1 *
      optimis_Crane3D_DevDriv_B.Kdy;
  }

  /* Derivative: '<S4>/Derivative' */
  if ((optimis_Crane3D_DevDriv_DW.TimeStampA_o >=
       optimis_Crane3D_DevDriv_M->Timing.t[0]) &&
      (optimis_Crane3D_DevDriv_DW.TimeStampB_c >=
       optimis_Crane3D_DevDriv_M->Timing.t[0])) {
    rtb_Saturation = 0.0;
  } else {
    rtb_Saturation = optimis_Crane3D_DevDriv_DW.TimeStampA_o;
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA_i;
    if (optimis_Crane3D_DevDriv_DW.TimeStampA_o <
        optimis_Crane3D_DevDriv_DW.TimeStampB_c) {
      if (optimis_Crane3D_DevDriv_DW.TimeStampB_c <
          optimis_Crane3D_DevDriv_M->Timing.t[0]) {
        rtb_Saturation = optimis_Crane3D_DevDriv_DW.TimeStampB_c;
        lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB_o;
      }
    } else {
      if (optimis_Crane3D_DevDriv_DW.TimeStampA_o >=
          optimis_Crane3D_DevDriv_M->Timing.t[0]) {
        rtb_Saturation = optimis_Crane3D_DevDriv_DW.TimeStampB_c;
        lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB_o;
      }
    }

    rtb_Saturation = (optimis_Crane3D_DevDriv_B.Product1_i - *lastU) /
      (optimis_Crane3D_DevDriv_M->Timing.t[0] - rtb_Saturation);
  }

  /* End of Derivative: '<S4>/Derivative' */
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Product: '<Root>/Product1' */
    optimis_Crane3D_DevDriv_B.Product1_ik = optimis_Crane3D_DevDriv_B.Kpay *
      optimis_Crane3D_DevDriv_B.YAngleScale;
  }

  /* Sum: '<Root>/Add1' incorporates:
   *  Integrator: '<S4>/Integrator'
   *  Sum: '<S4>/Sum'
   */
  optimis_Crane3D_DevDriv_B.Add1 = ((optimis_Crane3D_DevDriv_B.Product2_k +
    optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f) + rtb_Saturation) +
    optimis_Crane3D_DevDriv_B.Product1_ik;
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Stop: '<Root>/Stop Simulation' */
    if (optimis_Crane3D_DevDriv_B.done != 0.0) {
      rtmSetStopRequested(optimis_Crane3D_DevDriv_M, 1);
    }

    /* End of Stop: '<Root>/Stop Simulation' */

    /* Level2 S-Function Block: '<S1>/PWM' (Crane3D_PWM) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[1];
      sfcnOutputs(rts, 1);
    }
  }

  /* Switch: '<Root>/Switch' incorporates:
   *  Constant: '<Root>/Constant'
   */
  if (optimis_Crane3D_DevDriv_B.close_switch >
      optimis_Crane3D_DevDriv_P.Switch_Threshold) {
    rtb_Saturation = optimis_Crane3D_DevDriv_B.Add;
  } else {
    rtb_Saturation = optimis_Crane3D_DevDriv_P.Constant_Value;
  }

  /* End of Switch: '<Root>/Switch' */

  /* Saturate: '<Root>/Saturation' */
  if (rtb_Saturation > optimis_Crane3D_DevDriv_P.Saturation_UpperSat) {
    rtb_Saturation = optimis_Crane3D_DevDriv_P.Saturation_UpperSat;
  } else {
    if (rtb_Saturation < optimis_Crane3D_DevDriv_P.Saturation_LowerSat) {
      rtb_Saturation = optimis_Crane3D_DevDriv_P.Saturation_LowerSat;
    }
  }

  /* End of Saturate: '<Root>/Saturation' */

  /* Saturate: '<S1>/Saturation' */
  if (rtb_Saturation > optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j) {
    optimis_Crane3D_DevDriv_B.Saturation[0] =
      optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j;
  } else if (rtb_Saturation < optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l) {
    optimis_Crane3D_DevDriv_B.Saturation[0] =
      optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l;
  } else {
    optimis_Crane3D_DevDriv_B.Saturation[0] = rtb_Saturation;
  }

  /* Switch: '<Root>/Switch1' incorporates:
   *  Constant: '<Root>/Constant'
   */
  if (optimis_Crane3D_DevDriv_B.close_switch >
      optimis_Crane3D_DevDriv_P.Switch1_Threshold) {
    rtb_Saturation = optimis_Crane3D_DevDriv_B.Add1;
  } else {
    rtb_Saturation = optimis_Crane3D_DevDriv_P.Constant_Value;
  }

  /* End of Switch: '<Root>/Switch1' */

  /* Saturate: '<Root>/Saturation1' */
  if (rtb_Saturation > optimis_Crane3D_DevDriv_P.Saturation1_UpperSat) {
    rtb_Saturation = optimis_Crane3D_DevDriv_P.Saturation1_UpperSat;
  } else {
    if (rtb_Saturation < optimis_Crane3D_DevDriv_P.Saturation1_LowerSat) {
      rtb_Saturation = optimis_Crane3D_DevDriv_P.Saturation1_LowerSat;
    }
  }

  /* End of Saturate: '<Root>/Saturation1' */

  /* Saturate: '<S1>/Saturation' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  if (rtb_Saturation > optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j) {
    optimis_Crane3D_DevDriv_B.Saturation[1] =
      optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j;
  } else if (rtb_Saturation < optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l) {
    optimis_Crane3D_DevDriv_B.Saturation[1] =
      optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l;
  } else {
    optimis_Crane3D_DevDriv_B.Saturation[1] = rtb_Saturation;
  }

  if (optimis_Crane3D_DevDriv_P.Constant2_Value >
      optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j) {
    optimis_Crane3D_DevDriv_B.Saturation[2] =
      optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j;
  } else if (optimis_Crane3D_DevDriv_P.Constant2_Value <
             optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l) {
    optimis_Crane3D_DevDriv_B.Saturation[2] =
      optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l;
  } else {
    optimis_Crane3D_DevDriv_B.Saturation[2] =
      optimis_Crane3D_DevDriv_P.Constant2_Value;
  }

  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Level2 S-Function Block: '<S1>/LimitFlag' (Crane3D_LimitFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[2];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[0] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[0];

    /* Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[0] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[0];

    /* Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[1] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[1];

    /* Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[1] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[1];

    /* Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[2] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[2];

    /* Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[2] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[2];

    /* Level2 S-Function Block: '<S1>/SetLimit' (Crane3D_SetLimit) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[3];
      sfcnOutputs(rts, 1);
    }

    /* Level2 S-Function Block: '<S1>/LimitSwitch' (Crane3D_Switch) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[4];
      sfcnOutputs(rts, 1);
    }

    /* Level2 S-Function Block: '<S1>/PWMPrescaler' (Crane3D_PWMPrescaler) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[5];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/PWMPrescalerSource' */
    optimis_Crane3D_DevDriv_B.PWMPrescalerSource =
      optimis_Crane3D_DevDriv_P.PWMPrescalerSource_Value;

    /* Level2 S-Function Block: '<S1>/ResetEncoder' (Crane3D_ResetEncoder) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[6];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/ResetSource' */
    for (i = 0; i < 5; i++) {
      optimis_Crane3D_DevDriv_B.ResetSource[i] =
        optimis_Crane3D_DevDriv_P.ResetSource_Value[i];
    }

    /* End of Constant: '<S1>/ResetSource' */

    /* Level2 S-Function Block: '<S1>/ResetSwitchFlag ' (Crane3D_ResetSwitchFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[7];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/ResetSwitchFlagSource' */
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[0] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[0];
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[1] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[1];
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[2] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[2];

    /* Level2 S-Function Block: '<S1>/ThermFlag ' (Crane3D_ThermFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[8];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/ThermFlagSource' */
    optimis_Crane3D_DevDriv_B.ThermFlagSource[0] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[0];
    optimis_Crane3D_DevDriv_B.ThermFlagSource[1] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[1];
    optimis_Crane3D_DevDriv_B.ThermFlagSource[2] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[2];

    /* Product: '<S3>/Product' */
    optimis_Crane3D_DevDriv_B.Product_f = optimis_Crane3D_DevDriv_B.kix *
      rtb_Sum_n;

    /* Product: '<S4>/Product' */
    optimis_Crane3D_DevDriv_B.Product_c = optimis_Crane3D_DevDriv_B.Kiy *
      optimis_Crane3D_DevDriv_B.Sum1;
  }

  /* Clock: '<Root>/Clock' */
  optimis_Crane3D_DevDriv_B.Clock = optimis_Crane3D_DevDriv_M->Timing.t[0];
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
  }
}

/* Model update function */
void optimis_Crane3D_DevDriv_update(void)
{
  real_T *lastU;

  /* Update for Derivative: '<S3>/Derivative' */
  if (optimis_Crane3D_DevDriv_DW.TimeStampA == (rtInf)) {
    optimis_Crane3D_DevDriv_DW.TimeStampA = optimis_Crane3D_DevDriv_M->Timing.t
      [0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA;
  } else if (optimis_Crane3D_DevDriv_DW.TimeStampB == (rtInf)) {
    optimis_Crane3D_DevDriv_DW.TimeStampB = optimis_Crane3D_DevDriv_M->Timing.t
      [0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB;
  } else if (optimis_Crane3D_DevDriv_DW.TimeStampA <
             optimis_Crane3D_DevDriv_DW.TimeStampB) {
    optimis_Crane3D_DevDriv_DW.TimeStampA = optimis_Crane3D_DevDriv_M->Timing.t
      [0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA;
  } else {
    optimis_Crane3D_DevDriv_DW.TimeStampB = optimis_Crane3D_DevDriv_M->Timing.t
      [0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB;
  }

  *lastU = optimis_Crane3D_DevDriv_B.Product1;

  /* End of Update for Derivative: '<S3>/Derivative' */

  /* Update for Derivative: '<S4>/Derivative' */
  if (optimis_Crane3D_DevDriv_DW.TimeStampA_o == (rtInf)) {
    optimis_Crane3D_DevDriv_DW.TimeStampA_o =
      optimis_Crane3D_DevDriv_M->Timing.t[0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA_i;
  } else if (optimis_Crane3D_DevDriv_DW.TimeStampB_c == (rtInf)) {
    optimis_Crane3D_DevDriv_DW.TimeStampB_c =
      optimis_Crane3D_DevDriv_M->Timing.t[0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB_o;
  } else if (optimis_Crane3D_DevDriv_DW.TimeStampA_o <
             optimis_Crane3D_DevDriv_DW.TimeStampB_c) {
    optimis_Crane3D_DevDriv_DW.TimeStampA_o =
      optimis_Crane3D_DevDriv_M->Timing.t[0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA_i;
  } else {
    optimis_Crane3D_DevDriv_DW.TimeStampB_c =
      optimis_Crane3D_DevDriv_M->Timing.t[0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB_o;
  }

  *lastU = optimis_Crane3D_DevDriv_B.Product1_i;

  /* End of Update for Derivative: '<S4>/Derivative' */
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    rt_ertODEUpdateContinuousStates(&optimis_Crane3D_DevDriv_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++optimis_Crane3D_DevDriv_M->Timing.clockTick0)) {
    ++optimis_Crane3D_DevDriv_M->Timing.clockTickH0;
  }

  optimis_Crane3D_DevDriv_M->Timing.t[0] = rtsiGetSolverStopTime
    (&optimis_Crane3D_DevDriv_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++optimis_Crane3D_DevDriv_M->Timing.clockTick1)) {
      ++optimis_Crane3D_DevDriv_M->Timing.clockTickH1;
    }

    optimis_Crane3D_DevDriv_M->Timing.t[1] =
      optimis_Crane3D_DevDriv_M->Timing.clockTick1 *
      optimis_Crane3D_DevDriv_M->Timing.stepSize1 +
      optimis_Crane3D_DevDriv_M->Timing.clockTickH1 *
      optimis_Crane3D_DevDriv_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void optimis_Crane3D_DevDriv_derivatives(void)
{
  boolean_T lsat;
  boolean_T usat;
  XDot_optimis_Crane3D_DevDriv_T *_rtXdot;
  _rtXdot = ((XDot_optimis_Crane3D_DevDriv_T *)
             optimis_Crane3D_DevDriv_M->ModelData.derivs);

  /* Derivatives for Integrator: '<S3>/Integrator' */
  lsat = (optimis_Crane3D_DevDriv_X.Integrator_CSTATE <=
          optimis_Crane3D_DevDriv_P.Integrator_LowerSat);
  usat = (optimis_Crane3D_DevDriv_X.Integrator_CSTATE >=
          optimis_Crane3D_DevDriv_P.Integrator_UpperSat);
  if (((!lsat) && (!usat)) || (lsat && (optimis_Crane3D_DevDriv_B.Product_f >
        0.0)) || (usat && (optimis_Crane3D_DevDriv_B.Product_f < 0.0))) {
    _rtXdot->Integrator_CSTATE = optimis_Crane3D_DevDriv_B.Product_f;
  } else {
    /* in saturation */
    _rtXdot->Integrator_CSTATE = 0.0;
  }

  /* End of Derivatives for Integrator: '<S3>/Integrator' */

  /* Derivatives for Integrator: '<S4>/Integrator' */
  lsat = (optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f <=
          optimis_Crane3D_DevDriv_P.Integrator_LowerSat_d);
  usat = (optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f >=
          optimis_Crane3D_DevDriv_P.Integrator_UpperSat_g);
  if (((!lsat) && (!usat)) || (lsat && (optimis_Crane3D_DevDriv_B.Product_c >
        0.0)) || (usat && (optimis_Crane3D_DevDriv_B.Product_c < 0.0))) {
    _rtXdot->Integrator_CSTATE_f = optimis_Crane3D_DevDriv_B.Product_c;
  } else {
    /* in saturation */
    _rtXdot->Integrator_CSTATE_f = 0.0;
  }

  /* End of Derivatives for Integrator: '<S4>/Integrator' */
}

/* Model initialize function */
void optimis_Crane3D_DevDriv_initialize(void)
{
  {
    int32_T i;

    /* Start for Constant: '<Root>/start_course' */
    optimis_Crane3D_DevDriv_B.start_course =
      optimis_Crane3D_DevDriv_P.start_course;
    for (i = 0; i < 6; i++) {
      /* Start for Constant: '<Root>/xwaypoints' */
      optimis_Crane3D_DevDriv_B.xwaypoints[i] =
        optimis_Crane3D_DevDriv_P.xwaypoints[i];

      /* Start for Constant: '<Root>/ywaypoints ' */
      optimis_Crane3D_DevDriv_B.ywaypoints[i] =
        optimis_Crane3D_DevDriv_P.ywaypoints[i];
    }

    /* Start for Constant: '<Root>/total_waypoints ' */
    optimis_Crane3D_DevDriv_B.total_waypoints =
      optimis_Crane3D_DevDriv_P.total_waypoints;

    /* Start for Constant: '<Root>/settling_time ' */
    optimis_Crane3D_DevDriv_B.settling_time =
      optimis_Crane3D_DevDriv_P.settling_time_Value;

    /* Start for Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[0] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[0];

    /* Start for Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[0] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[0];

    /* Start for Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[1] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[1];

    /* Start for Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[1] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[1];

    /* Start for Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[2] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[2];

    /* Start for Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[2] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[2];

    /* Start for Constant: '<S1>/PWMPrescalerSource' */
    optimis_Crane3D_DevDriv_B.PWMPrescalerSource =
      optimis_Crane3D_DevDriv_P.PWMPrescalerSource_Value;

    /* Start for Constant: '<S1>/ResetSource' */
    for (i = 0; i < 5; i++) {
      optimis_Crane3D_DevDriv_B.ResetSource[i] =
        optimis_Crane3D_DevDriv_P.ResetSource_Value[i];
    }

    /* End of Start for Constant: '<S1>/ResetSource' */
    /* Start for Constant: '<S1>/ResetSwitchFlagSource' */
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[0] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[0];
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[1] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[1];
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[2] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[2];

    /* Start for Constant: '<S1>/ThermFlagSource' */
    optimis_Crane3D_DevDriv_B.ThermFlagSource[0] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[0];
    optimis_Crane3D_DevDriv_B.ThermFlagSource[1] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[1];
    optimis_Crane3D_DevDriv_B.ThermFlagSource[2] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[2];
  }

  /* InitializeConditions for Integrator: '<S3>/Integrator' */
  optimis_Crane3D_DevDriv_X.Integrator_CSTATE =
    optimis_Crane3D_DevDriv_P.Integrator_IC;

  /* InitializeConditions for Derivative: '<S3>/Derivative' */
  optimis_Crane3D_DevDriv_DW.TimeStampA = (rtInf);
  optimis_Crane3D_DevDriv_DW.TimeStampB = (rtInf);

  /* InitializeConditions for Integrator: '<S4>/Integrator' */
  optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f =
    optimis_Crane3D_DevDriv_P.Integrator_IC_a;

  /* InitializeConditions for Derivative: '<S4>/Derivative' */
  optimis_Crane3D_DevDriv_DW.TimeStampA_o = (rtInf);
  optimis_Crane3D_DevDriv_DW.TimeStampB_c = (rtInf);

  /* SystemInitialize for Chart: '<Root>/HL Controller' */
  optimis_Crane3D_DevDriv_DW.sfEvent = optimis_Crane3D_DevDriv_CALL_EVENT;
  optimis_Crane3D_DevDriv_DW.is_active_S1_setpoints = 0U;
  optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidx = 0U;
  optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidy = 0U;
  optimis_Crane3D_DevDriv_DW.temporalCounter_i1 = 0U;
  optimis_Crane3D_DevDriv_DW.is_active_c3_optimis_Crane3D_DevDriv = 0U;
  optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
    optimis_Crane3D_DevDriv_IN_NO_ACTIVE_CHILD;
  optimis_Crane3D_DevDriv_DW.ready = 0.0;
  optimis_Crane3D_DevDriv_DW.index = 1.0;
  optimis_Crane3D_DevDriv_DW.initialized = 0.0;
  optimis_Crane3D_DevDriv_DW.arrived = 0.0;
  optimis_Crane3D_DevDriv_DW.finished = -1.0;
  optimis_Crane3D_DevDriv_B.done = 0.0;
  optimis_Crane3D_DevDriv_B.close_switch = 0.0;
}

/* Model terminate function */
void optimis_Crane3D_DevDriv_terminate(void)
{
  /* Level2 S-Function Block: '<S1>/Encoder' (Crane3D_Encoder) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/PWM' (Crane3D_PWM) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/LimitFlag' (Crane3D_LimitFlag) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/SetLimit' (Crane3D_SetLimit) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/LimitSwitch' (Crane3D_Switch) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/PWMPrescaler' (Crane3D_PWMPrescaler) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[5];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/ResetEncoder' (Crane3D_ResetEncoder) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[6];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/ResetSwitchFlag ' (Crane3D_ResetSwitchFlag) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[7];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/ThermFlag ' (Crane3D_ThermFlag) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[8];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  optimis_Crane3D_DevDriv_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  optimis_Crane3D_DevDriv_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  optimis_Crane3D_DevDriv_initialize();
}

void MdlTerminate(void)
{
  optimis_Crane3D_DevDriv_terminate();
}

/* Registration function */
RT_MODEL_optimis_Crane3D_DevDriv_T *optimis_Crane3D_DevDriv(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)optimis_Crane3D_DevDriv_M, 0,
                sizeof(RT_MODEL_optimis_Crane3D_DevDriv_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
                          &optimis_Crane3D_DevDriv_M->Timing.simTimeStep);
    rtsiSetTPtr(&optimis_Crane3D_DevDriv_M->solverInfo, &rtmGetTPtr
                (optimis_Crane3D_DevDriv_M));
    rtsiSetStepSizePtr(&optimis_Crane3D_DevDriv_M->solverInfo,
                       &optimis_Crane3D_DevDriv_M->Timing.stepSize0);
    rtsiSetdXPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
                 &optimis_Crane3D_DevDriv_M->ModelData.derivs);
    rtsiSetContStatesPtr(&optimis_Crane3D_DevDriv_M->solverInfo, (real_T **)
                         &optimis_Crane3D_DevDriv_M->ModelData.contStates);
    rtsiSetNumContStatesPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
      &optimis_Crane3D_DevDriv_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
      &optimis_Crane3D_DevDriv_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
      &optimis_Crane3D_DevDriv_M->ModelData.periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
      &optimis_Crane3D_DevDriv_M->ModelData.periodicContStateRanges);
    rtsiSetErrorStatusPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
                          (&rtmGetErrorStatus(optimis_Crane3D_DevDriv_M)));
    rtsiSetRTModelPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
                      optimis_Crane3D_DevDriv_M);
  }

  rtsiSetSimTimeStep(&optimis_Crane3D_DevDriv_M->solverInfo, MAJOR_TIME_STEP);
  optimis_Crane3D_DevDriv_M->ModelData.intgData.y =
    optimis_Crane3D_DevDriv_M->ModelData.odeY;
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[0] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[0];
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[1] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[1];
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[2] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[2];
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[3] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[3];
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[4] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[4];
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[5] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[5];
  optimis_Crane3D_DevDriv_M->ModelData.contStates = ((real_T *)
    &optimis_Crane3D_DevDriv_X);
  rtsiSetSolverData(&optimis_Crane3D_DevDriv_M->solverInfo, (void *)
                    &optimis_Crane3D_DevDriv_M->ModelData.intgData);
  rtsiSetSolverName(&optimis_Crane3D_DevDriv_M->solverInfo,"ode5");
  optimis_Crane3D_DevDriv_M->solverInfoPtr =
    (&optimis_Crane3D_DevDriv_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = optimis_Crane3D_DevDriv_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    optimis_Crane3D_DevDriv_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    optimis_Crane3D_DevDriv_M->Timing.sampleTimes =
      (&optimis_Crane3D_DevDriv_M->Timing.sampleTimesArray[0]);
    optimis_Crane3D_DevDriv_M->Timing.offsetTimes =
      (&optimis_Crane3D_DevDriv_M->Timing.offsetTimesArray[0]);

    /* task periods */
    optimis_Crane3D_DevDriv_M->Timing.sampleTimes[0] = (0.0);
    optimis_Crane3D_DevDriv_M->Timing.sampleTimes[1] = (0.01);

    /* task offsets */
    optimis_Crane3D_DevDriv_M->Timing.offsetTimes[0] = (0.0);
    optimis_Crane3D_DevDriv_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(optimis_Crane3D_DevDriv_M,
             &optimis_Crane3D_DevDriv_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = optimis_Crane3D_DevDriv_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    optimis_Crane3D_DevDriv_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(optimis_Crane3D_DevDriv_M, -1);
  optimis_Crane3D_DevDriv_M->Timing.stepSize0 = 0.01;
  optimis_Crane3D_DevDriv_M->Timing.stepSize1 = 0.01;

  /* External mode info */
  optimis_Crane3D_DevDriv_M->Sizes.checksums[0] = (2563795657U);
  optimis_Crane3D_DevDriv_M->Sizes.checksums[1] = (719276884U);
  optimis_Crane3D_DevDriv_M->Sizes.checksums[2] = (1639452395U);
  optimis_Crane3D_DevDriv_M->Sizes.checksums[3] = (1179476952U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[2];
    optimis_Crane3D_DevDriv_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(optimis_Crane3D_DevDriv_M->extModeInfo,
      &optimis_Crane3D_DevDriv_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(optimis_Crane3D_DevDriv_M->extModeInfo,
                        optimis_Crane3D_DevDriv_M->Sizes.checksums);
    rteiSetTPtr(optimis_Crane3D_DevDriv_M->extModeInfo, rtmGetTPtr
                (optimis_Crane3D_DevDriv_M));
  }

  optimis_Crane3D_DevDriv_M->solverInfoPtr =
    (&optimis_Crane3D_DevDriv_M->solverInfo);
  optimis_Crane3D_DevDriv_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&optimis_Crane3D_DevDriv_M->solverInfo, 0.01);
  rtsiSetSolverMode(&optimis_Crane3D_DevDriv_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  optimis_Crane3D_DevDriv_M->ModelData.blockIO = ((void *)
    &optimis_Crane3D_DevDriv_B);

  {
    int32_T i;
    for (i = 0; i < 6; i++) {
      optimis_Crane3D_DevDriv_B.xwaypoints[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      optimis_Crane3D_DevDriv_B.ywaypoints[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      optimis_Crane3D_DevDriv_B.Encoder[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      optimis_Crane3D_DevDriv_B.ResetEncoder[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      optimis_Crane3D_DevDriv_B.ResetSource[i] = 0.0;
    }

    optimis_Crane3D_DevDriv_B.start_course = 0.0;
    optimis_Crane3D_DevDriv_B.total_waypoints = 0.0;
    optimis_Crane3D_DevDriv_B.XScale = 0.0;
    optimis_Crane3D_DevDriv_B.settling_time = 0.0;
    optimis_Crane3D_DevDriv_B.YScale = 0.0;
    optimis_Crane3D_DevDriv_B.XAngleScale = 0.0;
    optimis_Crane3D_DevDriv_B.YAngleScale = 0.0;
    optimis_Crane3D_DevDriv_B.Product2 = 0.0;
    optimis_Crane3D_DevDriv_B.Product1 = 0.0;
    optimis_Crane3D_DevDriv_B.Product = 0.0;
    optimis_Crane3D_DevDriv_B.Add = 0.0;
    optimis_Crane3D_DevDriv_B.Sum1 = 0.0;
    optimis_Crane3D_DevDriv_B.Product2_k = 0.0;
    optimis_Crane3D_DevDriv_B.Product1_i = 0.0;
    optimis_Crane3D_DevDriv_B.Product1_ik = 0.0;
    optimis_Crane3D_DevDriv_B.Add1 = 0.0;
    optimis_Crane3D_DevDriv_B.PWM[0] = 0.0;
    optimis_Crane3D_DevDriv_B.PWM[1] = 0.0;
    optimis_Crane3D_DevDriv_B.PWM[2] = 0.0;
    optimis_Crane3D_DevDriv_B.Saturation[0] = 0.0;
    optimis_Crane3D_DevDriv_B.Saturation[1] = 0.0;
    optimis_Crane3D_DevDriv_B.Saturation[2] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlag[0] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlag[1] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlag[2] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlagSource[0] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlagSource[1] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlagSource[2] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSource[0] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSource[1] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSource[2] = 0.0;
    optimis_Crane3D_DevDriv_B.SetLimit[0] = 0.0;
    optimis_Crane3D_DevDriv_B.SetLimit[1] = 0.0;
    optimis_Crane3D_DevDriv_B.SetLimit[2] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSwitch[0] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSwitch[1] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSwitch[2] = 0.0;
    optimis_Crane3D_DevDriv_B.PWMPrescaler = 0.0;
    optimis_Crane3D_DevDriv_B.PWMPrescalerSource = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlag[0] = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlag[1] = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlag[2] = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[0] = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[1] = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[2] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlag[0] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlag[1] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlag[2] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlagSource[0] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlagSource[1] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlagSource[2] = 0.0;
    optimis_Crane3D_DevDriv_B.Product_f = 0.0;
    optimis_Crane3D_DevDriv_B.Product_c = 0.0;
    optimis_Crane3D_DevDriv_B.Clock = 0.0;
    optimis_Crane3D_DevDriv_B.done = 0.0;
    optimis_Crane3D_DevDriv_B.close_switch = 0.0;
    optimis_Crane3D_DevDriv_B.xref = 0.0;
    optimis_Crane3D_DevDriv_B.yref = 0.0;
    optimis_Crane3D_DevDriv_B.Kiy = 0.0;
    optimis_Crane3D_DevDriv_B.at_waypoint = 0.0;
    optimis_Crane3D_DevDriv_B.Kdy = 0.0;
    optimis_Crane3D_DevDriv_B.Kpy = 0.0;
    optimis_Crane3D_DevDriv_B.Kpay = 0.0;
    optimis_Crane3D_DevDriv_B.kix = 0.0;
    optimis_Crane3D_DevDriv_B.kpx = 0.0;
    optimis_Crane3D_DevDriv_B.kpax = 0.0;
  }

  /* parameters */
  optimis_Crane3D_DevDriv_M->ModelData.defaultParam = ((real_T *)
    &optimis_Crane3D_DevDriv_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &optimis_Crane3D_DevDriv_X;
    optimis_Crane3D_DevDriv_M->ModelData.contStates = (x);
    (void) memset((void *)&optimis_Crane3D_DevDriv_X, 0,
                  sizeof(X_optimis_Crane3D_DevDriv_T));
  }

  /* states (dwork) */
  optimis_Crane3D_DevDriv_M->ModelData.dwork = ((void *)
    &optimis_Crane3D_DevDriv_DW);
  (void) memset((void *)&optimis_Crane3D_DevDriv_DW, 0,
                sizeof(DW_optimis_Crane3D_DevDriv_T));
  optimis_Crane3D_DevDriv_DW.TimeStampA = 0.0;
  optimis_Crane3D_DevDriv_DW.LastUAtTimeA = 0.0;
  optimis_Crane3D_DevDriv_DW.TimeStampB = 0.0;
  optimis_Crane3D_DevDriv_DW.LastUAtTimeB = 0.0;
  optimis_Crane3D_DevDriv_DW.TimeStampA_o = 0.0;
  optimis_Crane3D_DevDriv_DW.LastUAtTimeA_i = 0.0;
  optimis_Crane3D_DevDriv_DW.TimeStampB_c = 0.0;
  optimis_Crane3D_DevDriv_DW.LastUAtTimeB_o = 0.0;
  optimis_Crane3D_DevDriv_DW.ready = 0.0;
  optimis_Crane3D_DevDriv_DW.xlocal = 0.0;
  optimis_Crane3D_DevDriv_DW.ylocal = 0.0;
  optimis_Crane3D_DevDriv_DW.index = 0.0;
  optimis_Crane3D_DevDriv_DW.initialized = 0.0;
  optimis_Crane3D_DevDriv_DW.arrived = 0.0;
  optimis_Crane3D_DevDriv_DW.i = 0.0;
  optimis_Crane3D_DevDriv_DW.finished = 0.0;
  optimis_Crane3D_DevDriv_DW.Kiy_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kd_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kp_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Ki_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kpa_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kix_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kpx_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kpax_l = 0.0;

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    optimis_Crane3D_DevDriv_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.sfcnInfo;
    optimis_Crane3D_DevDriv_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus
      (optimis_Crane3D_DevDriv_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo,
      &optimis_Crane3D_DevDriv_M->Sizes.numSampTimes);
    optimis_Crane3D_DevDriv_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (optimis_Crane3D_DevDriv_M)[0]);
    optimis_Crane3D_DevDriv_M->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr
      (optimis_Crane3D_DevDriv_M)[1]);
    rtssSetTPtrPtr(sfcnInfo,
                   optimis_Crane3D_DevDriv_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(optimis_Crane3D_DevDriv_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(optimis_Crane3D_DevDriv_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (optimis_Crane3D_DevDriv_M));
    rtssSetStepSizePtr(sfcnInfo, &optimis_Crane3D_DevDriv_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested
      (optimis_Crane3D_DevDriv_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &optimis_Crane3D_DevDriv_M->ModelData.derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &optimis_Crane3D_DevDriv_M->ModelData.zCCacheNeedsReset);
    rtssSetBlkStateChangePtr(sfcnInfo,
      &optimis_Crane3D_DevDriv_M->ModelData.blkStateChange);
    rtssSetSampleHitsPtr(sfcnInfo, &optimis_Crane3D_DevDriv_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &optimis_Crane3D_DevDriv_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &optimis_Crane3D_DevDriv_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &optimis_Crane3D_DevDriv_M->solverInfoPtr);
  }

  optimis_Crane3D_DevDriv_M->Sizes.numSFcns = (9);

  /* register each child */
  {
    (void) memset((void *)
                  &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.childSFunctions[0],
                  0,
                  9*sizeof(SimStruct));
    optimis_Crane3D_DevDriv_M->childSfunctions =
      (&optimis_Crane3D_DevDriv_M->NonInlinedSFcns.childSFunctionPtrs[0]);

    {
      int_T i;
      for (i = 0; i < 9; i++) {
        optimis_Crane3D_DevDriv_M->childSfunctions[i] =
          (&optimis_Crane3D_DevDriv_M->NonInlinedSFcns.childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/Encoder (Crane3D_Encoder) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[0]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.Encoder));
        }
      }

      /* path info */
      ssSetModelName(rts, "Encoder");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/Encoder");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.Encoder_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.Encoder_P2_Size);
      }

      /* registration */
      Crane3D_Encoder(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/PWM (Crane3D_PWM) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[1]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.UPtrs0;
          sfcnUPtrs[0] = optimis_Crane3D_DevDriv_B.Saturation;
          sfcnUPtrs[1] = &optimis_Crane3D_DevDriv_B.Saturation[1];
          sfcnUPtrs[2] = &optimis_Crane3D_DevDriv_B.Saturation[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.PWM));
        }
      }

      /* path info */
      ssSetModelName(rts, "PWM");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/PWM");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)optimis_Crane3D_DevDriv_P.PWM_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)optimis_Crane3D_DevDriv_P.PWM_P2_Size);
      }

      /* registration */
      Crane3D_PWM(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/LimitFlag (Crane3D_LimitFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[2]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.UPtrs0;
          sfcnUPtrs[0] = optimis_Crane3D_DevDriv_B.LimitFlagSource;
          sfcnUPtrs[1] = &optimis_Crane3D_DevDriv_B.LimitFlagSource[1];
          sfcnUPtrs[2] = &optimis_Crane3D_DevDriv_B.LimitFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.LimitFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "LimitFlag");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/LimitFlag");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.LimitFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.LimitFlag_P2_Size);
      }

      /* registration */
      Crane3D_LimitFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/SetLimit (Crane3D_SetLimit) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[3]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[3]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[3]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.UPtrs0;
          sfcnUPtrs[0] = optimis_Crane3D_DevDriv_B.LimitSource;
          sfcnUPtrs[1] = &optimis_Crane3D_DevDriv_B.LimitSource[1];
          sfcnUPtrs[2] = &optimis_Crane3D_DevDriv_B.LimitSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.SetLimit));
        }
      }

      /* path info */
      ssSetModelName(rts, "SetLimit");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/SetLimit");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.SetLimit_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.SetLimit_P2_Size);
      }

      /* registration */
      Crane3D_SetLimit(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/LimitSwitch (Crane3D_Switch) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[4]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[4]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[4]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn4.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.LimitSwitch));
        }
      }

      /* path info */
      ssSetModelName(rts, "LimitSwitch");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/LimitSwitch");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.LimitSwitch_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.LimitSwitch_P2_Size);
      }

      /* registration */
      Crane3D_Switch(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/PWMPrescaler (Crane3D_PWMPrescaler) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[5];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[5]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [5]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [5]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[5]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[5]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.UPtrs0;
          sfcnUPtrs[0] = &optimis_Crane3D_DevDriv_B.PWMPrescalerSource;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &optimis_Crane3D_DevDriv_B.PWMPrescaler));
        }
      }

      /* path info */
      ssSetModelName(rts, "PWMPrescaler");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/PWMPrescaler");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.PWMPrescaler_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.PWMPrescaler_P2_Size);
      }

      /* registration */
      Crane3D_PWMPrescaler(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/ResetEncoder (Crane3D_ResetEncoder) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[6];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[6]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [6]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [6]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[6]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[6]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.UPtrs0;

          {
            int_T i1;
            const real_T *u0 = optimis_Crane3D_DevDriv_B.ResetSource;
            for (i1=0; i1 < 5; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }

          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 5);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.ResetEncoder));
        }
      }

      /* path info */
      ssSetModelName(rts, "ResetEncoder");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/ResetEncoder");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ResetEncoder_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ResetEncoder_P2_Size);
      }

      /* registration */
      Crane3D_ResetEncoder(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/ResetSwitchFlag  (Crane3D_ResetSwitchFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[7];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[7]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [7]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [7]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[7]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[7]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.UPtrs0;
          sfcnUPtrs[0] = optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource;
          sfcnUPtrs[1] = &optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[1];
          sfcnUPtrs[2] = &optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.ResetSwitchFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "ResetSwitchFlag ");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/ResetSwitchFlag ");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ResetSwitchFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ResetSwitchFlag_P2_Size);
      }

      /* registration */
      Crane3D_ResetSwitchFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/ThermFlag  (Crane3D_ThermFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[8];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[8]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [8]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [8]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[8]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[8]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.UPtrs0;
          sfcnUPtrs[0] = optimis_Crane3D_DevDriv_B.ThermFlagSource;
          sfcnUPtrs[1] = &optimis_Crane3D_DevDriv_B.ThermFlagSource[1];
          sfcnUPtrs[2] = &optimis_Crane3D_DevDriv_B.ThermFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.ThermFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "ThermFlag ");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/ThermFlag ");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ThermFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ThermFlag_P2_Size);
      }

      /* registration */
      Crane3D_ThermFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }
  }

  /* Initialize Sizes */
  optimis_Crane3D_DevDriv_M->Sizes.numContStates = (2);/* Number of continuous states */
  optimis_Crane3D_DevDriv_M->Sizes.numPeriodicContStates = (0);/* Number of periodic continuous states */
  optimis_Crane3D_DevDriv_M->Sizes.numY = (0);/* Number of model outputs */
  optimis_Crane3D_DevDriv_M->Sizes.numU = (0);/* Number of model inputs */
  optimis_Crane3D_DevDriv_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  optimis_Crane3D_DevDriv_M->Sizes.numSampTimes = (2);/* Number of sample times */
  optimis_Crane3D_DevDriv_M->Sizes.numBlocks = (65);/* Number of blocks */
  optimis_Crane3D_DevDriv_M->Sizes.numBlockIO = (49);/* Number of block outputs */
  optimis_Crane3D_DevDriv_M->Sizes.numBlockPrms = (108);/* Sum of parameter "widths" */
  return optimis_Crane3D_DevDriv_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
