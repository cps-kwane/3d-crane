#ifndef __c3_optimis_Crane3D_DevDriv_h__
#define __c3_optimis_Crane3D_DevDriv_h__

/* Include files */
#include "sf_runtime/sfc_sf.h"
#include "sf_runtime/sfc_mex.h"
#include "rtwtypes.h"
#include "multiword_types.h"

/* Type Definitions */
#ifndef typedef_SFc3_optimis_Crane3D_DevDrivInstanceStruct
#define typedef_SFc3_optimis_Crane3D_DevDrivInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  boolean_T c3_dataWrittenToVector[28];
  uint8_T c3_doSetSimStateSideEffects;
  const mxArray *c3_setSimStateSideEffectsInfo;
  int32_T *c3_sfEvent;
  uint8_T *c3_is_active_c3_optimis_Crane3D_DevDriv;
  uint8_T *c3_is_c3_optimis_Crane3D_DevDriv;
  uint8_T *c3_is_active_S1_setpoints;
  uint8_T *c3_is_active_S1_setup_pidy;
  uint8_T *c3_is_active_S1_setup_pidx;
  real_T *c3_start_course;
  real_T *c3_ready;
  real_T *c3_done;
  real_T (*c3_xwaypoints)[6];
  real_T (*c3_ywaypoints)[6];
  real_T *c3_total_waypoints;
  real_T *c3_close_switch;
  real_T *c3_xref;
  real_T *c3_yref;
  real_T *c3_xpos;
  real_T *c3_xlocal;
  real_T *c3_ylocal;
  real_T *c3_index;
  real_T *c3_initialized;
  real_T *c3_arrived;
  real_T *c3_t;
  real_T *c3_ypos;
  real_T *c3_i;
  real_T *c3_finished;
  real_T *c3_Kiy;
  real_T *c3_Kiy_l;
  real_T *c3_at_waypoint;
  real_T *c3_Kd_l;
  real_T *c3_Kp_l;
  real_T *c3_Ki_l;
  real_T *c3_Kdy;
  real_T *c3_Kpy;
  real_T *c3_Kpay;
  real_T *c3_Kpa_l;
  real_T *c3_kix;
  real_T *c3_kpx;
  real_T *c3_kpax;
  real_T *c3_Kix_l;
  real_T *c3_Kpx_l;
  real_T *c3_Kpax_l;
  uint32_T *c3_temporalCounter_i1;
} SFc3_optimis_Crane3D_DevDrivInstanceStruct;

#endif                                 /*typedef_SFc3_optimis_Crane3D_DevDrivInstanceStruct*/

/* Named Constants */

/* Variable Declarations */
extern struct SfDebugInstanceStruct *sfGlobalDebugInstanceStruct;

/* Variable Definitions */

/* Function Declarations */
extern const mxArray
  *sf_c3_optimis_Crane3D_DevDriv_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c3_optimis_Crane3D_DevDriv_get_check_sum(mxArray *plhs[]);
extern void c3_optimis_Crane3D_DevDriv_method_dispatcher(SimStruct *S, int_T
  method, void *data);

#endif
