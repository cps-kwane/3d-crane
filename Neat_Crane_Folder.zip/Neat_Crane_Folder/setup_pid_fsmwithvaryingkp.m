%PID Parameters Setup

Ki=0.1419;
Kia=1.3061;
Kpa=1.3061;

Kix=-0.08;
kiax=13.56;
Kpx=7.1849;
Kpax=4.2701;