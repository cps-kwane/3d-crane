1- The vanilla software model must be run after generating a timeseries object through generate time series vector script.

