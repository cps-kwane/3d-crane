% file='my_course.csv';
% i=1;
% [targets,obstacles]=getCourseFromCSV(file)


%% Software
[mscore, tarN, obsN, payloadX, payloadY, alphaX, alphaY] = ...
  getScore_simscape(simout, obstacles, targets,j,showPlot);


% %% Actual Crane
% payloadX = xpos.signals.values+0.3*sin(anglex.signals.values);
% payloadY= ypos.signals.values+0.3*sin(angley.signals.values);
% score = getScore_crane(payloadX,payloadY, obstacles, targets,xpos.time,i,'on')