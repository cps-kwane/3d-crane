function position = coordsToMeters(coords)
    position = coords/100;
end