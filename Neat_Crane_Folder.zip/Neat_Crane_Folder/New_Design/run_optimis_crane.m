j=1;
showPlot='on';


start_course=1;
settling_time=3;
total_waypoints=length(xwaypoints);
modelName='optimis_crane_2016a';
simout= sim(modelName,'FixedStep',num2str(Ts),'ReturnWorkspaceOutputs','on');

%  compute_score_hl;
% score(j)=mscore;

%end
[obstacles,targets]=getCourseFromCSV(filename);
simple_getScore(simout, obstacles, targets, j, showPlot)