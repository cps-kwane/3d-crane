def hi():
	print('hi')

hi()