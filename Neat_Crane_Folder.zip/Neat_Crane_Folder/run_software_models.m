modelName='Simscape_crane_software_model_vanilla';
simout= sim(modelName,'FixedStep',num2str(Ts),'ReturnWorkspaceOutputs','on');

