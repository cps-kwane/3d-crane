%% Given Setup Script
clear all
clear variables
close all
clc