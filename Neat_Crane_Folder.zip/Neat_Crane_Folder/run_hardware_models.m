%% Basic Model with finite time
Crane3D_DevDriv;
set_param('Crane3D_DevDriv','StopTime','28');
set_param('Crane3D_DevDriv','SimulationCommand','Update','SimulationCommand','start')
pause(30);


%% FSM Model
Crane3D_DevDriv_fsm;
model='Crane3D_DevDriv_fsm';
set_param(model,'StopTime','inf');
set_param(model,'SimulationCommand','Update','SimulationCommand','start')

%% FSM Model with varying Kp
Crane3D_DevDriv_fsm_varyingkp;
model='Crane3D_DevDriv_fsm_varyingkp';
set_param(model,'StopTime','inf');
set_param(model,'SimulationCommand','Update','SimulationCommand','start')
