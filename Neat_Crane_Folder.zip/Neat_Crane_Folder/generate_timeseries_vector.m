targets=[3,5;35,20;40,20;47,47];
obstacles=[];

%% Generate Path
xwaypoints=targets(:,1)/100;
ywaypoints=targets(:,2)/100;
time_vect=[0,4.99,5,9.99,10,14.99,15,19.99];
index=1;
%% Convert input to Time series object for Simulink
for i=1:length(xwaypoints)
 	  x_vect(2*i)=xwaypoints(i);
    	x_vect(2*i-1)=xwaypoints(i);
 		y_vect(2*i)=ywaypoints(i);
 		y_vect(2*i-1)=ywaypoints(i);
end
varx=timeseries(x_vect,time_vect);
vary=timeseries(y_vect,time_vect);
