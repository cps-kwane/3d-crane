/*
 * optimis_Crane3D_DevDriv_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "optimis_Crane3D_DevDriv".
 *
 * Model version              : 1.149
 * Simulink Coder version : 8.10 (R2016a) 10-Feb-2016
 * C source code generated on : Mon Dec 11 13:39:45 2017
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_optimis_Crane3D_DevDriv_types_h_
#define RTW_HEADER_optimis_Crane3D_DevDriv_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#ifndef struct_md9a4e78e0d93829f43034ec0a7818d89d
#define struct_md9a4e78e0d93829f43034ec0a7818d89d

struct md9a4e78e0d93829f43034ec0a7818d89d
{
  int32_T S0_isInitialized;
  real_T W0_states[229];
  real_T P0_InitialStates;
  real_T P1_Coefficients[230];
};

#endif                                 /*struct_md9a4e78e0d93829f43034ec0a7818d89d*/

#ifndef typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_T
#define typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_T

typedef struct md9a4e78e0d93829f43034ec0a7818d89d
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_T;

#endif                                 /*typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_T*/

#ifndef struct_mdX0FNByvRolJNUgOOQemAOC
#define struct_mdX0FNByvRolJNUgOOQemAOC

struct mdX0FNByvRolJNUgOOQemAOC
{
  int32_T isInitialized;
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_T cSFunObject;
};

#endif                                 /*struct_mdX0FNByvRolJNUgOOQemAOC*/

#ifndef typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_T
#define typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_T

typedef struct mdX0FNByvRolJNUgOOQemAOC
  dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_T;

#endif                                 /*typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_T*/

#ifndef struct_md8b9b4567eaae846399fa7b381f3e384c
#define struct_md8b9b4567eaae846399fa7b381f3e384c

struct md8b9b4567eaae846399fa7b381f3e384c
{
  int32_T S0_isInitialized;
  real_T W0_states[179];
  real_T P0_InitialStates;
  real_T P1_Coefficients[180];
};

#endif                                 /*struct_md8b9b4567eaae846399fa7b381f3e384c*/

#ifndef typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_k_T
#define typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_k_T

typedef struct md8b9b4567eaae846399fa7b381f3e384c
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_k_T;

#endif                                 /*typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_k_T*/

#ifndef struct_mdQXx0L82h8R3uunq361mKZB
#define struct_mdQXx0L82h8R3uunq361mKZB

struct mdQXx0L82h8R3uunq361mKZB
{
  int32_T isInitialized;
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_k_T cSFunObject;
};

#endif                                 /*struct_mdQXx0L82h8R3uunq361mKZB*/

#ifndef typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_k_T
#define typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_k_T

typedef struct mdQXx0L82h8R3uunq361mKZB
  dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_k_T;

#endif                                 /*typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_k_T*/

#ifndef struct_md561ef71ff04c69a057b628367880609c
#define struct_md561ef71ff04c69a057b628367880609c

struct md561ef71ff04c69a057b628367880609c
{
  int32_T S0_isInitialized;
  real_T W0_states[183];
  real_T P0_InitialStates;
  real_T P1_Coefficients[184];
};

#endif                                 /*struct_md561ef71ff04c69a057b628367880609c*/

#ifndef typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv_T
#define typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv_T

typedef struct md561ef71ff04c69a057b628367880609c
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv_T;

#endif                                 /*typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv_T*/

#ifndef struct_mdCLi7H4xfQO7lDjce6P581D
#define struct_mdCLi7H4xfQO7lDjce6P581D

struct mdCLi7H4xfQO7lDjce6P581D
{
  int32_T isInitialized;
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv_T cSFunObject;
};

#endif                                 /*struct_mdCLi7H4xfQO7lDjce6P581D*/

#ifndef typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv_T
#define typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv_T

typedef struct mdCLi7H4xfQO7lDjce6P581D
  dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv_T;

#endif                                 /*typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv_T*/

#ifndef struct_md8a2e2eee649ba52f1104f11610133852
#define struct_md8a2e2eee649ba52f1104f11610133852

struct md8a2e2eee649ba52f1104f11610133852
{
  int32_T S0_isInitialized;
  real_T W0_states[317];
  real_T P0_InitialStates;
  real_T P1_Coefficients[318];
};

#endif                                 /*struct_md8a2e2eee649ba52f1104f11610133852*/

#ifndef typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv4_T
#define typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv4_T

typedef struct md8a2e2eee649ba52f1104f11610133852
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv4_T;

#endif                                 /*typedef_dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv4_T*/

#ifndef struct_mdfgAVNxZwbltd78pScLleiF
#define struct_mdfgAVNxZwbltd78pScLleiF

struct mdfgAVNxZwbltd78pScLleiF
{
  int32_T isInitialized;
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv4_T cSFunObject;
};

#endif                                 /*struct_mdfgAVNxZwbltd78pScLleiF*/

#ifndef typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv4_T
#define typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv4_T

typedef struct mdfgAVNxZwbltd78pScLleiF
  dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv4_T;

#endif                                 /*typedef_dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv4_T*/

#ifndef struct_tag_shTYV4pEKtZdgIbJrMrA3LC
#define struct_tag_shTYV4pEKtZdgIbJrMrA3LC

struct tag_shTYV4pEKtZdgIbJrMrA3LC
{
  int32_T isInitialized;
  uint32_T inputVarSize1[8];
  real_T State[29];
  real_T pNumChannels;
};

#endif                                 /*struct_tag_shTYV4pEKtZdgIbJrMrA3LC*/

#ifndef typedef_My_MovingAverageFilter_optimis_Crane3D_DevDriv_T
#define typedef_My_MovingAverageFilter_optimis_Crane3D_DevDriv_T

typedef struct tag_shTYV4pEKtZdgIbJrMrA3LC
  My_MovingAverageFilter_optimis_Crane3D_DevDriv_T;

#endif                                 /*typedef_My_MovingAverageFilter_optimis_Crane3D_DevDriv_T*/

#ifndef typedef_struct_T_optimis_Crane3D_DevDriv_T
#define typedef_struct_T_optimis_Crane3D_DevDriv_T

typedef struct {
  char_T f0[6];
  char_T f1[6];
} struct_T_optimis_Crane3D_DevDriv_T;

#endif                                 /*typedef_struct_T_optimis_Crane3D_DevDriv_T*/

#ifndef typedef_struct_T_optimis_Crane3D_DevDriv_k_T
#define typedef_struct_T_optimis_Crane3D_DevDriv_k_T

typedef struct {
  char_T f0[2];
  char_T f1[9];
} struct_T_optimis_Crane3D_DevDriv_k_T;

#endif                                 /*typedef_struct_T_optimis_Crane3D_DevDriv_k_T*/

#ifndef struct_mdLycFgTvS8pC8y6eKSEbM1D
#define struct_mdLycFgTvS8pC8y6eKSEbM1D

struct mdLycFgTvS8pC8y6eKSEbM1D
{
  int32_T isInitialized;
  uint32_T inputVarSize1[8];
  real_T pSampleRateDialog;
  real_T NumChannels;
  dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_T *FilterObj;
};

#endif                                 /*struct_mdLycFgTvS8pC8y6eKSEbM1D*/

#ifndef typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_T
#define typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_T

typedef struct mdLycFgTvS8pC8y6eKSEbM1D
  dsp_LowpassFilter_optimis_Crane3D_DevDriv_T;

#endif                                 /*typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_T*/

#ifndef typedef_struct_T_optimis_Crane3D_DevDriv_kv_T
#define typedef_struct_T_optimis_Crane3D_DevDriv_kv_T

typedef struct {
  char_T f0[7];
} struct_T_optimis_Crane3D_DevDriv_kv_T;

#endif                                 /*typedef_struct_T_optimis_Crane3D_DevDriv_kv_T*/

#ifndef typedef_struct_T_optimis_Crane3D_DevDriv_kv4_T
#define typedef_struct_T_optimis_Crane3D_DevDriv_kv4_T

typedef struct {
  char_T f0[6];
} struct_T_optimis_Crane3D_DevDriv_kv4_T;

#endif                                 /*typedef_struct_T_optimis_Crane3D_DevDriv_kv4_T*/

#ifndef typedef_struct_T_optimis_Crane3D_DevDriv_kv43_T
#define typedef_struct_T_optimis_Crane3D_DevDriv_kv43_T

typedef struct {
  char_T f0[6];
  char_T f1[6];
  char_T f2[4];
  char_T f3[8];
} struct_T_optimis_Crane3D_DevDriv_kv43_T;

#endif                                 /*typedef_struct_T_optimis_Crane3D_DevDriv_kv43_T*/

#ifndef typedef_struct_T_optimis_Crane3D_DevDriv_kv434_T
#define typedef_struct_T_optimis_Crane3D_DevDriv_kv434_T

typedef struct {
  char_T f0[6];
  char_T f1[6];
  char_T f2[4];
  char_T f3[8];
  char_T f4[2];
  real_T f5;
} struct_T_optimis_Crane3D_DevDriv_kv434_T;

#endif                                 /*typedef_struct_T_optimis_Crane3D_DevDriv_kv434_T*/

#ifndef typedef_struct_T_optimis_Crane3D_DevDriv_kv434o_T
#define typedef_struct_T_optimis_Crane3D_DevDriv_kv434o_T

typedef struct {
  char_T f0[4];
  char_T f1[6];
  char_T f2[8];
  char_T f3[6];
} struct_T_optimis_Crane3D_DevDriv_kv434o_T;

#endif                                 /*typedef_struct_T_optimis_Crane3D_DevDriv_kv434o_T*/

#ifndef typedef_struct_T_optimis_Crane3D_DevDriv_kv434oj_T
#define typedef_struct_T_optimis_Crane3D_DevDriv_kv434oj_T

typedef struct {
  char_T f0[6];
  char_T f1[6];
  char_T f2[4];
  char_T f3[8];
  char_T f4;
  real_T f5;
} struct_T_optimis_Crane3D_DevDriv_kv434oj_T;

#endif                                 /*typedef_struct_T_optimis_Crane3D_DevDriv_kv434oj_T*/

#ifndef struct_mdNUymLyrTKJjKhjEwTr1PFH
#define struct_mdNUymLyrTKJjKhjEwTr1PFH

struct mdNUymLyrTKJjKhjEwTr1PFH
{
  int32_T isInitialized;
  uint32_T inputVarSize1[8];
  real_T pSampleRateDialog;
  real_T NumChannels;
  dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_k_T *FilterObj;
};

#endif                                 /*struct_mdNUymLyrTKJjKhjEwTr1PFH*/

#ifndef typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_k_T
#define typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_k_T

typedef struct mdNUymLyrTKJjKhjEwTr1PFH
  dsp_LowpassFilter_optimis_Crane3D_DevDriv_k_T;

#endif                                 /*typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_k_T*/

#ifndef struct_mdZSNIb5W8vhkmArF01GgUaF
#define struct_mdZSNIb5W8vhkmArF01GgUaF

struct mdZSNIb5W8vhkmArF01GgUaF
{
  int32_T isInitialized;
  uint32_T inputVarSize1[8];
  real_T pSampleRateDialog;
  real_T NumChannels;
  dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv_T *FilterObj;
};

#endif                                 /*struct_mdZSNIb5W8vhkmArF01GgUaF*/

#ifndef typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_kv_T
#define typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_kv_T

typedef struct mdZSNIb5W8vhkmArF01GgUaF
  dsp_LowpassFilter_optimis_Crane3D_DevDriv_kv_T;

#endif                                 /*typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_kv_T*/

#ifndef struct_mdM4rVfn8a71yKl1Rd09lDS
#define struct_mdM4rVfn8a71yKl1Rd09lDS

struct mdM4rVfn8a71yKl1Rd09lDS
{
  int32_T isInitialized;
  uint32_T inputVarSize1[8];
  real_T pSampleRateDialog;
  real_T NumChannels;
  dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv4_T *FilterObj;
};

#endif                                 /*struct_mdM4rVfn8a71yKl1Rd09lDS*/

#ifndef typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_kv4_T
#define typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_kv4_T

typedef struct mdM4rVfn8a71yKl1Rd09lDS
  dsp_LowpassFilter_optimis_Crane3D_DevDriv_kv4_T;

#endif                                 /*typedef_dsp_LowpassFilter_optimis_Crane3D_DevDriv_kv4_T*/

/* Parameters (auto storage) */
typedef struct P_optimis_Crane3D_DevDriv_T_ P_optimis_Crane3D_DevDriv_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_optimis_Crane3D_DevDriv_T
  RT_MODEL_optimis_Crane3D_DevDriv_T;

#endif                                 /* RTW_HEADER_optimis_Crane3D_DevDriv_types_h_ */
