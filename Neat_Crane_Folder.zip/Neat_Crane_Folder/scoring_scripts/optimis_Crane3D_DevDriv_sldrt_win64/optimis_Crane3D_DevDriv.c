/*
 * optimis_Crane3D_DevDriv.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "optimis_Crane3D_DevDriv".
 *
 * Model version              : 1.149
 * Simulink Coder version : 8.10 (R2016a) 10-Feb-2016
 * C source code generated on : Mon Dec 11 13:39:45 2017
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "optimis_Crane3D_DevDriv.h"
#include "optimis_Crane3D_DevDriv_private.h"
#include "optimis_Crane3D_DevDriv_dt.h"

/* Named constants for Chart: '<Root>/HL Controller' */
#define optimis_Crane3D_DevDriv_CALL_EVENT (-1)
#define optimis_Crane3D_DevDriv_IN_Idle ((uint8_T)1U)
#define optimis_Crane3D_DevDriv_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define optimis_Crane3D_DevDriv_IN_S1_initialize ((uint8_T)2U)
#define optimis_Crane3D_DevDriv_IN_S2_move_it ((uint8_T)3U)
#define optimis_Crane3D_DevDriv_IN_S3_new_input ((uint8_T)4U)
#define optimis_Crane3D_DevDriv_IN_S4_wait1 ((uint8_T)5U)
#define optimis_Crane3D_DevDriv_IN_S5_checkifdone ((uint8_T)6U)
#define optimis_Crane3D_DevDriv_IN_S6_done ((uint8_T)7U)
#define optimis_Crane3D_DevDriv_SampleRate (44100.0)

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.01, 0.0,
};

/* Block signals (auto storage) */
B_optimis_Crane3D_DevDriv_T optimis_Crane3D_DevDriv_B;

/* Continuous states */
X_optimis_Crane3D_DevDriv_T optimis_Crane3D_DevDriv_X;

/* Block states (auto storage) */
DW_optimis_Crane3D_DevDriv_T optimis_Crane3D_DevDriv_DW;

/* Real-time model */
RT_MODEL_optimis_Crane3D_DevDriv_T optimis_Crane3D_DevDriv_M_;
RT_MODEL_optimis_Crane3D_DevDriv_T *const optimis_Crane3D_DevDriv_M =
  &optimis_Crane3D_DevDriv_M_;

/* Forward declaration for local functions */
static void optimis_Crane3D_DevDriv_setpidy(real_T ycurrent, real_T ydest,
  real_T *Kd, real_T *Kp, real_T *Ki, real_T *Kpa);
static void optimis_Crane3D_DevDriv_func1_setpidy(real_T ycurrent, real_T ydest);
static void optimis_Crane3D_DevDriv_setpidx(real_T xcurrent, real_T xdest,
  real_T *Kix, real_T *Kpx, real_T *Kpax);
static void optimis_Crane3D_DevDriv_func1_setpidx(real_T xcurrent, real_T xdest);
static void optimis_Crane3D_DevDriv_func2_CheckArrival(real_T currentx, real_T
  currenty, real_T xdest, real_T ydest);
static void optimis_Crane3D_DevDriv_func3_CheckDone(real_T count, real_T total);

/*
 * This function updates continuous states using the ODE5 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE5_A[6] = {
    1.0/5.0, 3.0/10.0, 4.0/5.0, 8.0/9.0, 1.0, 1.0
  };

  static const real_T rt_ODE5_B[6][6] = {
    { 1.0/5.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 3.0/40.0, 9.0/40.0, 0.0, 0.0, 0.0, 0.0 },

    { 44.0/45.0, -56.0/15.0, 32.0/9.0, 0.0, 0.0, 0.0 },

    { 19372.0/6561.0, -25360.0/2187.0, 64448.0/6561.0, -212.0/729.0, 0.0, 0.0 },

    { 9017.0/3168.0, -355.0/33.0, 46732.0/5247.0, 49.0/176.0, -5103.0/18656.0,
      0.0 },

    { 35.0/384.0, 0.0, 500.0/1113.0, 125.0/192.0, -2187.0/6784.0, 11.0/84.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE5_IntgData *id = (ODE5_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T *f4 = id->f[4];
  real_T *f5 = id->f[5];
  real_T hB[6];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  optimis_Crane3D_DevDriv_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE5_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[0]);
  rtsiSetdX(si, f1);
  optimis_Crane3D_DevDriv_output();
  optimis_Crane3D_DevDriv_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE5_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[1]);
  rtsiSetdX(si, f2);
  optimis_Crane3D_DevDriv_output();
  optimis_Crane3D_DevDriv_derivatives();

  /* f(:,4) = feval(odefile, t + hA(3), y + f*hB(:,3), args(:)(*)); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE5_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[2]);
  rtsiSetdX(si, f3);
  optimis_Crane3D_DevDriv_output();
  optimis_Crane3D_DevDriv_derivatives();

  /* f(:,5) = feval(odefile, t + hA(4), y + f*hB(:,4), args(:)(*)); */
  for (i = 0; i <= 3; i++) {
    hB[i] = h * rt_ODE5_B[3][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[3]);
  rtsiSetdX(si, f4);
  optimis_Crane3D_DevDriv_output();
  optimis_Crane3D_DevDriv_derivatives();

  /* f(:,6) = feval(odefile, t + hA(5), y + f*hB(:,5), args(:)(*)); */
  for (i = 0; i <= 4; i++) {
    hB[i] = h * rt_ODE5_B[4][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f5);
  optimis_Crane3D_DevDriv_output();
  optimis_Crane3D_DevDriv_derivatives();

  /* tnew = t + hA(6);
     ynew = y + f*hB(:,6); */
  for (i = 0; i <= 5; i++) {
    hB[i] = h * rt_ODE5_B[5][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4] + f5[i]*hB[5]);
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_setpidy(real_T ycurrent, real_T ydest,
  real_T *Kd, real_T *Kp, real_T *Ki, real_T *Kpa)
{
  real_T temp;

  /* MATLAB Function 'setpidy': '<S2>:371' */
  /* '<S2>:371:2' */
  temp = fabs(ycurrent - ydest);
  if (temp == 0.0) {
    /* '<S2>:371:3' */
    /* '<S2>:371:4' */
    *Kd = 0.0;

    /* '<S2>:371:5' */
    *Kp = 0.0;

    /* '<S2>:371:6' */
    *Ki = 0.0;

    /* '<S2>:371:7' */
    *Kpa = 0.0;
  } else if (temp <= 0.02) {
    /* '<S2>:371:8' */
    /* '<S2>:371:9' */
    *Kd = -0.00013983;

    /* '<S2>:371:10' */
    *Kp = 35.0;

    /* '<S2>:371:11' */
    *Ki = 2.0;

    /* '<S2>:371:12' */
    *Kpa = 0.0;
  } else if (temp <= 0.04) {
    /* '<S2>:371:13' */
    /* '<S2>:371:14' */
    *Kd = -0.2543;

    /* '<S2>:371:15' */
    *Kp = 5.1432;

    /* '<S2>:371:16' */
    *Ki = -0.0242;

    /* '<S2>:371:17' */
    *Kpa = 6.7982;
  } else if (temp <= 0.09) {
    /* '<S2>:371:18' */
    /* '<S2>:371:19' */
    *Kd = -0.2515;

    /* '<S2>:371:20' */
    *Kp = 5.1432;

    /* '<S2>:371:21' */
    *Ki = -0.0268;

    /* '<S2>:371:22' */
    *Kpa = 6.7982;
  } else if (temp <= 0.14) {
    /* '<S2>:371:23' */
    /* '<S2>:371:24' */
    *Kd = 0.3539;

    /* '<S2>:371:25' */
    *Kp = 4.2986;

    /* '<S2>:371:26' */
    *Ki = 0.0954;

    /* '<S2>:371:27' */
    *Kpa = 6.9524;
  } else if (temp <= 0.19) {
    /* '<S2>:371:28' */
    /* '<S2>:371:29' */
    *Kd = -0.0808;

    /* '<S2>:371:30' */
    *Kp = 4.2171;

    /* '<S2>:371:31' */
    *Ki = -0.0742;

    /* '<S2>:371:32' */
    *Kpa = 6.7859;
  } else if (temp <= 0.24) {
    /* '<S2>:371:33' */
    /* '<S2>:371:34' */
    *Kd = -0.0762;

    /* '<S2>:371:35' */
    *Kp = 3.5884;

    /* '<S2>:371:36' */
    *Ki = 0.0463;

    /* '<S2>:371:37' */
    *Kpa = 6.6922;
  } else if (temp <= 0.29) {
    /* '<S2>:371:38' */
    /* '<S2>:371:39' */
    *Kd = 0.0659;

    /* '<S2>:371:40' */
    *Kp = 3.4205;

    /* '<S2>:371:41' */
    *Ki = -0.002;

    /* '<S2>:371:42' */
    *Kpa = 6.7035;
  } else if (temp <= 0.34) {
    /* '<S2>:371:43' */
    /* '<S2>:371:44' */
    *Kd = -0.032;

    /* '<S2>:371:45' */
    *Kp = 2.8951;

    /* '<S2>:371:46' */
    *Ki = 0.0262;

    /* '<S2>:371:47' */
    *Kpa = 7.0725;
  } else if (temp <= 0.39) {
    /* '<S2>:371:48' */
    /* '<S2>:371:49' */
    *Kd = 0.0417;

    /* '<S2>:371:50' */
    *Kp = 2.8599;

    /* '<S2>:371:51' */
    *Ki = 0.0234;

    /* '<S2>:371:52' */
    *Kpa = 7.0674;
  } else if (temp <= 0.44) {
    /* '<S2>:371:53' */
    /* '<S2>:371:54' */
    *Kd = 0.042;

    /* '<S2>:371:55' */
    *Kp = 2.7403;

    /* '<S2>:371:56' */
    *Ki = 0.0169;

    /* '<S2>:371:57' */
    *Kpa = 7.0866;
  } else {
    /* '<S2>:371:59' */
    *Kd = 0.1158;

    /* '<S2>:371:60' */
    *Kp = 2.6958;

    /* '<S2>:371:61' */
    *Ki = 0.0135;

    /* '<S2>:371:62' */
    *Kpa = 7.1027;
  }

  /*      Ki=0.2; */
  /*      Kp=6; */
  /*      Kpa=3.7; */
  /*      Kd=0; */
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_func1_setpidy(real_T ycurrent, real_T ydest)
{
  real_T Kd_l;
  real_T Kp_l;
  real_T Ki_l;
  real_T Kpa_l;

  /* MATLAB Function 'func1_setpidy': '<S2>:396' */
  /* Graphical Function 'func1_setpidy': '<S2>:396' */
  /* '<S2>:397:1' */
  optimis_Crane3D_DevDriv_setpidy(ycurrent, ydest, &Kd_l, &Kp_l, &Ki_l, &Kpa_l);

  /* '<S2>:397:1' */
  optimis_Crane3D_DevDriv_DW.Kd_l = Kd_l;

  /* '<S2>:397:1' */
  optimis_Crane3D_DevDriv_DW.Kp_l = Kp_l;

  /* '<S2>:397:1' */
  optimis_Crane3D_DevDriv_DW.Ki_l = Ki_l;

  /* '<S2>:397:1' */
  optimis_Crane3D_DevDriv_DW.Kpa_l = Kpa_l;
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_setpidx(real_T xcurrent, real_T xdest,
  real_T *Kix, real_T *Kpx, real_T *Kpax)
{
  real_T temp;

  /* MATLAB Function 'setpidx': '<S2>:405' */
  /* '<S2>:405:2' */
  temp = fabs(xcurrent - xdest);
  if (temp == 0.0) {
    /* '<S2>:405:3' */
    /* '<S2>:405:4' */
    *Kix = 0.0;

    /* '<S2>:405:5' */
    *Kpx = 0.0;

    /* '<S2>:405:6' */
    *Kpax = 0.0;
  } else if (temp <= 0.01) {
    /* '<S2>:405:7' */
    /* '<S2>:405:8' */
    *Kix = 0.004;

    /* '<S2>:405:9' */
    *Kpx = 12.0;

    /* '<S2>:405:10' */
    *Kpax = 12.0;
  } else if (temp <= 0.09) {
    /* '<S2>:405:11' */
    /* %used that of 0.05 */
    /* '<S2>:405:12' */
    *Kix = 0.004;

    /* '<S2>:405:13' */
    *Kpx = 7.9;

    /* '<S2>:405:14' */
    *Kpax = 12.0;
  } else if (temp == 0.1) {
    /* '<S2>:405:15' */
    /* '<S2>:405:16' */
    *Kix = 0.0214;

    /* '<S2>:405:17' */
    *Kpx = 5.19131;

    /* '<S2>:405:18' */
    *Kpax = 6.5867;
  } else if (temp <= 0.15) {
    /* '<S2>:405:19' */
    /* '<S2>:405:20' */
    *Kix = 0.00527;

    /* '<S2>:405:21' */
    *Kpx = 4.1917;

    /* '<S2>:405:22' */
    *Kpax = 8.314;
  } else if (temp <= 0.2) {
    /* '<S2>:405:23' */
    /* '<S2>:405:24' */
    *Kix = 0.0053;

    /* '<S2>:405:25' */
    *Kpx = 4.1826;

    /* '<S2>:405:26' */
    *Kpax = 6.8172;
  } else if (temp <= 0.25) {
    /* '<S2>:405:27' */
    /* '<S2>:405:28' */
    *Kix = 0.0155;

    /* '<S2>:405:29' */
    *Kpx = 3.6125;

    /* '<S2>:405:30' */
    *Kpax = 7.1256;
  } else if (temp <= 0.3) {
    /* '<S2>:405:31' */
    /* '<S2>:405:32' */
    *Kix = 0.0155;

    /* '<S2>:405:33' */
    *Kpx = 3.2684;

    /* '<S2>:405:34' */
    *Kpax = 7.1256;
  } else if (temp <= 0.35) {
    /* '<S2>:405:35' */
    /* '<S2>:405:36' */
    *Kix = 0.0152;

    /* '<S2>:405:37' */
    *Kpx = 3.1918;

    /* '<S2>:405:38' */
    *Kpax = 7.1093;
  } else if (temp <= 0.42) {
    /* '<S2>:405:39' */
    /* '<S2>:405:40' */
    *Kix = 0.0082;

    /* '<S2>:405:41' */
    *Kpx = 3.039;

    /* '<S2>:405:42' */
    *Kpax = 7.0203;
  } else {
    /* '<S2>:405:44' */
    *Kix = 0.0078;

    /* '<S2>:405:45' */
    *Kpx = 3.1393;

    /* '<S2>:405:46' */
    *Kpax = 5.232;
  }
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_func1_setpidx(real_T xcurrent, real_T xdest)
{
  real_T Kix_l;
  real_T Kpx_l;
  real_T Kpax_l;

  /* MATLAB Function 'func1_setpidx': '<S2>:408' */
  /* Graphical Function 'func1_setpidx': '<S2>:408' */
  /* '<S2>:409:1' */
  optimis_Crane3D_DevDriv_setpidx(xcurrent, xdest, &Kix_l, &Kpx_l, &Kpax_l);

  /* '<S2>:409:1' */
  optimis_Crane3D_DevDriv_DW.Kix_l = Kix_l;

  /* '<S2>:409:1' */
  optimis_Crane3D_DevDriv_DW.Kpx_l = Kpx_l;

  /* '<S2>:409:1' */
  optimis_Crane3D_DevDriv_DW.Kpax_l = Kpax_l;
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_func2_CheckArrival(real_T currentx, real_T
  currenty, real_T xdest, real_T ydest)
{
  boolean_T sf_internal_predicateOutput;

  /* MATLAB Function 'func2_CheckArrival': '<S2>:48' */
  /* Graphical Function 'func2_CheckArrival': '<S2>:48' */
  /*  checks for steady state */
  if ((fabs(xdest - currentx) <= 0.01) && (fabs(ydest - currenty) <= 0.01)) {
    /* '<S2>:54:1' */
    sf_internal_predicateOutput = true;
  } else {
    /* '<S2>:54:1' */
    sf_internal_predicateOutput = false;
  }

  if (sf_internal_predicateOutput) {
    /* '<S2>:54:1' */
    /* '<S2>:56:1' */
    optimis_Crane3D_DevDriv_DW.arrived = 1.0;
  } else {
    /* '<S2>:55:1' */
    optimis_Crane3D_DevDriv_DW.arrived = 0.0;
  }
}

/* Function for Chart: '<Root>/HL Controller' */
static void optimis_Crane3D_DevDriv_func3_CheckDone(real_T count, real_T total)
{
  /* MATLAB Function 'func3_CheckDone': '<S2>:129' */
  /* Graphical Function 'func3_CheckDone': '<S2>:129' */
  /* '<S2>:142:1' */
  if (count > total) {
    /* '<S2>:144:1' */
    optimis_Crane3D_DevDriv_DW.finished = 1.0;
  } else {
    /* '<S2>:143:1' */
    optimis_Crane3D_DevDriv_DW.finished = 0.0;
  }
}

/* Model output function */
void optimis_Crane3D_DevDriv_output(void)
{
  real_T *lastU;
  real_T dbuffer[30];
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv4_T *obj;
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_kv_T *obj_0;
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_k_T *obj_1;
  dsp_FIRFilter_0_optimis_Crane3D_DevDriv_T *obj_2;
  real_T rtb_Sum_n;
  real_T rtb_Derivative_m;
  real_T rtb_Derivative;
  real_T rtb_Encoder500PPR[5];
  int32_T i;
  boolean_T exitg1;
  boolean_T exitg2;
  boolean_T exitg3;
  boolean_T exitg4;
  boolean_T exitg5;
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* set solver stop time */
    if (!(optimis_Crane3D_DevDriv_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&optimis_Crane3D_DevDriv_M->solverInfo,
                            ((optimis_Crane3D_DevDriv_M->Timing.clockTickH0 + 1)
        * optimis_Crane3D_DevDriv_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&optimis_Crane3D_DevDriv_M->solverInfo,
                            ((optimis_Crane3D_DevDriv_M->Timing.clockTick0 + 1) *
        optimis_Crane3D_DevDriv_M->Timing.stepSize0 +
        optimis_Crane3D_DevDriv_M->Timing.clockTickH0 *
        optimis_Crane3D_DevDriv_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(optimis_Crane3D_DevDriv_M)) {
    optimis_Crane3D_DevDriv_M->Timing.t[0] = rtsiGetT
      (&optimis_Crane3D_DevDriv_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Constant: '<Root>/start_course' */
    optimis_Crane3D_DevDriv_B.start_course =
      optimis_Crane3D_DevDriv_P.start_course;
    for (i = 0; i < 6; i++) {
      /* Constant: '<Root>/xwaypoints' */
      optimis_Crane3D_DevDriv_B.xwaypoints[i] =
        optimis_Crane3D_DevDriv_P.xwaypoints[i];

      /* Constant: '<Root>/ywaypoints ' */
      optimis_Crane3D_DevDriv_B.ywaypoints[i] =
        optimis_Crane3D_DevDriv_P.ywaypoints[i];
    }

    /* Constant: '<Root>/total_waypoints ' */
    optimis_Crane3D_DevDriv_B.total_waypoints =
      optimis_Crane3D_DevDriv_P.total_waypoints;

    /* Level2 S-Function Block: '<S1>/Encoder' (Crane3D_Encoder) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[0];
      sfcnOutputs(rts, 1);
    }

    /* Gain: '<S1>/Encoder 500PPR' */
    for (i = 0; i < 5; i++) {
      rtb_Encoder500PPR[i] = optimis_Crane3D_DevDriv_P.Encoder500PPR_Gain *
        optimis_Crane3D_DevDriv_B.Encoder[i];
    }

    /* End of Gain: '<S1>/Encoder 500PPR' */

    /* Gain: '<S1>/X Scale' */
    optimis_Crane3D_DevDriv_B.XScale = optimis_Crane3D_DevDriv_P.XScale_Gain *
      rtb_Encoder500PPR[0];

    /* Constant: '<Root>/settling_time ' */
    optimis_Crane3D_DevDriv_B.settling_time =
      optimis_Crane3D_DevDriv_P.settling_time;

    /* Gain: '<S1>/Y Scale' */
    optimis_Crane3D_DevDriv_B.YScale = optimis_Crane3D_DevDriv_P.YScale_Gain *
      rtb_Encoder500PPR[1];

    /* Chart: '<Root>/HL Controller' */
    if (optimis_Crane3D_DevDriv_DW.temporalCounter_i1 < MAX_uint32_T) {
      optimis_Crane3D_DevDriv_DW.temporalCounter_i1++;
    }

    /* Gateway: HL Controller */
    optimis_Crane3D_DevDriv_DW.sfEvent = optimis_Crane3D_DevDriv_CALL_EVENT;

    /* During: HL Controller */
    if (optimis_Crane3D_DevDriv_DW.is_active_c3_optimis_Crane3D_DevDriv == 0U) {
      /* Entry: HL Controller */
      optimis_Crane3D_DevDriv_DW.is_active_c3_optimis_Crane3D_DevDriv = 1U;

      /* Entry Internal: HL Controller */
      /* Transition: '<S2>:3' */
      optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
        optimis_Crane3D_DevDriv_IN_Idle;

      /* Entry 'Idle': '<S2>:1' */
      optimis_Crane3D_DevDriv_DW.xlocal = 0.0;
      optimis_Crane3D_DevDriv_DW.ylocal = 0.0;
      optimis_Crane3D_DevDriv_B.done = 0.0;
      optimis_Crane3D_DevDriv_DW.index = 1.0;
      optimis_Crane3D_DevDriv_DW.Kd_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Kp_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Ki_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Kpa_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Kix_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Kpx_l = 0.0;
      optimis_Crane3D_DevDriv_DW.Kpax_l = 0.0;
    } else {
      switch (optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv) {
       case optimis_Crane3D_DevDriv_IN_Idle:
        /* During 'Idle': '<S2>:1' */
        if (optimis_Crane3D_DevDriv_B.start_course == 1.0) {
          /* Transition: '<S2>:158' */
          /* Exit 'Idle': '<S2>:1' */
          optimis_Crane3D_DevDriv_B.close_switch = 0.0;
          optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
            optimis_Crane3D_DevDriv_IN_S1_initialize;

          /* Entry Internal 'S1_initialize': '<S2>:26' */
          optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidy = 1U;

          /* Entry 'S1_setup_pidy': '<S2>:328' */
          optimis_Crane3D_DevDriv_func1_setpidy(optimis_Crane3D_DevDriv_B.YScale,
            optimis_Crane3D_DevDriv_B.ywaypoints[(int32_T)
            optimis_Crane3D_DevDriv_DW.index - 1]);
          optimis_Crane3D_DevDriv_DW.is_active_S1_setpoints = 1U;

          /* Entry 'S1_setpoints': '<S2>:334' */
          optimis_Crane3D_DevDriv_DW.xlocal =
            optimis_Crane3D_DevDriv_B.xwaypoints[(int32_T)
            optimis_Crane3D_DevDriv_DW.index - 1];
          optimis_Crane3D_DevDriv_DW.ylocal =
            optimis_Crane3D_DevDriv_B.ywaypoints[(int32_T)
            optimis_Crane3D_DevDriv_DW.index - 1];
          optimis_Crane3D_DevDriv_DW.arrived = 0.0;
          optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidx = 1U;

          /* Entry 'S1_setup_pidx': '<S2>:411' */
          optimis_Crane3D_DevDriv_func1_setpidx(optimis_Crane3D_DevDriv_B.XScale,
            optimis_Crane3D_DevDriv_B.xwaypoints[(int32_T)
            optimis_Crane3D_DevDriv_DW.index - 1]);
        }
        break;

       case optimis_Crane3D_DevDriv_IN_S1_initialize:
        /* During 'S1_initialize': '<S2>:26' */
        /* Transition: '<S2>:43' */
        /* Exit Internal 'S1_initialize': '<S2>:26' */
        optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidx = 0U;
        optimis_Crane3D_DevDriv_DW.is_active_S1_setpoints = 0U;
        optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidy = 0U;
        optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
          optimis_Crane3D_DevDriv_IN_S2_move_it;

        /* Entry 'S2_move_it': '<S2>:42' */
        optimis_Crane3D_DevDriv_B.xref = optimis_Crane3D_DevDriv_DW.xlocal;
        optimis_Crane3D_DevDriv_B.yref = optimis_Crane3D_DevDriv_DW.ylocal;
        optimis_Crane3D_DevDriv_B.at_waypoint = 0.0;
        optimis_Crane3D_DevDriv_B.Kdy = optimis_Crane3D_DevDriv_DW.Kd_l;
        optimis_Crane3D_DevDriv_B.Kpy = optimis_Crane3D_DevDriv_DW.Kp_l;
        optimis_Crane3D_DevDriv_B.Kiy = optimis_Crane3D_DevDriv_DW.Ki_l;
        optimis_Crane3D_DevDriv_B.Kpay = optimis_Crane3D_DevDriv_DW.Kpa_l;
        optimis_Crane3D_DevDriv_B.kix = optimis_Crane3D_DevDriv_DW.Kix_l;
        optimis_Crane3D_DevDriv_B.kpx = optimis_Crane3D_DevDriv_DW.Kpx_l;
        optimis_Crane3D_DevDriv_B.kpax = optimis_Crane3D_DevDriv_DW.Kpax_l;
        break;

       case optimis_Crane3D_DevDriv_IN_S2_move_it:
        /* During 'S2_move_it': '<S2>:42' */
        /* Transition: '<S2>:385' */
        /* Exit 'S2_move_it': '<S2>:42' */
        optimis_Crane3D_DevDriv_B.close_switch = 1.0;
        optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
          optimis_Crane3D_DevDriv_IN_S3_new_input;
        optimis_Crane3D_DevDriv_DW.temporalCounter_i1 = 0U;

        /* Entry 'S3_new_input': '<S2>:68' */
        optimis_Crane3D_DevDriv_DW.arrived = 0.0;
        break;

       case optimis_Crane3D_DevDriv_IN_S3_new_input:
        /* During 'S3_new_input': '<S2>:68' */
        if (optimis_Crane3D_DevDriv_DW.temporalCounter_i1 >= (uint32_T)ceil
            (optimis_Crane3D_DevDriv_B.settling_time / 0.01 - 1.0E-10)) {
          /* Transition: '<S2>:86' */
          optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
            optimis_Crane3D_DevDriv_IN_S4_wait1;

          /* Entry 'S4_wait1': '<S2>:84' */
          optimis_Crane3D_DevDriv_DW.index++;
          optimis_Crane3D_DevDriv_B.at_waypoint =
            optimis_Crane3D_DevDriv_DW.arrived;
        } else {
          optimis_Crane3D_DevDriv_func2_CheckArrival
            (optimis_Crane3D_DevDriv_B.XScale, optimis_Crane3D_DevDriv_B.YScale,
             optimis_Crane3D_DevDriv_DW.xlocal,
             optimis_Crane3D_DevDriv_DW.ylocal);
        }
        break;

       case optimis_Crane3D_DevDriv_IN_S4_wait1:
        /* During 'S4_wait1': '<S2>:84' */
        /* Transition: '<S2>:118' */
        optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
          optimis_Crane3D_DevDriv_IN_S5_checkifdone;

        /* Entry 'S5_checkifdone': '<S2>:117' */
        optimis_Crane3D_DevDriv_func3_CheckDone(optimis_Crane3D_DevDriv_DW.index,
          optimis_Crane3D_DevDriv_B.total_waypoints);
        break;

       case optimis_Crane3D_DevDriv_IN_S5_checkifdone:
        /* During 'S5_checkifdone': '<S2>:117' */
        if (optimis_Crane3D_DevDriv_DW.finished == 1.0) {
          /* Transition: '<S2>:156' */
          optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
            optimis_Crane3D_DevDriv_IN_S6_done;

          /* Entry 'S6_done': '<S2>:154' */
          optimis_Crane3D_DevDriv_B.done = 1.0;
        } else {
          if (optimis_Crane3D_DevDriv_DW.finished == 0.0) {
            /* Transition: '<S2>:157' */
            optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
              optimis_Crane3D_DevDriv_IN_S1_initialize;

            /* Entry Internal 'S1_initialize': '<S2>:26' */
            optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidy = 1U;

            /* Entry 'S1_setup_pidy': '<S2>:328' */
            optimis_Crane3D_DevDriv_func1_setpidy
              (optimis_Crane3D_DevDriv_B.YScale,
               optimis_Crane3D_DevDriv_B.ywaypoints[(int32_T)
               optimis_Crane3D_DevDriv_DW.index - 1]);
            optimis_Crane3D_DevDriv_DW.is_active_S1_setpoints = 1U;

            /* Entry 'S1_setpoints': '<S2>:334' */
            optimis_Crane3D_DevDriv_DW.xlocal =
              optimis_Crane3D_DevDriv_B.xwaypoints[(int32_T)
              optimis_Crane3D_DevDriv_DW.index - 1];
            optimis_Crane3D_DevDriv_DW.ylocal =
              optimis_Crane3D_DevDriv_B.ywaypoints[(int32_T)
              optimis_Crane3D_DevDriv_DW.index - 1];
            optimis_Crane3D_DevDriv_DW.arrived = 0.0;
            optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidx = 1U;

            /* Entry 'S1_setup_pidx': '<S2>:411' */
            optimis_Crane3D_DevDriv_func1_setpidx
              (optimis_Crane3D_DevDriv_B.XScale,
               optimis_Crane3D_DevDriv_B.xwaypoints[(int32_T)
               optimis_Crane3D_DevDriv_DW.index - 1]);
          }
        }
        break;

       default:
        /* During 'S6_done': '<S2>:154' */
        break;
      }
    }

    /* End of Chart: '<Root>/HL Controller' */

    /* Gain: '<S1>/X Angle Scale' */
    optimis_Crane3D_DevDriv_B.XAngleScale =
      optimis_Crane3D_DevDriv_P.XAngleScale_Gain * rtb_Encoder500PPR[3];

    /* Gain: '<S1>/Y Angle Scale' */
    optimis_Crane3D_DevDriv_B.YAngleScale =
      optimis_Crane3D_DevDriv_P.YAngleScale_Gain * rtb_Encoder500PPR[4];

    /* Start for MATLABSystem: '<Root>/Lowpass Filter2' incorporates:
     *  MATLABSystem: '<Root>/Lowpass Filter2'
     */
    i = 0;
    exitg5 = false;
    while ((exitg5 == false) && (i < 8)) {
      if (optimis_Crane3D_DevDriv_DW.obj_or.inputVarSize1[i] != 1U) {
        for (i = 0; i < 8; i++) {
          optimis_Crane3D_DevDriv_DW.obj_or.inputVarSize1[i] = 1U;
        }

        exitg5 = true;
      } else {
        i++;
      }
    }

    if (optimis_Crane3D_DevDriv_DW.obj_or.FilterObj->isInitialized != 1) {
      optimis_Crane3D_DevDriv_DW.obj_or.FilterObj->isInitialized = 1;

      /* System object Initialization function: dsp.FIRFilter */
      rtb_Derivative =
        optimis_Crane3D_DevDriv_DW.obj_or.FilterObj->cSFunObject.P0_InitialStates;
      for (i = 0; i < 317; i++) {
        optimis_Crane3D_DevDriv_DW.obj_or.FilterObj->cSFunObject.W0_states[i] =
          rtb_Derivative;
      }
    }

    obj = &optimis_Crane3D_DevDriv_DW.obj_or.FilterObj->cSFunObject;

    /* System object Outputs function: dsp.FIRFilter */
    /* Consume delay line and beginning of input samples */
    rtb_Derivative_m = 0.0;
    i = 0;
    while (i < 1) {
      rtb_Derivative = optimis_Crane3D_DevDriv_B.XAngleScale *
        obj->P1_Coefficients[0];
      rtb_Derivative_m += rtb_Derivative;
      i = 1;
    }

    for (i = 0; i < 317; i++) {
      rtb_Derivative = obj->P1_Coefficients[1 + i] * obj->W0_states[i];
      rtb_Derivative_m += rtb_Derivative;
    }

    /* Update delay line for next frame */
    for (i = 315; i >= 0; i--) {
      obj->W0_states[1 + i] = obj->W0_states[i];
    }

    optimis_Crane3D_DevDriv_DW.obj_or.FilterObj->cSFunObject.W0_states[0] =
      optimis_Crane3D_DevDriv_B.XAngleScale;

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter2' */

    /* MATLABSystem: '<Root>/Lowpass Filter2' */
    optimis_Crane3D_DevDriv_B.LowpassFilter2 = rtb_Derivative_m;

    /* Start for MATLABSystem: '<Root>/Lowpass Filter1' incorporates:
     *  MATLABSystem: '<Root>/Lowpass Filter1'
     */
    i = 0;
    exitg4 = false;
    while ((exitg4 == false) && (i < 8)) {
      if (optimis_Crane3D_DevDriv_DW.obj_o.inputVarSize1[i] != 1U) {
        for (i = 0; i < 8; i++) {
          optimis_Crane3D_DevDriv_DW.obj_o.inputVarSize1[i] = 1U;
        }

        exitg4 = true;
      } else {
        i++;
      }
    }

    if (optimis_Crane3D_DevDriv_DW.obj_o.FilterObj->isInitialized != 1) {
      optimis_Crane3D_DevDriv_DW.obj_o.FilterObj->isInitialized = 1;

      /* System object Initialization function: dsp.FIRFilter */
      rtb_Derivative =
        optimis_Crane3D_DevDriv_DW.obj_o.FilterObj->cSFunObject.P0_InitialStates;
      for (i = 0; i < 183; i++) {
        optimis_Crane3D_DevDriv_DW.obj_o.FilterObj->cSFunObject.W0_states[i] =
          rtb_Derivative;
      }
    }

    obj_0 = &optimis_Crane3D_DevDriv_DW.obj_o.FilterObj->cSFunObject;

    /* System object Outputs function: dsp.FIRFilter */
    /* Consume delay line and beginning of input samples */
    rtb_Derivative_m = 0.0;
    i = 0;
    while (i < 1) {
      rtb_Derivative = optimis_Crane3D_DevDriv_B.XAngleScale *
        obj_0->P1_Coefficients[0];
      rtb_Derivative_m += rtb_Derivative;
      i = 1;
    }

    for (i = 0; i < 183; i++) {
      rtb_Derivative = obj_0->P1_Coefficients[1 + i] * obj_0->W0_states[i];
      rtb_Derivative_m += rtb_Derivative;
    }

    /* Update delay line for next frame */
    for (i = 181; i >= 0; i--) {
      obj_0->W0_states[1 + i] = obj_0->W0_states[i];
    }

    optimis_Crane3D_DevDriv_DW.obj_o.FilterObj->cSFunObject.W0_states[0] =
      optimis_Crane3D_DevDriv_B.XAngleScale;

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter1' */

    /* MATLABSystem: '<Root>/Lowpass Filter1' */
    optimis_Crane3D_DevDriv_B.u00 = rtb_Derivative_m;

    /* Start for MATLABSystem: '<Root>/Lowpass Filter3' incorporates:
     *  MATLABSystem: '<Root>/Lowpass Filter3'
     */
    i = 0;
    exitg3 = false;
    while ((exitg3 == false) && (i < 8)) {
      if (optimis_Crane3D_DevDriv_DW.obj_a.inputVarSize1[i] != 1U) {
        for (i = 0; i < 8; i++) {
          optimis_Crane3D_DevDriv_DW.obj_a.inputVarSize1[i] = 1U;
        }

        exitg3 = true;
      } else {
        i++;
      }
    }

    if (optimis_Crane3D_DevDriv_DW.obj_a.FilterObj->isInitialized != 1) {
      optimis_Crane3D_DevDriv_DW.obj_a.FilterObj->isInitialized = 1;

      /* System object Initialization function: dsp.FIRFilter */
      rtb_Derivative =
        optimis_Crane3D_DevDriv_DW.obj_a.FilterObj->cSFunObject.P0_InitialStates;
      for (i = 0; i < 179; i++) {
        optimis_Crane3D_DevDriv_DW.obj_a.FilterObj->cSFunObject.W0_states[i] =
          rtb_Derivative;
      }
    }

    obj_1 = &optimis_Crane3D_DevDriv_DW.obj_a.FilterObj->cSFunObject;

    /* System object Outputs function: dsp.FIRFilter */
    /* Consume delay line and beginning of input samples */
    rtb_Derivative_m = 0.0;
    i = 0;
    while (i < 1) {
      rtb_Derivative = optimis_Crane3D_DevDriv_B.XAngleScale *
        obj_1->P1_Coefficients[0];
      rtb_Derivative_m += rtb_Derivative;
      i = 1;
    }

    for (i = 0; i < 179; i++) {
      rtb_Derivative = obj_1->P1_Coefficients[1 + i] * obj_1->W0_states[i];
      rtb_Derivative_m += rtb_Derivative;
    }

    /* Update delay line for next frame */
    for (i = 177; i >= 0; i--) {
      obj_1->W0_states[1 + i] = obj_1->W0_states[i];
    }

    optimis_Crane3D_DevDriv_DW.obj_a.FilterObj->cSFunObject.W0_states[0] =
      optimis_Crane3D_DevDriv_B.XAngleScale;

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter3' */

    /* MATLABSystem: '<Root>/Lowpass Filter3' */
    optimis_Crane3D_DevDriv_B.u0 = rtb_Derivative_m;

    /* Start for MATLABSystem: '<Root>/Lowpass Filter4' incorporates:
     *  MATLABSystem: '<Root>/Lowpass Filter4'
     */
    i = 0;
    exitg2 = false;
    while ((exitg2 == false) && (i < 8)) {
      if (optimis_Crane3D_DevDriv_DW.obj_b.inputVarSize1[i] != 1U) {
        for (i = 0; i < 8; i++) {
          optimis_Crane3D_DevDriv_DW.obj_b.inputVarSize1[i] = 1U;
        }

        exitg2 = true;
      } else {
        i++;
      }
    }

    if (optimis_Crane3D_DevDriv_DW.obj_b.FilterObj->isInitialized != 1) {
      optimis_Crane3D_DevDriv_DW.obj_b.FilterObj->isInitialized = 1;

      /* System object Initialization function: dsp.FIRFilter */
      rtb_Derivative =
        optimis_Crane3D_DevDriv_DW.obj_b.FilterObj->cSFunObject.P0_InitialStates;
      for (i = 0; i < 229; i++) {
        optimis_Crane3D_DevDriv_DW.obj_b.FilterObj->cSFunObject.W0_states[i] =
          rtb_Derivative;
      }
    }

    obj_2 = &optimis_Crane3D_DevDriv_DW.obj_b.FilterObj->cSFunObject;

    /* System object Outputs function: dsp.FIRFilter */
    /* Consume delay line and beginning of input samples */
    rtb_Sum_n = 0.0;
    i = 0;
    while (i < 1) {
      rtb_Derivative = optimis_Crane3D_DevDriv_B.XAngleScale *
        obj_2->P1_Coefficients[0];
      rtb_Sum_n += rtb_Derivative;
      i = 1;
    }

    for (i = 0; i < 229; i++) {
      rtb_Derivative = obj_2->P1_Coefficients[1 + i] * obj_2->W0_states[i];
      rtb_Sum_n += rtb_Derivative;
    }

    /* Update delay line for next frame */
    for (i = 227; i >= 0; i--) {
      obj_2->W0_states[1 + i] = obj_2->W0_states[i];
    }

    optimis_Crane3D_DevDriv_DW.obj_b.FilterObj->cSFunObject.W0_states[0] =
      optimis_Crane3D_DevDriv_B.XAngleScale;

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter4' */

    /* MATLABSystem: '<Root>/Lowpass Filter4' */
    optimis_Crane3D_DevDriv_B.u00_p = rtb_Sum_n;

    /* Start for MATLABSystem: '<Root>/MATLAB System' incorporates:
     *  MATLABSystem: '<Root>/MATLAB System'
     */
    i = 0;
    exitg1 = false;
    while ((exitg1 == false) && (i < 8)) {
      if (optimis_Crane3D_DevDriv_DW.obj.inputVarSize1[i] != 1U) {
        for (i = 0; i < 8; i++) {
          optimis_Crane3D_DevDriv_DW.obj.inputVarSize1[i] = 1U;
        }

        exitg1 = true;
      } else {
        i++;
      }
    }

    for (i = 0; i < 29; i++) {
      dbuffer[i + 1] = optimis_Crane3D_DevDriv_DW.obj.State[i];
      dbuffer[i] = dbuffer[i + 1];
    }

    dbuffer[29] = 0.0;
    for (i = 0; i < 30; i++) {
      dbuffer[i] += optimis_Crane3D_DevDriv_B.XAngleScale * 0.033333333333333333;
    }

    /* MATLABSystem: '<Root>/MATLAB System' incorporates:
     *  Start for MATLABSystem: '<Root>/MATLAB System'
     */
    optimis_Crane3D_DevDriv_B.ma = dbuffer[0];
    for (i = 0; i < 29; i++) {
      /* Start for MATLABSystem: '<Root>/MATLAB System' incorporates:
       *  MATLABSystem: '<Root>/MATLAB System'
       */
      optimis_Crane3D_DevDriv_DW.obj.State[i] = dbuffer[i + 1];

      /* MATLABSystem: '<Root>/MATLAB System' */
      optimis_Crane3D_DevDriv_DW.State[i] =
        optimis_Crane3D_DevDriv_DW.obj.State[i];
    }

    /* Stop: '<Root>/Stop Simulation' */
    if (optimis_Crane3D_DevDriv_B.done != 0.0) {
      rtmSetStopRequested(optimis_Crane3D_DevDriv_M, 1);
    }

    /* End of Stop: '<Root>/Stop Simulation' */

    /* Sum: '<Root>/Sum' */
    rtb_Sum_n = optimis_Crane3D_DevDriv_B.xref -
      optimis_Crane3D_DevDriv_B.XScale;

    /* Product: '<S3>/Product2' */
    optimis_Crane3D_DevDriv_B.Product2 = optimis_Crane3D_DevDriv_B.kpx *
      rtb_Sum_n;
  }

  /* Integrator: '<S3>/Integrator' */
  /* Limited  Integrator  */
  if (optimis_Crane3D_DevDriv_X.Integrator_CSTATE >=
      optimis_Crane3D_DevDriv_P.Integrator_UpperSat) {
    optimis_Crane3D_DevDriv_X.Integrator_CSTATE =
      optimis_Crane3D_DevDriv_P.Integrator_UpperSat;
  } else {
    if (optimis_Crane3D_DevDriv_X.Integrator_CSTATE <=
        optimis_Crane3D_DevDriv_P.Integrator_LowerSat) {
      optimis_Crane3D_DevDriv_X.Integrator_CSTATE =
        optimis_Crane3D_DevDriv_P.Integrator_LowerSat;
    }
  }

  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Product: '<S3>/Product1' incorporates:
     *  Constant: '<Root>/Constant'
     */
    optimis_Crane3D_DevDriv_B.Product1 = rtb_Sum_n *
      optimis_Crane3D_DevDriv_P.Constant_Value;
  }

  /* Derivative: '<S3>/Derivative' */
  if ((optimis_Crane3D_DevDriv_DW.TimeStampA >=
       optimis_Crane3D_DevDriv_M->Timing.t[0]) &&
      (optimis_Crane3D_DevDriv_DW.TimeStampB >=
       optimis_Crane3D_DevDriv_M->Timing.t[0])) {
    rtb_Derivative = 0.0;
  } else {
    rtb_Derivative_m = optimis_Crane3D_DevDriv_DW.TimeStampA;
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA;
    if (optimis_Crane3D_DevDriv_DW.TimeStampA <
        optimis_Crane3D_DevDriv_DW.TimeStampB) {
      if (optimis_Crane3D_DevDriv_DW.TimeStampB <
          optimis_Crane3D_DevDriv_M->Timing.t[0]) {
        rtb_Derivative_m = optimis_Crane3D_DevDriv_DW.TimeStampB;
        lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB;
      }
    } else {
      if (optimis_Crane3D_DevDriv_DW.TimeStampA >=
          optimis_Crane3D_DevDriv_M->Timing.t[0]) {
        rtb_Derivative_m = optimis_Crane3D_DevDriv_DW.TimeStampB;
        lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB;
      }
    }

    rtb_Derivative = (optimis_Crane3D_DevDriv_B.Product1 - *lastU) /
      (optimis_Crane3D_DevDriv_M->Timing.t[0] - rtb_Derivative_m);
  }

  /* End of Derivative: '<S3>/Derivative' */
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Product: '<Root>/Product' */
    optimis_Crane3D_DevDriv_B.Product = optimis_Crane3D_DevDriv_B.XAngleScale *
      optimis_Crane3D_DevDriv_B.kpax;

    /* Sum: '<Root>/Sum1' */
    optimis_Crane3D_DevDriv_B.Sum1 = optimis_Crane3D_DevDriv_B.yref -
      optimis_Crane3D_DevDriv_B.YScale;

    /* Product: '<S4>/Product2' */
    optimis_Crane3D_DevDriv_B.Product2_k = optimis_Crane3D_DevDriv_B.Kpy *
      optimis_Crane3D_DevDriv_B.Sum1;
  }

  /* Integrator: '<S4>/Integrator' */
  /* Limited  Integrator  */
  if (optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f >=
      optimis_Crane3D_DevDriv_P.Integrator_UpperSat_g) {
    optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f =
      optimis_Crane3D_DevDriv_P.Integrator_UpperSat_g;
  } else {
    if (optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f <=
        optimis_Crane3D_DevDriv_P.Integrator_LowerSat_d) {
      optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f =
        optimis_Crane3D_DevDriv_P.Integrator_LowerSat_d;
    }
  }

  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Product: '<S4>/Product1' */
    optimis_Crane3D_DevDriv_B.Product1_i = optimis_Crane3D_DevDriv_B.Sum1 *
      optimis_Crane3D_DevDriv_B.Kdy;
  }

  /* Derivative: '<S4>/Derivative' */
  if ((optimis_Crane3D_DevDriv_DW.TimeStampA_o >=
       optimis_Crane3D_DevDriv_M->Timing.t[0]) &&
      (optimis_Crane3D_DevDriv_DW.TimeStampB_c >=
       optimis_Crane3D_DevDriv_M->Timing.t[0])) {
    rtb_Derivative_m = 0.0;
  } else {
    rtb_Derivative_m = optimis_Crane3D_DevDriv_DW.TimeStampA_o;
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA_i;
    if (optimis_Crane3D_DevDriv_DW.TimeStampA_o <
        optimis_Crane3D_DevDriv_DW.TimeStampB_c) {
      if (optimis_Crane3D_DevDriv_DW.TimeStampB_c <
          optimis_Crane3D_DevDriv_M->Timing.t[0]) {
        rtb_Derivative_m = optimis_Crane3D_DevDriv_DW.TimeStampB_c;
        lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB_o;
      }
    } else {
      if (optimis_Crane3D_DevDriv_DW.TimeStampA_o >=
          optimis_Crane3D_DevDriv_M->Timing.t[0]) {
        rtb_Derivative_m = optimis_Crane3D_DevDriv_DW.TimeStampB_c;
        lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB_o;
      }
    }

    rtb_Derivative_m = (optimis_Crane3D_DevDriv_B.Product1_i - *lastU) /
      (optimis_Crane3D_DevDriv_M->Timing.t[0] - rtb_Derivative_m);
  }

  /* End of Derivative: '<S4>/Derivative' */
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Product: '<Root>/Product1' */
    optimis_Crane3D_DevDriv_B.Product1_ik = optimis_Crane3D_DevDriv_B.Kpay *
      optimis_Crane3D_DevDriv_B.YAngleScale;

    /* Level2 S-Function Block: '<S1>/PWM' (Crane3D_PWM) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[1];
      sfcnOutputs(rts, 1);
    }
  }

  /* Switch: '<Root>/Switch' incorporates:
   *  Constant: '<Root>/Constant'
   *  Integrator: '<S3>/Integrator'
   *  Sum: '<Root>/Add'
   *  Sum: '<S3>/Sum'
   */
  if (optimis_Crane3D_DevDriv_B.close_switch >
      optimis_Crane3D_DevDriv_P.Switch_Threshold) {
    rtb_Derivative = ((optimis_Crane3D_DevDriv_B.Product2 +
                       optimis_Crane3D_DevDriv_X.Integrator_CSTATE) +
                      rtb_Derivative) + optimis_Crane3D_DevDriv_B.Product;
  } else {
    rtb_Derivative = optimis_Crane3D_DevDriv_P.Constant_Value;
  }

  /* End of Switch: '<Root>/Switch' */

  /* Saturate: '<Root>/Saturation' */
  if (rtb_Derivative > optimis_Crane3D_DevDriv_P.Saturation_UpperSat) {
    rtb_Derivative = optimis_Crane3D_DevDriv_P.Saturation_UpperSat;
  } else {
    if (rtb_Derivative < optimis_Crane3D_DevDriv_P.Saturation_LowerSat) {
      rtb_Derivative = optimis_Crane3D_DevDriv_P.Saturation_LowerSat;
    }
  }

  /* End of Saturate: '<Root>/Saturation' */

  /* Switch: '<Root>/Switch1' incorporates:
   *  Constant: '<Root>/Constant'
   *  Integrator: '<S4>/Integrator'
   *  Sum: '<Root>/Add1'
   *  Sum: '<S4>/Sum'
   */
  if (optimis_Crane3D_DevDriv_B.close_switch >
      optimis_Crane3D_DevDriv_P.Switch1_Threshold) {
    rtb_Derivative_m = ((optimis_Crane3D_DevDriv_B.Product2_k +
                         optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f) +
                        rtb_Derivative_m) +
      optimis_Crane3D_DevDriv_B.Product1_ik;
  } else {
    rtb_Derivative_m = optimis_Crane3D_DevDriv_P.Constant_Value;
  }

  /* End of Switch: '<Root>/Switch1' */

  /* Saturate: '<Root>/Saturation1' */
  if (rtb_Derivative_m > optimis_Crane3D_DevDriv_P.Saturation1_UpperSat) {
    rtb_Derivative_m = optimis_Crane3D_DevDriv_P.Saturation1_UpperSat;
  } else {
    if (rtb_Derivative_m < optimis_Crane3D_DevDriv_P.Saturation1_LowerSat) {
      rtb_Derivative_m = optimis_Crane3D_DevDriv_P.Saturation1_LowerSat;
    }
  }

  /* End of Saturate: '<Root>/Saturation1' */

  /* Saturate: '<S1>/Saturation' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  if (rtb_Derivative > optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j) {
    optimis_Crane3D_DevDriv_B.Saturation[0] =
      optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j;
  } else if (rtb_Derivative < optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l) {
    optimis_Crane3D_DevDriv_B.Saturation[0] =
      optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l;
  } else {
    optimis_Crane3D_DevDriv_B.Saturation[0] = rtb_Derivative;
  }

  if (rtb_Derivative_m > optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j) {
    optimis_Crane3D_DevDriv_B.Saturation[1] =
      optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j;
  } else if (rtb_Derivative_m < optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l)
  {
    optimis_Crane3D_DevDriv_B.Saturation[1] =
      optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l;
  } else {
    optimis_Crane3D_DevDriv_B.Saturation[1] = rtb_Derivative_m;
  }

  if (optimis_Crane3D_DevDriv_P.Constant2_Value >
      optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j) {
    optimis_Crane3D_DevDriv_B.Saturation[2] =
      optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j;
  } else if (optimis_Crane3D_DevDriv_P.Constant2_Value <
             optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l) {
    optimis_Crane3D_DevDriv_B.Saturation[2] =
      optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l;
  } else {
    optimis_Crane3D_DevDriv_B.Saturation[2] =
      optimis_Crane3D_DevDriv_P.Constant2_Value;
  }

  /* End of Saturate: '<S1>/Saturation' */
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    /* Level2 S-Function Block: '<S1>/LimitFlag' (Crane3D_LimitFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[2];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[0] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[0];

    /* Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[0] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[0];

    /* Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[1] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[1];

    /* Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[1] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[1];

    /* Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[2] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[2];

    /* Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[2] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[2];

    /* Level2 S-Function Block: '<S1>/SetLimit' (Crane3D_SetLimit) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[3];
      sfcnOutputs(rts, 1);
    }

    /* Level2 S-Function Block: '<S1>/LimitSwitch' (Crane3D_Switch) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[4];
      sfcnOutputs(rts, 1);
    }

    /* Level2 S-Function Block: '<S1>/PWMPrescaler' (Crane3D_PWMPrescaler) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[5];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/PWMPrescalerSource' */
    optimis_Crane3D_DevDriv_B.PWMPrescalerSource =
      optimis_Crane3D_DevDriv_P.PWMPrescalerSource_Value;

    /* Level2 S-Function Block: '<S1>/ResetEncoder' (Crane3D_ResetEncoder) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[6];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/ResetSource' */
    for (i = 0; i < 5; i++) {
      optimis_Crane3D_DevDriv_B.ResetSource[i] =
        optimis_Crane3D_DevDriv_P.ResetSource_Value[i];
    }

    /* End of Constant: '<S1>/ResetSource' */

    /* Level2 S-Function Block: '<S1>/ResetSwitchFlag ' (Crane3D_ResetSwitchFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[7];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/ResetSwitchFlagSource' */
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[0] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[0];
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[1] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[1];
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[2] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[2];

    /* Level2 S-Function Block: '<S1>/ThermFlag ' (Crane3D_ThermFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[8];
      sfcnOutputs(rts, 1);
    }

    /* Constant: '<S1>/ThermFlagSource' */
    optimis_Crane3D_DevDriv_B.ThermFlagSource[0] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[0];
    optimis_Crane3D_DevDriv_B.ThermFlagSource[1] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[1];
    optimis_Crane3D_DevDriv_B.ThermFlagSource[2] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[2];

    /* Product: '<S3>/Product' */
    optimis_Crane3D_DevDriv_B.Product_f = optimis_Crane3D_DevDriv_B.kix *
      rtb_Sum_n;

    /* Product: '<S4>/Product' */
    optimis_Crane3D_DevDriv_B.Product_c = optimis_Crane3D_DevDriv_B.Kiy *
      optimis_Crane3D_DevDriv_B.Sum1;
  }

  /* Clock: '<Root>/Clock' */
  optimis_Crane3D_DevDriv_B.Clock = optimis_Crane3D_DevDriv_M->Timing.t[0];
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
  }
}

/* Model update function */
void optimis_Crane3D_DevDriv_update(void)
{
  real_T *lastU;

  /* Update for Derivative: '<S3>/Derivative' */
  if (optimis_Crane3D_DevDriv_DW.TimeStampA == (rtInf)) {
    optimis_Crane3D_DevDriv_DW.TimeStampA = optimis_Crane3D_DevDriv_M->Timing.t
      [0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA;
  } else if (optimis_Crane3D_DevDriv_DW.TimeStampB == (rtInf)) {
    optimis_Crane3D_DevDriv_DW.TimeStampB = optimis_Crane3D_DevDriv_M->Timing.t
      [0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB;
  } else if (optimis_Crane3D_DevDriv_DW.TimeStampA <
             optimis_Crane3D_DevDriv_DW.TimeStampB) {
    optimis_Crane3D_DevDriv_DW.TimeStampA = optimis_Crane3D_DevDriv_M->Timing.t
      [0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA;
  } else {
    optimis_Crane3D_DevDriv_DW.TimeStampB = optimis_Crane3D_DevDriv_M->Timing.t
      [0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB;
  }

  *lastU = optimis_Crane3D_DevDriv_B.Product1;

  /* End of Update for Derivative: '<S3>/Derivative' */

  /* Update for Derivative: '<S4>/Derivative' */
  if (optimis_Crane3D_DevDriv_DW.TimeStampA_o == (rtInf)) {
    optimis_Crane3D_DevDriv_DW.TimeStampA_o =
      optimis_Crane3D_DevDriv_M->Timing.t[0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA_i;
  } else if (optimis_Crane3D_DevDriv_DW.TimeStampB_c == (rtInf)) {
    optimis_Crane3D_DevDriv_DW.TimeStampB_c =
      optimis_Crane3D_DevDriv_M->Timing.t[0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB_o;
  } else if (optimis_Crane3D_DevDriv_DW.TimeStampA_o <
             optimis_Crane3D_DevDriv_DW.TimeStampB_c) {
    optimis_Crane3D_DevDriv_DW.TimeStampA_o =
      optimis_Crane3D_DevDriv_M->Timing.t[0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeA_i;
  } else {
    optimis_Crane3D_DevDriv_DW.TimeStampB_c =
      optimis_Crane3D_DevDriv_M->Timing.t[0];
    lastU = &optimis_Crane3D_DevDriv_DW.LastUAtTimeB_o;
  }

  *lastU = optimis_Crane3D_DevDriv_B.Product1_i;

  /* End of Update for Derivative: '<S4>/Derivative' */
  if (rtmIsMajorTimeStep(optimis_Crane3D_DevDriv_M)) {
    rt_ertODEUpdateContinuousStates(&optimis_Crane3D_DevDriv_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++optimis_Crane3D_DevDriv_M->Timing.clockTick0)) {
    ++optimis_Crane3D_DevDriv_M->Timing.clockTickH0;
  }

  optimis_Crane3D_DevDriv_M->Timing.t[0] = rtsiGetSolverStopTime
    (&optimis_Crane3D_DevDriv_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++optimis_Crane3D_DevDriv_M->Timing.clockTick1)) {
      ++optimis_Crane3D_DevDriv_M->Timing.clockTickH1;
    }

    optimis_Crane3D_DevDriv_M->Timing.t[1] =
      optimis_Crane3D_DevDriv_M->Timing.clockTick1 *
      optimis_Crane3D_DevDriv_M->Timing.stepSize1 +
      optimis_Crane3D_DevDriv_M->Timing.clockTickH1 *
      optimis_Crane3D_DevDriv_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void optimis_Crane3D_DevDriv_derivatives(void)
{
  boolean_T lsat;
  boolean_T usat;
  XDot_optimis_Crane3D_DevDriv_T *_rtXdot;
  _rtXdot = ((XDot_optimis_Crane3D_DevDriv_T *)
             optimis_Crane3D_DevDriv_M->ModelData.derivs);

  /* Derivatives for Integrator: '<S3>/Integrator' */
  lsat = (optimis_Crane3D_DevDriv_X.Integrator_CSTATE <=
          optimis_Crane3D_DevDriv_P.Integrator_LowerSat);
  usat = (optimis_Crane3D_DevDriv_X.Integrator_CSTATE >=
          optimis_Crane3D_DevDriv_P.Integrator_UpperSat);
  if (((!lsat) && (!usat)) || (lsat && (optimis_Crane3D_DevDriv_B.Product_f >
        0.0)) || (usat && (optimis_Crane3D_DevDriv_B.Product_f < 0.0))) {
    _rtXdot->Integrator_CSTATE = optimis_Crane3D_DevDriv_B.Product_f;
  } else {
    /* in saturation */
    _rtXdot->Integrator_CSTATE = 0.0;
  }

  /* End of Derivatives for Integrator: '<S3>/Integrator' */

  /* Derivatives for Integrator: '<S4>/Integrator' */
  lsat = (optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f <=
          optimis_Crane3D_DevDriv_P.Integrator_LowerSat_d);
  usat = (optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f >=
          optimis_Crane3D_DevDriv_P.Integrator_UpperSat_g);
  if (((!lsat) && (!usat)) || (lsat && (optimis_Crane3D_DevDriv_B.Product_c >
        0.0)) || (usat && (optimis_Crane3D_DevDriv_B.Product_c < 0.0))) {
    _rtXdot->Integrator_CSTATE_f = optimis_Crane3D_DevDriv_B.Product_c;
  } else {
    /* in saturation */
    _rtXdot->Integrator_CSTATE_f = 0.0;
  }

  /* End of Derivatives for Integrator: '<S4>/Integrator' */
}

/* Model initialize function */
void optimis_Crane3D_DevDriv_initialize(void)
{
  {
    dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv4_T *iobj_0;
    dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_kv_T *iobj_0_0;
    dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_k_T *iobj_0_1;
    dspcodegen_FIRFilter_optimis_Crane3D_DevDriv_T *iobj_0_2;
    int32_T i;
    static const real_T tmp[318] = { 6.0993180294656731E-5,
      2.7670146935033298E-5, 3.3548835555932635E-5, 3.9937452672456289E-5,
      4.6791606327360532E-5, 5.4052337798716723E-5, 6.1650805463293754E-5,
      6.9499647538234669E-5, 7.7489828546128682E-5, 8.5505353579902379E-5,
      9.34119345288878E-5, 0.0001010520031514249, 0.00010826486918382385,
      0.00011486474068440613, 0.00012066616788727969, 0.00012546335360465616,
      0.00012904957719045063, 0.00013120972950391907, 0.0001317275561851486,
      0.00013038759924218114, 0.0001269768653905337, 0.0001212916318090078,
      0.00011314047209882998, 0.00010234786658387939, 8.8759512949545857E-5,
      7.2242749788472646E-5, 5.2695313551610168E-5, 3.0045661652630079E-5,
      4.260885091420487E-6, -2.46528081402922E-5, -5.6645259558263667E-5,
      -9.1619957081604255E-5, -0.00012943163260063204, -0.00016988256266866993,
      -0.00021272249416914754, -0.00025764517191006965, -0.00030429023019397762,
      -0.00035224204793541389, -0.00040103278638681933, -0.0004501437877973784,
      -0.0004990073887395464, -0.00054701132623058424, -0.00059350209584505464,
      -0.00063779295312050882, -0.00067917066824564132, -0.00071690038704737692,
      -0.00075023707639613785, -0.00077842656097510733, -0.00080072629379604194,
      -0.00081640492123306993, -0.00082476358865943386, -0.00082513620134906868,
      -0.00081690424780147338, -0.00079950991684781046, -0.00077246445400775256,
      -0.00073536537441002564, -0.00068790277102766337, -0.00062985622127846249,
      -0.0005611425349022251, -0.00048175743563436916, -0.00039190807500728343,
      -0.00029182063428816543, -0.000181961084831513, -6.29128243690733E-5,
      6.4624275230859069E-5, 0.00019977628019913644, 0.00034150968015177121,
      0.0004886618294248355, 0.00063995001047128641, 0.00079393581500112741,
      0.0009490357186789913, 0.0011036036032513212, 0.0012558538579375564,
      0.0014039421170426907, 0.0015459284094883083, 0.001679837295382135,
      0.0018036616374591356, 0.0019153886737657267, 0.00201301986061668,
      0.0020945894410488823, 0.0021581949024973603, 0.0022020243323376473,
      0.0022243796824177467, 0.0022237060121889697, 0.0021986072367978894,
      0.0021478794570652269, 0.0020705297390861185, 0.0019658068681540318,
      0.0018332197505247587, 0.0016725579849848284, 0.0014839085278884607,
      0.0012676694027544527, 0.0010245639699284896, 0.000755649707734556,
      0.00046232644329788645, 0.00014633977343139943, -0.00019021910589017018,
      -0.000544916195565303, -0.000914983189859026, -0.0012973263841262661,
      -0.0016885426652622198, -0.0020849370496313418, -0.0024825469427331923,
      -0.0028771701292296245, -0.00326439306816668, -0.003639626439521172,
      -0.00399813454100072, -0.00433507831988893, -0.004645550080122773,
      -0.0049246227629045607, -0.0051673939405939449, -0.005369035916698928,
      -0.00552484604262651, -0.0056302898755702206, -0.0056810467865101473,
      -0.0056730535383026862, -0.0056025453238308914, -0.0054661227627227551,
      -0.0052607777124510108, -0.0049839683254474321, -0.0046336056212554107,
      -0.004208115466089987, -0.0037064355958101088, -0.0031280678563856022,
      -0.0024731486881144687, -0.0017424350740314204, -0.00093724390233042027,
      -5.9452052265944678E-5, 0.00088834436067106225, 0.0019027974341172414,
      0.0029803751472031563, 0.004116477247753686, 0.0053062583206468636,
      0.0065441933533923781, 0.0078242960610868818, 0.0091400979953495769,
      0.010484710338468709, 0.011850874693089335, 0.01323100216309182,
      0.014617236229338176, 0.016001515327072554, 0.0173756253555577,
      0.01873127706153074, 0.020060153057157554, 0.021353991217080273,
      0.022604639245676822, 0.023804130880825197, 0.024944745904798366,
      0.026019074746884849, 0.027020081459984177, 0.027941161561825925,
      0.028776199854410378, 0.029519621212843822, 0.030166436916403486,
      0.030712289151353413, 0.031153485918758685, 0.031487036241342956,
      0.031710672640186094, 0.0318228732701098, 0.0318228732701098,
      0.031710672640186094, 0.031487036241342956, 0.031153485918758685,
      0.030712289151353413, 0.030166436916403486, 0.029519621212843822,
      0.028776199854410378, 0.027941161561825925, 0.027020081459984177,
      0.026019074746884849, 0.024944745904798366, 0.023804130880825197,
      0.022604639245676822, 0.021353991217080273, 0.020060153057157554,
      0.01873127706153074, 0.0173756253555577, 0.016001515327072554,
      0.014617236229338176, 0.01323100216309182, 0.011850874693089335,
      0.010484710338468709, 0.0091400979953495769, 0.0078242960610868818,
      0.0065441933533923781, 0.0053062583206468636, 0.004116477247753686,
      0.0029803751472031563, 0.0019027974341172414, 0.00088834436067106225,
      -5.9452052265944678E-5, -0.00093724390233042027, -0.0017424350740314204,
      -0.0024731486881144687, -0.0031280678563856022, -0.0037064355958101088,
      -0.004208115466089987, -0.0046336056212554107, -0.0049839683254474321,
      -0.0052607777124510108, -0.0054661227627227551, -0.0056025453238308914,
      -0.0056730535383026862, -0.0056810467865101473, -0.0056302898755702206,
      -0.00552484604262651, -0.005369035916698928, -0.0051673939405939449,
      -0.0049246227629045607, -0.004645550080122773, -0.00433507831988893,
      -0.00399813454100072, -0.003639626439521172, -0.00326439306816668,
      -0.0028771701292296245, -0.0024825469427331923, -0.0020849370496313418,
      -0.0016885426652622198, -0.0012973263841262661, -0.000914983189859026,
      -0.000544916195565303, -0.00019021910589017018, 0.00014633977343139943,
      0.00046232644329788645, 0.000755649707734556, 0.0010245639699284896,
      0.0012676694027544527, 0.0014839085278884607, 0.0016725579849848284,
      0.0018332197505247587, 0.0019658068681540318, 0.0020705297390861185,
      0.0021478794570652269, 0.0021986072367978894, 0.0022237060121889697,
      0.0022243796824177467, 0.0022020243323376473, 0.0021581949024973603,
      0.0020945894410488823, 0.00201301986061668, 0.0019153886737657267,
      0.0018036616374591356, 0.001679837295382135, 0.0015459284094883083,
      0.0014039421170426907, 0.0012558538579375564, 0.0011036036032513212,
      0.0009490357186789913, 0.00079393581500112741, 0.00063995001047128641,
      0.0004886618294248355, 0.00034150968015177121, 0.00019977628019913644,
      6.4624275230859069E-5, -6.29128243690733E-5, -0.000181961084831513,
      -0.00029182063428816543, -0.00039190807500728343, -0.00048175743563436916,
      -0.0005611425349022251, -0.00062985622127846249, -0.00068790277102766337,
      -0.00073536537441002564, -0.00077246445400775256, -0.00079950991684781046,
      -0.00081690424780147338, -0.00082513620134906868, -0.00082476358865943386,
      -0.00081640492123306993, -0.00080072629379604194, -0.00077842656097510733,
      -0.00075023707639613785, -0.00071690038704737692, -0.00067917066824564132,
      -0.00063779295312050882, -0.00059350209584505464, -0.00054701132623058424,
      -0.0004990073887395464, -0.0004501437877973784, -0.00040103278638681933,
      -0.00035224204793541389, -0.00030429023019397762, -0.00025764517191006965,
      -0.00021272249416914754, -0.00016988256266866993, -0.00012943163260063204,
      -9.1619957081604255E-5, -5.6645259558263667E-5, -2.46528081402922E-5,
      4.260885091420487E-6, 3.0045661652630079E-5, 5.2695313551610168E-5,
      7.2242749788472646E-5, 8.8759512949545857E-5, 0.00010234786658387939,
      0.00011314047209882998, 0.0001212916318090078, 0.0001269768653905337,
      0.00013038759924218114, 0.0001317275561851486, 0.00013120972950391907,
      0.00012904957719045063, 0.00012546335360465616, 0.00012066616788727969,
      0.00011486474068440613, 0.00010826486918382385, 0.0001010520031514249,
      9.34119345288878E-5, 8.5505353579902379E-5, 7.7489828546128682E-5,
      6.9499647538234669E-5, 6.1650805463293754E-5, 5.4052337798716723E-5,
      4.6791606327360532E-5, 3.9937452672456289E-5, 3.3548835555932635E-5,
      2.7670146935033298E-5, 6.0993180294656731E-5 };

    static const real_T tmp_0[184] = { -6.5832063820294307E-5,
      -4.05359299102213E-5, -5.2614390107875509E-5, -6.6739674102163628E-5,
      -8.3075314416404953E-5, -0.00010177717145812027, -0.00012299005907100274,
      -0.00014684528586309082, -0.00017344978193441302, -0.00020289494061997922,
      -0.00023523310049893036, -0.00027050686193444461, -0.00030870159340322818,
      -0.00034978324625331586, -0.0003936580416882418, -0.00044019198970543527,
      -0.00048920819522462367, -0.00054046237948760965, -0.00059365949926768109,
      -0.00064844474390992734, -0.00070440236582023415, -0.00076104783406234918,
      -0.00081783659346813266, -0.00087414721098245691, -0.00092929999082224789,
      -0.000982548237748339, -0.001033074812977414, -0.0010799989322459202,
      -0.0011223788769098835, -0.0011592239541811005, -0.0011894731257738249,
      -0.0012120243391099028, -0.0012257343611694338, -0.0012294190584301772,
      -0.0012218590464883397, -0.0012018294694666923, -0.0011680783667648183,
      -0.0011193485589826382, -0.0010544157064280712, -0.00097202998223506153,
      -0.000871008149741243, -0.00075017485469011766, -0.00060842704635043513,
      -0.00044471045433985921, -0.00025804845796414066, -4.75488942787051E-5,
      0.00018759134246485243, 0.00044803300246606666, 0.00073443046534393038,
      0.0010470559885335056, 0.001386450469808365, 0.0017525656859591681,
      0.0021454532349827983, 0.0025650277583620516, 0.0030109101997601367,
      0.0034825588362512789, 0.0039793183794453717, 0.0045003608688456362,
      0.0050446311620474015, 0.0056108906738593263, 0.0061977276702185257,
      0.0068035871811758224, 0.0074267301500699039, 0.0080652435654357344,
      0.0087170490596640889, 0.0093799205014481572, 0.010051512592720512,
      0.010729351847056425, 0.011410852369317912, 0.012093327037568666,
      0.012774008313482191, 0.013450052976580189, 0.014118573940573444,
      0.014776651375848212, 0.015421363065146448, 0.016049799003507236,
      0.01665906014377002, 0.017246290667332187, 0.017808696461897,
      0.018343589045811438, 0.018848366144272925, 0.019320539919662771,
      0.019757778432289933, 0.020157914764871818, 0.020518912980947344,
      0.020838939133620886, 0.02111639024779953, 0.021349792773420549,
      0.021537993151788472, 0.021679988639985385, 0.0217750643267125,
      0.021822722864228788, 0.021822722864228788, 0.0217750643267125,
      0.021679988639985385, 0.021537993151788472, 0.021349792773420549,
      0.02111639024779953, 0.020838939133620886, 0.020518912980947344,
      0.020157914764871818, 0.019757778432289933, 0.019320539919662771,
      0.018848366144272925, 0.018343589045811438, 0.017808696461897,
      0.017246290667332187, 0.01665906014377002, 0.016049799003507236,
      0.015421363065146448, 0.014776651375848212, 0.014118573940573444,
      0.013450052976580189, 0.012774008313482191, 0.012093327037568666,
      0.011410852369317912, 0.010729351847056425, 0.010051512592720512,
      0.0093799205014481572, 0.0087170490596640889, 0.0080652435654357344,
      0.0074267301500699039, 0.0068035871811758224, 0.0061977276702185257,
      0.0056108906738593263, 0.0050446311620474015, 0.0045003608688456362,
      0.0039793183794453717, 0.0034825588362512789, 0.0030109101997601367,
      0.0025650277583620516, 0.0021454532349827983, 0.0017525656859591681,
      0.001386450469808365, 0.0010470559885335056, 0.00073443046534393038,
      0.00044803300246606666, 0.00018759134246485243, -4.75488942787051E-5,
      -0.00025804845796414066, -0.00044471045433985921, -0.00060842704635043513,
      -0.00075017485469011766, -0.000871008149741243, -0.00097202998223506153,
      -0.0010544157064280712, -0.0011193485589826382, -0.0011680783667648183,
      -0.0012018294694666923, -0.0012218590464883397, -0.0012294190584301772,
      -0.0012257343611694338, -0.0012120243391099028, -0.0011894731257738249,
      -0.0011592239541811005, -0.0011223788769098835, -0.0010799989322459202,
      -0.001033074812977414, -0.000982548237748339, -0.00092929999082224789,
      -0.00087414721098245691, -0.00081783659346813266, -0.00076104783406234918,
      -0.00070440236582023415, -0.00064844474390992734, -0.00059365949926768109,
      -0.00054046237948760965, -0.00048920819522462367, -0.00044019198970543527,
      -0.0003936580416882418, -0.00034978324625331586, -0.00030870159340322818,
      -0.00027050686193444461, -0.00023523310049893036, -0.00020289494061997922,
      -0.00017344978193441302, -0.00014684528586309082, -0.00012299005907100274,
      -0.00010177717145812027, -8.3075314416404953E-5, -6.6739674102163628E-5,
      -5.2614390107875509E-5, -4.05359299102213E-5, -6.5832063820294307E-5 };

    static const real_T tmp_1[180] = { -6.4685528284945122E-5,
      -3.7901786645457888E-5, -4.8607513891221552E-5, -6.0981102282028615E-5,
      -7.5134536390084926E-5, -9.1154533924794773E-5, -0.00010911288356720274,
      -0.00012907499397969081, -0.00015106386947893522, -0.00017509545899201554,
      -0.00020113765477189547, -0.00022914461995376056, -0.0002590220190237578,
      -0.00029064021566679453, -0.00032382561408644784, -0.00035835942180820679,
      -0.0003939780074608952, -0.00043035976294234022, -0.00046713603496019896,
      -0.00050387855613774786, -0.00054010834003538643, -0.00057528587011131235,
      -0.00060881778552132073, -0.00064005473921340179, -0.00066828899276019258,
      -0.00069275965279975722, -0.00071264996487274386, -0.00072710160310252079,
      -0.00073520603771820483, -0.0007360166973997581, -0.00072854619364196667,
      -0.000711780515642069, -0.00068468233389287563, -0.00064619054584045513,
      -0.00059523820581698726, -0.00053074871842220676, -0.00045166776980686224,
      -0.00035694096445634344, -0.00024554935624649781, -0.00011650273392565342,
      3.1139052836309771E-5, 0.00019824945785470131, 0.00038570553870597931,
      0.0005941393943535182, 0.00082441443625542858, 0.0010768661979842829,
      0.0013521085936034896, 0.0016505015670064127, 0.0019722028820531368,
      0.0023173241049278875, 0.0026858662620382048, 0.0030776799979278452,
      0.0034923941105345379, 0.0039295318611926016, 0.0043884657331017089,
      0.0048684326721342795, 0.0053684882142244908, 0.0058875175764090439,
      0.0064242548604853678, 0.00697728679172268, 0.0075450648745102678,
      0.0081258886119803635, 0.0087179217474837485, 0.0093191892923722847,
      0.0099275979462578635, 0.010540945469229956, 0.011156936180023206,
      0.011773195305399541, 0.012387273672204014, 0.012996666965774208,
      0.013598821114075692, 0.014191157938865624, 0.014771084523775808,
      0.015336020318471991, 0.0158834129308946, 0.016410752348712081,
      0.016915585089922712, 0.017395519791582003, 0.017848262859662505,
      0.018271623807341271, 0.018663545569683748, 0.019022094719328055,
      0.019345491047757027, 0.019632126564959655, 0.019880565852913694,
      0.0200895755442122, 0.020258057096653341, 0.020385196607903444,
      0.020470308192672981, 0.020512985267553102, 0.020512985267553102,
      0.020470308192672981, 0.020385196607903444, 0.020258057096653341,
      0.0200895755442122, 0.019880565852913694, 0.019632126564959655,
      0.019345491047757027, 0.019022094719328055, 0.018663545569683748,
      0.018271623807341271, 0.017848262859662505, 0.017395519791582003,
      0.016915585089922712, 0.016410752348712081, 0.0158834129308946,
      0.015336020318471991, 0.014771084523775808, 0.014191157938865624,
      0.013598821114075692, 0.012996666965774208, 0.012387273672204014,
      0.011773195305399541, 0.011156936180023206, 0.010540945469229956,
      0.0099275979462578635, 0.0093191892923722847, 0.0087179217474837485,
      0.0081258886119803635, 0.0075450648745102678, 0.00697728679172268,
      0.0064242548604853678, 0.0058875175764090439, 0.0053684882142244908,
      0.0048684326721342795, 0.0043884657331017089, 0.0039295318611926016,
      0.0034923941105345379, 0.0030776799979278452, 0.0026858662620382048,
      0.0023173241049278875, 0.0019722028820531368, 0.0016505015670064127,
      0.0013521085936034896, 0.0010768661979842829, 0.00082441443625542858,
      0.0005941393943535182, 0.00038570553870597931, 0.00019824945785470131,
      3.1139052836309771E-5, -0.00011650273392565342, -0.00024554935624649781,
      -0.00035694096445634344, -0.00045166776980686224, -0.00053074871842220676,
      -0.00059523820581698726, -0.00064619054584045513, -0.00068468233389287563,
      -0.000711780515642069, -0.00072854619364196667, -0.0007360166973997581,
      -0.00073520603771820483, -0.00072710160310252079, -0.00071264996487274386,
      -0.00069275965279975722, -0.00066828899276019258, -0.00064005473921340179,
      -0.00060881778552132073, -0.00057528587011131235, -0.00054010834003538643,
      -0.00050387855613774786, -0.00046713603496019896, -0.00043035976294234022,
      -0.0003939780074608952, -0.00035835942180820679, -0.00032382561408644784,
      -0.00029064021566679453, -0.0002590220190237578, -0.00022914461995376056,
      -0.00020113765477189547, -0.00017509545899201554, -0.00015106386947893522,
      -0.00012907499397969081, -0.00010911288356720274, -9.1154533924794773E-5,
      -7.5134536390084926E-5, -6.0981102282028615E-5, -4.8607513891221552E-5,
      -3.7901786645457888E-5, -6.4685528284945122E-5 };

    static const real_T tmp_2[230] = { 6.357302992977705E-5,
      3.5491409528551326E-5, 4.49906472530147E-5, 5.5837756308079079E-5,
      6.8091888162968649E-5, 8.1786230930722115E-5, 9.69409956042E-5,
      0.00011354971661896638, 0.00013158810916945551, 0.00015100733589213614,
      0.00017172589021793465, 0.00019363211306500504, 0.00021658261716176017,
      0.00024039950379870607, 0.00026487420242358593, 0.00028976043249421564,
      0.00031476682184176561, 0.00033956537161120817, 0.00036379951578905973,
      0.00038707998079355881, 0.00040897924258927025, 0.00042902990986315112,
      0.0004467335951562627, 0.00046157843642576589, 0.00047303334055844492,
      0.0004805321498471271, 0.00048349691358269488, 0.0004813679438302458,
      0.00047357522903320273, 0.00045953075681350844, 0.00043869158287382251,
      0.00041055348436552856, 0.00037456562539550946, 0.00033032733044654187,
      0.00027738737551657794, 0.00021542544099919915, 0.00014414167887261516,
      6.3340472806155691E-5, -2.7108449678091616E-5, -0.00012722709690081262,
      -0.00023693863778881662, -0.00035606183916468156, -0.00048429227167928193,
      -0.00062120057326990044, -0.00076623181106432879, -0.00091869468511282808,
      -0.0010777618751737837, -0.001242468707521971, -0.0014117060700051145,
      -0.0015842248127290758, -0.0017586416367944427, -0.0019334334927635954,
      -0.0021069433629815051, -0.0022773959132933092, -0.0024428979906570064,
      -0.0026014426992594687, -0.00275093078919915, -0.0028891819637608916,
      -0.0030139383259796954, -0.0031228896319780925, -0.0032136914781477248,
      -0.003283971192936436, -0.0033313573103989904, -0.0033535065307228884,
      -0.0033480883684634038, -0.0033128644840654865, -0.003245642111640871,
      -0.0031443704120749528, -0.0030070734850199633, -0.0028319747096494747,
      -0.0026174201740154918, -0.0023619681511949779, -0.0020643860509915908,
      -0.0017236521257514683, -0.0013389984528639053, -0.00090992498431644248,
      -0.00043619351610746664, 8.2146070979222373E-5, 0.00064473646920087642,
      0.00125091942567867, 0.0018997303690833824, 0.0025898818808088478,
      0.0033197668631297526, 0.0040874665660680957, 0.0048907499492796495,
      0.0057270785255031193, 0.0065936161869052188, 0.0074872412188815235,
      0.0084045669135929361, 0.0093419594871061631, 0.010295547333947126,
      0.011261246762907354, 0.012234793161274843, 0.013211759595160529,
      0.014187583959536093, 0.015157606664338626, 0.01611708241150844,
      0.017061259146019102, 0.017985297812836157, 0.01888459202959223,
      0.019754222117299297, 0.020589826642273726, 0.021386824501157857,
      0.022140854253215853, 0.022847862886336674, 0.023503980133913128,
      0.024105524114582215, 0.024649113366145926, 0.025131712899773184,
      0.025550617533719476, 0.025903446442650684, 0.026188166974095792,
      0.0264031324703912, 0.026547114690623784, 0.026619306166985747,
      0.026619306166985747, 0.026547114690623784, 0.0264031324703912,
      0.026188166974095792, 0.025903446442650684, 0.025550617533719476,
      0.025131712899773184, 0.024649113366145926, 0.024105524114582215,
      0.023503980133913128, 0.022847862886336674, 0.022140854253215853,
      0.021386824501157857, 0.020589826642273726, 0.019754222117299297,
      0.01888459202959223, 0.017985297812836157, 0.017061259146019102,
      0.01611708241150844, 0.015157606664338626, 0.014187583959536093,
      0.013211759595160529, 0.012234793161274843, 0.011261246762907354,
      0.010295547333947126, 0.0093419594871061631, 0.0084045669135929361,
      0.0074872412188815235, 0.0065936161869052188, 0.0057270785255031193,
      0.0048907499492796495, 0.0040874665660680957, 0.0033197668631297526,
      0.0025898818808088478, 0.0018997303690833824, 0.00125091942567867,
      0.00064473646920087642, 8.2146070979222373E-5, -0.00043619351610746664,
      -0.00090992498431644248, -0.0013389984528639053, -0.0017236521257514683,
      -0.0020643860509915908, -0.0023619681511949779, -0.0026174201740154918,
      -0.0028319747096494747, -0.0030070734850199633, -0.0031443704120749528,
      -0.003245642111640871, -0.0033128644840654865, -0.0033480883684634038,
      -0.0033535065307228884, -0.0033313573103989904, -0.003283971192936436,
      -0.0032136914781477248, -0.0031228896319780925, -0.0030139383259796954,
      -0.0028891819637608916, -0.00275093078919915, -0.0026014426992594687,
      -0.0024428979906570064, -0.0022773959132933092, -0.0021069433629815051,
      -0.0019334334927635954, -0.0017586416367944427, -0.0015842248127290758,
      -0.0014117060700051145, -0.001242468707521971, -0.0010777618751737837,
      -0.00091869468511282808, -0.00076623181106432879, -0.00062120057326990044,
      -0.00048429227167928193, -0.00035606183916468156, -0.00023693863778881662,
      -0.00012722709690081262, -2.7108449678091616E-5, 6.3340472806155691E-5,
      0.00014414167887261516, 0.00021542544099919915, 0.00027738737551657794,
      0.00033032733044654187, 0.00037456562539550946, 0.00041055348436552856,
      0.00043869158287382251, 0.00045953075681350844, 0.00047357522903320273,
      0.0004813679438302458, 0.00048349691358269488, 0.0004805321498471271,
      0.00047303334055844492, 0.00046157843642576589, 0.0004467335951562627,
      0.00042902990986315112, 0.00040897924258927025, 0.00038707998079355881,
      0.00036379951578905973, 0.00033956537161120817, 0.00031476682184176561,
      0.00028976043249421564, 0.00026487420242358593, 0.00024039950379870607,
      0.00021658261716176017, 0.00019363211306500504, 0.00017172589021793465,
      0.00015100733589213614, 0.00013158810916945551, 0.00011354971661896638,
      9.69409956042E-5, 8.1786230930722115E-5, 6.8091888162968649E-5,
      5.5837756308079079E-5, 4.49906472530147E-5, 3.5491409528551326E-5,
      6.357302992977705E-5 };

    static const real_T tmp_3[318] = { 6.0993180294656731E-5,
      2.7670146935033298E-5, 3.3548835555932635E-5, 3.9937452672456289E-5,
      4.6791606327360532E-5, 5.4052337798716723E-5, 6.1650805463293754E-5,
      6.9499647538234669E-5, 7.7489828546128682E-5, 8.5505353579902379E-5,
      9.34119345288878E-5, 0.0001010520031514249, 0.00010826486918382385,
      0.00011486474068440613, 0.00012066616788727969, 0.00012546335360465616,
      0.00012904957719045063, 0.00013120972950391907, 0.0001317275561851486,
      0.00013038759924218114, 0.0001269768653905337, 0.0001212916318090078,
      0.00011314047209882998, 0.00010234786658387939, 8.8759512949545857E-5,
      7.2242749788472646E-5, 5.2695313551610168E-5, 3.0045661652630079E-5,
      4.260885091420487E-6, -2.46528081402922E-5, -5.6645259558263667E-5,
      -9.1619957081604255E-5, -0.00012943163260063204, -0.00016988256266866993,
      -0.00021272249416914754, -0.00025764517191006965, -0.00030429023019397762,
      -0.00035224204793541389, -0.00040103278638681933, -0.0004501437877973784,
      -0.0004990073887395464, -0.00054701132623058424, -0.00059350209584505464,
      -0.00063779295312050882, -0.00067917066824564132, -0.00071690038704737692,
      -0.00075023707639613785, -0.00077842656097510733, -0.00080072629379604194,
      -0.00081640492123306993, -0.00082476358865943386, -0.00082513620134906868,
      -0.00081690424780147338, -0.00079950991684781046, -0.00077246445400775256,
      -0.00073536537441002564, -0.00068790277102766337, -0.00062985622127846249,
      -0.0005611425349022251, -0.00048175743563436916, -0.00039190807500728343,
      -0.00029182063428816543, -0.000181961084831513, -6.29128243690733E-5,
      6.4624275230859069E-5, 0.00019977628019913644, 0.00034150968015177121,
      0.0004886618294248355, 0.00063995001047128641, 0.00079393581500112741,
      0.0009490357186789913, 0.0011036036032513212, 0.0012558538579375564,
      0.0014039421170426907, 0.0015459284094883083, 0.001679837295382135,
      0.0018036616374591356, 0.0019153886737657267, 0.00201301986061668,
      0.0020945894410488823, 0.0021581949024973603, 0.0022020243323376473,
      0.0022243796824177467, 0.0022237060121889697, 0.0021986072367978894,
      0.0021478794570652269, 0.0020705297390861185, 0.0019658068681540318,
      0.0018332197505247587, 0.0016725579849848284, 0.0014839085278884607,
      0.0012676694027544527, 0.0010245639699284896, 0.000755649707734556,
      0.00046232644329788645, 0.00014633977343139943, -0.00019021910589017018,
      -0.000544916195565303, -0.000914983189859026, -0.0012973263841262661,
      -0.0016885426652622198, -0.0020849370496313418, -0.0024825469427331923,
      -0.0028771701292296245, -0.00326439306816668, -0.003639626439521172,
      -0.00399813454100072, -0.00433507831988893, -0.004645550080122773,
      -0.0049246227629045607, -0.0051673939405939449, -0.005369035916698928,
      -0.00552484604262651, -0.0056302898755702206, -0.0056810467865101473,
      -0.0056730535383026862, -0.0056025453238308914, -0.0054661227627227551,
      -0.0052607777124510108, -0.0049839683254474321, -0.0046336056212554107,
      -0.004208115466089987, -0.0037064355958101088, -0.0031280678563856022,
      -0.0024731486881144687, -0.0017424350740314204, -0.00093724390233042027,
      -5.9452052265944678E-5, 0.00088834436067106225, 0.0019027974341172414,
      0.0029803751472031563, 0.004116477247753686, 0.0053062583206468636,
      0.0065441933533923781, 0.0078242960610868818, 0.0091400979953495769,
      0.010484710338468709, 0.011850874693089335, 0.01323100216309182,
      0.014617236229338176, 0.016001515327072554, 0.0173756253555577,
      0.01873127706153074, 0.020060153057157554, 0.021353991217080273,
      0.022604639245676822, 0.023804130880825197, 0.024944745904798366,
      0.026019074746884849, 0.027020081459984177, 0.027941161561825925,
      0.028776199854410378, 0.029519621212843822, 0.030166436916403486,
      0.030712289151353413, 0.031153485918758685, 0.031487036241342956,
      0.031710672640186094, 0.0318228732701098, 0.0318228732701098,
      0.031710672640186094, 0.031487036241342956, 0.031153485918758685,
      0.030712289151353413, 0.030166436916403486, 0.029519621212843822,
      0.028776199854410378, 0.027941161561825925, 0.027020081459984177,
      0.026019074746884849, 0.024944745904798366, 0.023804130880825197,
      0.022604639245676822, 0.021353991217080273, 0.020060153057157554,
      0.01873127706153074, 0.0173756253555577, 0.016001515327072554,
      0.014617236229338176, 0.01323100216309182, 0.011850874693089335,
      0.010484710338468709, 0.0091400979953495769, 0.0078242960610868818,
      0.0065441933533923781, 0.0053062583206468636, 0.004116477247753686,
      0.0029803751472031563, 0.0019027974341172414, 0.00088834436067106225,
      -5.9452052265944678E-5, -0.00093724390233042027, -0.0017424350740314204,
      -0.0024731486881144687, -0.0031280678563856022, -0.0037064355958101088,
      -0.004208115466089987, -0.0046336056212554107, -0.0049839683254474321,
      -0.0052607777124510108, -0.0054661227627227551, -0.0056025453238308914,
      -0.0056730535383026862, -0.0056810467865101473, -0.0056302898755702206,
      -0.00552484604262651, -0.005369035916698928, -0.0051673939405939449,
      -0.0049246227629045607, -0.004645550080122773, -0.00433507831988893,
      -0.00399813454100072, -0.003639626439521172, -0.00326439306816668,
      -0.0028771701292296245, -0.0024825469427331923, -0.0020849370496313418,
      -0.0016885426652622198, -0.0012973263841262661, -0.000914983189859026,
      -0.000544916195565303, -0.00019021910589017018, 0.00014633977343139943,
      0.00046232644329788645, 0.000755649707734556, 0.0010245639699284896,
      0.0012676694027544527, 0.0014839085278884607, 0.0016725579849848284,
      0.0018332197505247587, 0.0019658068681540318, 0.0020705297390861185,
      0.0021478794570652269, 0.0021986072367978894, 0.0022237060121889697,
      0.0022243796824177467, 0.0022020243323376473, 0.0021581949024973603,
      0.0020945894410488823, 0.00201301986061668, 0.0019153886737657267,
      0.0018036616374591356, 0.001679837295382135, 0.0015459284094883083,
      0.0014039421170426907, 0.0012558538579375564, 0.0011036036032513212,
      0.0009490357186789913, 0.00079393581500112741, 0.00063995001047128641,
      0.0004886618294248355, 0.00034150968015177121, 0.00019977628019913644,
      6.4624275230859069E-5, -6.29128243690733E-5, -0.000181961084831513,
      -0.00029182063428816543, -0.00039190807500728343, -0.00048175743563436916,
      -0.0005611425349022251, -0.00062985622127846249, -0.00068790277102766337,
      -0.00073536537441002564, -0.00077246445400775256, -0.00079950991684781046,
      -0.00081690424780147338, -0.00082513620134906868, -0.00082476358865943386,
      -0.00081640492123306993, -0.00080072629379604194, -0.00077842656097510733,
      -0.00075023707639613785, -0.00071690038704737692, -0.00067917066824564132,
      -0.00063779295312050882, -0.00059350209584505464, -0.00054701132623058424,
      -0.0004990073887395464, -0.0004501437877973784, -0.00040103278638681933,
      -0.00035224204793541389, -0.00030429023019397762, -0.00025764517191006965,
      -0.00021272249416914754, -0.00016988256266866993, -0.00012943163260063204,
      -9.1619957081604255E-5, -5.6645259558263667E-5, -2.46528081402922E-5,
      4.260885091420487E-6, 3.0045661652630079E-5, 5.2695313551610168E-5,
      7.2242749788472646E-5, 8.8759512949545857E-5, 0.00010234786658387939,
      0.00011314047209882998, 0.0001212916318090078, 0.0001269768653905337,
      0.00013038759924218114, 0.0001317275561851486, 0.00013120972950391907,
      0.00012904957719045063, 0.00012546335360465616, 0.00012066616788727969,
      0.00011486474068440613, 0.00010826486918382385, 0.0001010520031514249,
      9.34119345288878E-5, 8.5505353579902379E-5, 7.7489828546128682E-5,
      6.9499647538234669E-5, 6.1650805463293754E-5, 5.4052337798716723E-5,
      4.6791606327360532E-5, 3.9937452672456289E-5, 3.3548835555932635E-5,
      2.7670146935033298E-5, 6.0993180294656731E-5 };

    static const real_T tmp_4[184] = { -6.5832063820294307E-5,
      -4.05359299102213E-5, -5.2614390107875509E-5, -6.6739674102163628E-5,
      -8.3075314416404953E-5, -0.00010177717145812027, -0.00012299005907100274,
      -0.00014684528586309082, -0.00017344978193441302, -0.00020289494061997922,
      -0.00023523310049893036, -0.00027050686193444461, -0.00030870159340322818,
      -0.00034978324625331586, -0.0003936580416882418, -0.00044019198970543527,
      -0.00048920819522462367, -0.00054046237948760965, -0.00059365949926768109,
      -0.00064844474390992734, -0.00070440236582023415, -0.00076104783406234918,
      -0.00081783659346813266, -0.00087414721098245691, -0.00092929999082224789,
      -0.000982548237748339, -0.001033074812977414, -0.0010799989322459202,
      -0.0011223788769098835, -0.0011592239541811005, -0.0011894731257738249,
      -0.0012120243391099028, -0.0012257343611694338, -0.0012294190584301772,
      -0.0012218590464883397, -0.0012018294694666923, -0.0011680783667648183,
      -0.0011193485589826382, -0.0010544157064280712, -0.00097202998223506153,
      -0.000871008149741243, -0.00075017485469011766, -0.00060842704635043513,
      -0.00044471045433985921, -0.00025804845796414066, -4.75488942787051E-5,
      0.00018759134246485243, 0.00044803300246606666, 0.00073443046534393038,
      0.0010470559885335056, 0.001386450469808365, 0.0017525656859591681,
      0.0021454532349827983, 0.0025650277583620516, 0.0030109101997601367,
      0.0034825588362512789, 0.0039793183794453717, 0.0045003608688456362,
      0.0050446311620474015, 0.0056108906738593263, 0.0061977276702185257,
      0.0068035871811758224, 0.0074267301500699039, 0.0080652435654357344,
      0.0087170490596640889, 0.0093799205014481572, 0.010051512592720512,
      0.010729351847056425, 0.011410852369317912, 0.012093327037568666,
      0.012774008313482191, 0.013450052976580189, 0.014118573940573444,
      0.014776651375848212, 0.015421363065146448, 0.016049799003507236,
      0.01665906014377002, 0.017246290667332187, 0.017808696461897,
      0.018343589045811438, 0.018848366144272925, 0.019320539919662771,
      0.019757778432289933, 0.020157914764871818, 0.020518912980947344,
      0.020838939133620886, 0.02111639024779953, 0.021349792773420549,
      0.021537993151788472, 0.021679988639985385, 0.0217750643267125,
      0.021822722864228788, 0.021822722864228788, 0.0217750643267125,
      0.021679988639985385, 0.021537993151788472, 0.021349792773420549,
      0.02111639024779953, 0.020838939133620886, 0.020518912980947344,
      0.020157914764871818, 0.019757778432289933, 0.019320539919662771,
      0.018848366144272925, 0.018343589045811438, 0.017808696461897,
      0.017246290667332187, 0.01665906014377002, 0.016049799003507236,
      0.015421363065146448, 0.014776651375848212, 0.014118573940573444,
      0.013450052976580189, 0.012774008313482191, 0.012093327037568666,
      0.011410852369317912, 0.010729351847056425, 0.010051512592720512,
      0.0093799205014481572, 0.0087170490596640889, 0.0080652435654357344,
      0.0074267301500699039, 0.0068035871811758224, 0.0061977276702185257,
      0.0056108906738593263, 0.0050446311620474015, 0.0045003608688456362,
      0.0039793183794453717, 0.0034825588362512789, 0.0030109101997601367,
      0.0025650277583620516, 0.0021454532349827983, 0.0017525656859591681,
      0.001386450469808365, 0.0010470559885335056, 0.00073443046534393038,
      0.00044803300246606666, 0.00018759134246485243, -4.75488942787051E-5,
      -0.00025804845796414066, -0.00044471045433985921, -0.00060842704635043513,
      -0.00075017485469011766, -0.000871008149741243, -0.00097202998223506153,
      -0.0010544157064280712, -0.0011193485589826382, -0.0011680783667648183,
      -0.0012018294694666923, -0.0012218590464883397, -0.0012294190584301772,
      -0.0012257343611694338, -0.0012120243391099028, -0.0011894731257738249,
      -0.0011592239541811005, -0.0011223788769098835, -0.0010799989322459202,
      -0.001033074812977414, -0.000982548237748339, -0.00092929999082224789,
      -0.00087414721098245691, -0.00081783659346813266, -0.00076104783406234918,
      -0.00070440236582023415, -0.00064844474390992734, -0.00059365949926768109,
      -0.00054046237948760965, -0.00048920819522462367, -0.00044019198970543527,
      -0.0003936580416882418, -0.00034978324625331586, -0.00030870159340322818,
      -0.00027050686193444461, -0.00023523310049893036, -0.00020289494061997922,
      -0.00017344978193441302, -0.00014684528586309082, -0.00012299005907100274,
      -0.00010177717145812027, -8.3075314416404953E-5, -6.6739674102163628E-5,
      -5.2614390107875509E-5, -4.05359299102213E-5, -6.5832063820294307E-5 };

    static const real_T tmp_5[180] = { -6.4685528284945122E-5,
      -3.7901786645457888E-5, -4.8607513891221552E-5, -6.0981102282028615E-5,
      -7.5134536390084926E-5, -9.1154533924794773E-5, -0.00010911288356720274,
      -0.00012907499397969081, -0.00015106386947893522, -0.00017509545899201554,
      -0.00020113765477189547, -0.00022914461995376056, -0.0002590220190237578,
      -0.00029064021566679453, -0.00032382561408644784, -0.00035835942180820679,
      -0.0003939780074608952, -0.00043035976294234022, -0.00046713603496019896,
      -0.00050387855613774786, -0.00054010834003538643, -0.00057528587011131235,
      -0.00060881778552132073, -0.00064005473921340179, -0.00066828899276019258,
      -0.00069275965279975722, -0.00071264996487274386, -0.00072710160310252079,
      -0.00073520603771820483, -0.0007360166973997581, -0.00072854619364196667,
      -0.000711780515642069, -0.00068468233389287563, -0.00064619054584045513,
      -0.00059523820581698726, -0.00053074871842220676, -0.00045166776980686224,
      -0.00035694096445634344, -0.00024554935624649781, -0.00011650273392565342,
      3.1139052836309771E-5, 0.00019824945785470131, 0.00038570553870597931,
      0.0005941393943535182, 0.00082441443625542858, 0.0010768661979842829,
      0.0013521085936034896, 0.0016505015670064127, 0.0019722028820531368,
      0.0023173241049278875, 0.0026858662620382048, 0.0030776799979278452,
      0.0034923941105345379, 0.0039295318611926016, 0.0043884657331017089,
      0.0048684326721342795, 0.0053684882142244908, 0.0058875175764090439,
      0.0064242548604853678, 0.00697728679172268, 0.0075450648745102678,
      0.0081258886119803635, 0.0087179217474837485, 0.0093191892923722847,
      0.0099275979462578635, 0.010540945469229956, 0.011156936180023206,
      0.011773195305399541, 0.012387273672204014, 0.012996666965774208,
      0.013598821114075692, 0.014191157938865624, 0.014771084523775808,
      0.015336020318471991, 0.0158834129308946, 0.016410752348712081,
      0.016915585089922712, 0.017395519791582003, 0.017848262859662505,
      0.018271623807341271, 0.018663545569683748, 0.019022094719328055,
      0.019345491047757027, 0.019632126564959655, 0.019880565852913694,
      0.0200895755442122, 0.020258057096653341, 0.020385196607903444,
      0.020470308192672981, 0.020512985267553102, 0.020512985267553102,
      0.020470308192672981, 0.020385196607903444, 0.020258057096653341,
      0.0200895755442122, 0.019880565852913694, 0.019632126564959655,
      0.019345491047757027, 0.019022094719328055, 0.018663545569683748,
      0.018271623807341271, 0.017848262859662505, 0.017395519791582003,
      0.016915585089922712, 0.016410752348712081, 0.0158834129308946,
      0.015336020318471991, 0.014771084523775808, 0.014191157938865624,
      0.013598821114075692, 0.012996666965774208, 0.012387273672204014,
      0.011773195305399541, 0.011156936180023206, 0.010540945469229956,
      0.0099275979462578635, 0.0093191892923722847, 0.0087179217474837485,
      0.0081258886119803635, 0.0075450648745102678, 0.00697728679172268,
      0.0064242548604853678, 0.0058875175764090439, 0.0053684882142244908,
      0.0048684326721342795, 0.0043884657331017089, 0.0039295318611926016,
      0.0034923941105345379, 0.0030776799979278452, 0.0026858662620382048,
      0.0023173241049278875, 0.0019722028820531368, 0.0016505015670064127,
      0.0013521085936034896, 0.0010768661979842829, 0.00082441443625542858,
      0.0005941393943535182, 0.00038570553870597931, 0.00019824945785470131,
      3.1139052836309771E-5, -0.00011650273392565342, -0.00024554935624649781,
      -0.00035694096445634344, -0.00045166776980686224, -0.00053074871842220676,
      -0.00059523820581698726, -0.00064619054584045513, -0.00068468233389287563,
      -0.000711780515642069, -0.00072854619364196667, -0.0007360166973997581,
      -0.00073520603771820483, -0.00072710160310252079, -0.00071264996487274386,
      -0.00069275965279975722, -0.00066828899276019258, -0.00064005473921340179,
      -0.00060881778552132073, -0.00057528587011131235, -0.00054010834003538643,
      -0.00050387855613774786, -0.00046713603496019896, -0.00043035976294234022,
      -0.0003939780074608952, -0.00035835942180820679, -0.00032382561408644784,
      -0.00029064021566679453, -0.0002590220190237578, -0.00022914461995376056,
      -0.00020113765477189547, -0.00017509545899201554, -0.00015106386947893522,
      -0.00012907499397969081, -0.00010911288356720274, -9.1154533924794773E-5,
      -7.5134536390084926E-5, -6.0981102282028615E-5, -4.8607513891221552E-5,
      -3.7901786645457888E-5, -6.4685528284945122E-5 };

    static const real_T tmp_6[230] = { 6.357302992977705E-5,
      3.5491409528551326E-5, 4.49906472530147E-5, 5.5837756308079079E-5,
      6.8091888162968649E-5, 8.1786230930722115E-5, 9.69409956042E-5,
      0.00011354971661896638, 0.00013158810916945551, 0.00015100733589213614,
      0.00017172589021793465, 0.00019363211306500504, 0.00021658261716176017,
      0.00024039950379870607, 0.00026487420242358593, 0.00028976043249421564,
      0.00031476682184176561, 0.00033956537161120817, 0.00036379951578905973,
      0.00038707998079355881, 0.00040897924258927025, 0.00042902990986315112,
      0.0004467335951562627, 0.00046157843642576589, 0.00047303334055844492,
      0.0004805321498471271, 0.00048349691358269488, 0.0004813679438302458,
      0.00047357522903320273, 0.00045953075681350844, 0.00043869158287382251,
      0.00041055348436552856, 0.00037456562539550946, 0.00033032733044654187,
      0.00027738737551657794, 0.00021542544099919915, 0.00014414167887261516,
      6.3340472806155691E-5, -2.7108449678091616E-5, -0.00012722709690081262,
      -0.00023693863778881662, -0.00035606183916468156, -0.00048429227167928193,
      -0.00062120057326990044, -0.00076623181106432879, -0.00091869468511282808,
      -0.0010777618751737837, -0.001242468707521971, -0.0014117060700051145,
      -0.0015842248127290758, -0.0017586416367944427, -0.0019334334927635954,
      -0.0021069433629815051, -0.0022773959132933092, -0.0024428979906570064,
      -0.0026014426992594687, -0.00275093078919915, -0.0028891819637608916,
      -0.0030139383259796954, -0.0031228896319780925, -0.0032136914781477248,
      -0.003283971192936436, -0.0033313573103989904, -0.0033535065307228884,
      -0.0033480883684634038, -0.0033128644840654865, -0.003245642111640871,
      -0.0031443704120749528, -0.0030070734850199633, -0.0028319747096494747,
      -0.0026174201740154918, -0.0023619681511949779, -0.0020643860509915908,
      -0.0017236521257514683, -0.0013389984528639053, -0.00090992498431644248,
      -0.00043619351610746664, 8.2146070979222373E-5, 0.00064473646920087642,
      0.00125091942567867, 0.0018997303690833824, 0.0025898818808088478,
      0.0033197668631297526, 0.0040874665660680957, 0.0048907499492796495,
      0.0057270785255031193, 0.0065936161869052188, 0.0074872412188815235,
      0.0084045669135929361, 0.0093419594871061631, 0.010295547333947126,
      0.011261246762907354, 0.012234793161274843, 0.013211759595160529,
      0.014187583959536093, 0.015157606664338626, 0.01611708241150844,
      0.017061259146019102, 0.017985297812836157, 0.01888459202959223,
      0.019754222117299297, 0.020589826642273726, 0.021386824501157857,
      0.022140854253215853, 0.022847862886336674, 0.023503980133913128,
      0.024105524114582215, 0.024649113366145926, 0.025131712899773184,
      0.025550617533719476, 0.025903446442650684, 0.026188166974095792,
      0.0264031324703912, 0.026547114690623784, 0.026619306166985747,
      0.026619306166985747, 0.026547114690623784, 0.0264031324703912,
      0.026188166974095792, 0.025903446442650684, 0.025550617533719476,
      0.025131712899773184, 0.024649113366145926, 0.024105524114582215,
      0.023503980133913128, 0.022847862886336674, 0.022140854253215853,
      0.021386824501157857, 0.020589826642273726, 0.019754222117299297,
      0.01888459202959223, 0.017985297812836157, 0.017061259146019102,
      0.01611708241150844, 0.015157606664338626, 0.014187583959536093,
      0.013211759595160529, 0.012234793161274843, 0.011261246762907354,
      0.010295547333947126, 0.0093419594871061631, 0.0084045669135929361,
      0.0074872412188815235, 0.0065936161869052188, 0.0057270785255031193,
      0.0048907499492796495, 0.0040874665660680957, 0.0033197668631297526,
      0.0025898818808088478, 0.0018997303690833824, 0.00125091942567867,
      0.00064473646920087642, 8.2146070979222373E-5, -0.00043619351610746664,
      -0.00090992498431644248, -0.0013389984528639053, -0.0017236521257514683,
      -0.0020643860509915908, -0.0023619681511949779, -0.0026174201740154918,
      -0.0028319747096494747, -0.0030070734850199633, -0.0031443704120749528,
      -0.003245642111640871, -0.0033128644840654865, -0.0033480883684634038,
      -0.0033535065307228884, -0.0033313573103989904, -0.003283971192936436,
      -0.0032136914781477248, -0.0031228896319780925, -0.0030139383259796954,
      -0.0028891819637608916, -0.00275093078919915, -0.0026014426992594687,
      -0.0024428979906570064, -0.0022773959132933092, -0.0021069433629815051,
      -0.0019334334927635954, -0.0017586416367944427, -0.0015842248127290758,
      -0.0014117060700051145, -0.001242468707521971, -0.0010777618751737837,
      -0.00091869468511282808, -0.00076623181106432879, -0.00062120057326990044,
      -0.00048429227167928193, -0.00035606183916468156, -0.00023693863778881662,
      -0.00012722709690081262, -2.7108449678091616E-5, 6.3340472806155691E-5,
      0.00014414167887261516, 0.00021542544099919915, 0.00027738737551657794,
      0.00033032733044654187, 0.00037456562539550946, 0.00041055348436552856,
      0.00043869158287382251, 0.00045953075681350844, 0.00047357522903320273,
      0.0004813679438302458, 0.00048349691358269488, 0.0004805321498471271,
      0.00047303334055844492, 0.00046157843642576589, 0.0004467335951562627,
      0.00042902990986315112, 0.00040897924258927025, 0.00038707998079355881,
      0.00036379951578905973, 0.00033956537161120817, 0.00031476682184176561,
      0.00028976043249421564, 0.00026487420242358593, 0.00024039950379870607,
      0.00021658261716176017, 0.00019363211306500504, 0.00017172589021793465,
      0.00015100733589213614, 0.00013158810916945551, 0.00011354971661896638,
      9.69409956042E-5, 8.1786230930722115E-5, 6.8091888162968649E-5,
      5.5837756308079079E-5, 4.49906472530147E-5, 3.5491409528551326E-5,
      6.357302992977705E-5 };

    /* Start for Constant: '<Root>/start_course' */
    optimis_Crane3D_DevDriv_B.start_course =
      optimis_Crane3D_DevDriv_P.start_course;
    for (i = 0; i < 6; i++) {
      /* Start for Constant: '<Root>/xwaypoints' */
      optimis_Crane3D_DevDriv_B.xwaypoints[i] =
        optimis_Crane3D_DevDriv_P.xwaypoints[i];

      /* Start for Constant: '<Root>/ywaypoints ' */
      optimis_Crane3D_DevDriv_B.ywaypoints[i] =
        optimis_Crane3D_DevDriv_P.ywaypoints[i];
    }

    /* Start for Constant: '<Root>/total_waypoints ' */
    optimis_Crane3D_DevDriv_B.total_waypoints =
      optimis_Crane3D_DevDriv_P.total_waypoints;

    /* Start for Constant: '<Root>/settling_time ' */
    optimis_Crane3D_DevDriv_B.settling_time =
      optimis_Crane3D_DevDriv_P.settling_time;

    /* Start for MATLABSystem: '<Root>/Lowpass Filter2' */
    optimis_Crane3D_DevDriv_DW.obj_or.isInitialized = 0;
    optimis_Crane3D_DevDriv_DW.obj_or.NumChannels = -1.0;
    optimis_Crane3D_DevDriv_DW.objisempty = true;
    optimis_Crane3D_DevDriv_DW.obj_or.pSampleRateDialog =
      optimis_Crane3D_DevDriv_SampleRate;
    iobj_0 = &optimis_Crane3D_DevDriv_DW.gobj_0;
    optimis_Crane3D_DevDriv_DW.obj_or.isInitialized = 1;
    optimis_Crane3D_DevDriv_DW.obj_or.inputVarSize1[0] = 1U;
    optimis_Crane3D_DevDriv_DW.obj_or.inputVarSize1[1] = 1U;
    for (i = 0; i < 6; i++) {
      optimis_Crane3D_DevDriv_DW.obj_or.inputVarSize1[i + 2] = 1U;
    }

    optimis_Crane3D_DevDriv_DW.gobj_0.isInitialized = 0;

    /* System object Constructor function: dsp.FIRFilter */
    iobj_0->cSFunObject.P0_InitialStates = 0.0;
    for (i = 0; i < 318; i++) {
      iobj_0->cSFunObject.P1_Coefficients[i] = tmp_3[i];
    }

    for (i = 0; i < 318; i++) {
      iobj_0->cSFunObject.P1_Coefficients[i] = tmp[i];
    }

    optimis_Crane3D_DevDriv_DW.obj_or.FilterObj =
      &optimis_Crane3D_DevDriv_DW.gobj_0;
    optimis_Crane3D_DevDriv_DW.obj_or.NumChannels = 1.0;

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter2' */
    /* Start for MATLABSystem: '<Root>/Lowpass Filter1' */
    optimis_Crane3D_DevDriv_DW.obj_o.isInitialized = 0;
    optimis_Crane3D_DevDriv_DW.obj_o.NumChannels = -1.0;
    optimis_Crane3D_DevDriv_DW.objisempty_i = true;
    optimis_Crane3D_DevDriv_DW.obj_o.pSampleRateDialog =
      optimis_Crane3D_DevDriv_SampleRate;
    iobj_0_0 = &optimis_Crane3D_DevDriv_DW.gobj_0_m;
    optimis_Crane3D_DevDriv_DW.obj_o.isInitialized = 1;
    optimis_Crane3D_DevDriv_DW.obj_o.inputVarSize1[0] = 1U;
    optimis_Crane3D_DevDriv_DW.obj_o.inputVarSize1[1] = 1U;
    for (i = 0; i < 6; i++) {
      optimis_Crane3D_DevDriv_DW.obj_o.inputVarSize1[i + 2] = 1U;
    }

    optimis_Crane3D_DevDriv_DW.gobj_0_m.isInitialized = 0;

    /* System object Constructor function: dsp.FIRFilter */
    iobj_0_0->cSFunObject.P0_InitialStates = 0.0;
    for (i = 0; i < 184; i++) {
      iobj_0_0->cSFunObject.P1_Coefficients[i] = tmp_4[i];
    }

    for (i = 0; i < 184; i++) {
      iobj_0_0->cSFunObject.P1_Coefficients[i] = tmp_0[i];
    }

    optimis_Crane3D_DevDriv_DW.obj_o.FilterObj =
      &optimis_Crane3D_DevDriv_DW.gobj_0_m;
    optimis_Crane3D_DevDriv_DW.obj_o.NumChannels = 1.0;

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter1' */

    /* Start for MATLABSystem: '<Root>/Lowpass Filter3' */
    optimis_Crane3D_DevDriv_DW.obj_a.isInitialized = 0;
    optimis_Crane3D_DevDriv_DW.obj_a.NumChannels = -1.0;
    optimis_Crane3D_DevDriv_DW.objisempty_g = true;
    optimis_Crane3D_DevDriv_DW.obj_a.pSampleRateDialog =
      optimis_Crane3D_DevDriv_SampleRate;
    iobj_0_1 = &optimis_Crane3D_DevDriv_DW.gobj_0_f;
    optimis_Crane3D_DevDriv_DW.obj_a.isInitialized = 1;
    optimis_Crane3D_DevDriv_DW.obj_a.inputVarSize1[0] = 1U;
    optimis_Crane3D_DevDriv_DW.obj_a.inputVarSize1[1] = 1U;
    for (i = 0; i < 6; i++) {
      optimis_Crane3D_DevDriv_DW.obj_a.inputVarSize1[i + 2] = 1U;
    }

    optimis_Crane3D_DevDriv_DW.gobj_0_f.isInitialized = 0;

    /* System object Constructor function: dsp.FIRFilter */
    iobj_0_1->cSFunObject.P0_InitialStates = 0.0;
    for (i = 0; i < 180; i++) {
      iobj_0_1->cSFunObject.P1_Coefficients[i] = tmp_5[i];
    }

    for (i = 0; i < 180; i++) {
      iobj_0_1->cSFunObject.P1_Coefficients[i] = tmp_1[i];
    }

    optimis_Crane3D_DevDriv_DW.obj_a.FilterObj =
      &optimis_Crane3D_DevDriv_DW.gobj_0_f;
    optimis_Crane3D_DevDriv_DW.obj_a.NumChannels = 1.0;

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter3' */

    /* Start for MATLABSystem: '<Root>/Lowpass Filter4' */
    optimis_Crane3D_DevDriv_DW.obj_b.isInitialized = 0;
    optimis_Crane3D_DevDriv_DW.obj_b.NumChannels = -1.0;
    optimis_Crane3D_DevDriv_DW.objisempty_id = true;
    optimis_Crane3D_DevDriv_DW.obj_b.pSampleRateDialog =
      optimis_Crane3D_DevDriv_SampleRate;
    iobj_0_2 = &optimis_Crane3D_DevDriv_DW.gobj_0_j;
    optimis_Crane3D_DevDriv_DW.obj_b.isInitialized = 1;
    optimis_Crane3D_DevDriv_DW.obj_b.inputVarSize1[0] = 1U;
    optimis_Crane3D_DevDriv_DW.obj_b.inputVarSize1[1] = 1U;
    for (i = 0; i < 6; i++) {
      optimis_Crane3D_DevDriv_DW.obj_b.inputVarSize1[i + 2] = 1U;
    }

    optimis_Crane3D_DevDriv_DW.gobj_0_j.isInitialized = 0;

    /* System object Constructor function: dsp.FIRFilter */
    iobj_0_2->cSFunObject.P0_InitialStates = 0.0;
    for (i = 0; i < 230; i++) {
      iobj_0_2->cSFunObject.P1_Coefficients[i] = tmp_6[i];
    }

    for (i = 0; i < 230; i++) {
      iobj_0_2->cSFunObject.P1_Coefficients[i] = tmp_2[i];
    }

    optimis_Crane3D_DevDriv_DW.obj_b.FilterObj =
      &optimis_Crane3D_DevDriv_DW.gobj_0_j;
    optimis_Crane3D_DevDriv_DW.obj_b.NumChannels = 1.0;

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter4' */
    /* Start for MATLABSystem: '<Root>/MATLAB System' */
    optimis_Crane3D_DevDriv_DW.obj.pNumChannels = -1.0;

    /*  MovingAverageFilter Moving Average Filter example System object */
    /*   This object is only in support of the tutorial - Create Moving Average */
    /*   System Object. It may change in a future release. */
    /*  */
    /*    FILTER = dspdemo.MovingAverageFilter returns a moving average filter */
    /*    System object(TM) filter, which computes the moving average of the */
    /*    input. */
    /*  */
    /*    FILTER = dspdemo.MovingAverageFilter('PropertyName', PropertyValue, */
    /*    ...) returns a moving average filter System object, filter, with each */
    /*    specified property set to the specified value. */
    /*  */
    /*    Step method syntax: */
    /*  */
    /*    Y = step(FILTER, X) filters the matrix input X and returns the filtered */
    /*    output in Y. The object filters each input channel (or column) */
    /*    independently over time. */
    /*  */
    /*    MovingAverageFilter methods: */
    /*  */
    /*    step     - See above description for use of this method  */
    /*    release  - Allow property value and input characteristics changes  */
    /*    clone    - Create ExMovingAverageFilter object with same property values  */
    /*    isLocked - Locked status (logical)  */
    /*    reset    - Reset the internal states to initial conditions */
    /*  */
    /*    MovingAverageFilter properties: */
    /*  */
    /*    WindowLength                      - Moving average window length */
    /*  */
    /*    % EXAMPLE: Use a moving average filter to low-pass filter a noisy */
    /*    square wave. The filter's window length is set to 30. */
    /*    */
    /*    movingAverageFilter = dspdemo.MovingAverageFilter('WindowLength',30); */
    /*    scope = dsp.TimeScope('SampleRate',1e3,... */
    /*                          'TimeSpan',256 * .01,... 'ShowGrid',true,... */
    /*                          'NumInputPorts',2,... 'LayoutDimensions',[2 1]); */
    /*    for ii =1:100 */
    /*      input =  (1-2*randi([0 1],1)) * ones(256,1) + 0.5 * randn(256,1); */
    /*      output = step(movingAverageFilter,input); step(scope,input,output) */
    /*    end */
    /*    Copyright 2014 The MathWorks, Inc. */
    /*  WindowLength Moving average filter length */
    /*    Specify the length of the moving average filter as a */
    /*    scalar positive integer value. The default value of this */
    /*    property is 5. */
    /*  pNumChannels Property used to cache the number of input channels */
    /*  (columns). Varying the number of channels during the streaming */
    /*  operation is not allowed (since it modifes the number of required */
    /*  states). The default of -1 means that the streaming operation has */
    /*  not started yet (i.e. the number ofo channels is still unknown). */
    /*  Constructor */
    optimis_Crane3D_DevDriv_DW.obj.isInitialized = 0;

    /*  Support name-value pair arguments when constructing the */
    /*  object. */
    optimis_Crane3D_DevDriv_DW.objisempty_f = true;
    optimis_Crane3D_DevDriv_DW.obj.isInitialized = 1;
    optimis_Crane3D_DevDriv_DW.obj.inputVarSize1[0] = 1U;
    optimis_Crane3D_DevDriv_DW.obj.inputVarSize1[1] = 1U;
    for (i = 0; i < 6; i++) {
      optimis_Crane3D_DevDriv_DW.obj.inputVarSize1[i + 2] = 1U;
    }

    optimis_Crane3D_DevDriv_DW.obj.pNumChannels = 1.0;
    for (i = 0; i < 29; i++) {
      optimis_Crane3D_DevDriv_DW.obj.State[i] = 0.0;
      optimis_Crane3D_DevDriv_DW.State[i] =
        optimis_Crane3D_DevDriv_DW.obj.State[i];
    }

    /* End of Start for MATLABSystem: '<Root>/MATLAB System' */
    /* Start for Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[0] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[0];

    /* Start for Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[0] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[0];

    /* Start for Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[1] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[1];

    /* Start for Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[1] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[1];

    /* Start for Constant: '<S1>/LimitFlagSource' */
    optimis_Crane3D_DevDriv_B.LimitFlagSource[2] =
      optimis_Crane3D_DevDriv_P.LimitFlagSource_Value[2];

    /* Start for Constant: '<S1>/LimitSource' */
    optimis_Crane3D_DevDriv_B.LimitSource[2] =
      optimis_Crane3D_DevDriv_P.LimitSource_Value[2];

    /* Start for Constant: '<S1>/PWMPrescalerSource' */
    optimis_Crane3D_DevDriv_B.PWMPrescalerSource =
      optimis_Crane3D_DevDriv_P.PWMPrescalerSource_Value;

    /* Start for Constant: '<S1>/ResetSource' */
    for (i = 0; i < 5; i++) {
      optimis_Crane3D_DevDriv_B.ResetSource[i] =
        optimis_Crane3D_DevDriv_P.ResetSource_Value[i];
    }

    /* End of Start for Constant: '<S1>/ResetSource' */
    /* Start for Constant: '<S1>/ResetSwitchFlagSource' */
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[0] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[0];
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[1] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[1];
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[2] =
      optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value[2];

    /* Start for Constant: '<S1>/ThermFlagSource' */
    optimis_Crane3D_DevDriv_B.ThermFlagSource[0] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[0];
    optimis_Crane3D_DevDriv_B.ThermFlagSource[1] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[1];
    optimis_Crane3D_DevDriv_B.ThermFlagSource[2] =
      optimis_Crane3D_DevDriv_P.ThermFlagSource_Value[2];
  }

  {
    int32_T i;
    real_T tmp;

    /* InitializeConditions for Integrator: '<S3>/Integrator' */
    optimis_Crane3D_DevDriv_X.Integrator_CSTATE =
      optimis_Crane3D_DevDriv_P.Integrator_IC;

    /* InitializeConditions for Derivative: '<S3>/Derivative' */
    optimis_Crane3D_DevDriv_DW.TimeStampA = (rtInf);
    optimis_Crane3D_DevDriv_DW.TimeStampB = (rtInf);

    /* InitializeConditions for Integrator: '<S4>/Integrator' */
    optimis_Crane3D_DevDriv_X.Integrator_CSTATE_f =
      optimis_Crane3D_DevDriv_P.Integrator_IC_a;

    /* InitializeConditions for Derivative: '<S4>/Derivative' */
    optimis_Crane3D_DevDriv_DW.TimeStampA_o = (rtInf);
    optimis_Crane3D_DevDriv_DW.TimeStampB_c = (rtInf);

    /* SystemInitialize for Chart: '<Root>/HL Controller' */
    optimis_Crane3D_DevDriv_DW.sfEvent = optimis_Crane3D_DevDriv_CALL_EVENT;
    optimis_Crane3D_DevDriv_DW.is_active_S1_setpoints = 0U;
    optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidx = 0U;
    optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidy = 0U;
    optimis_Crane3D_DevDriv_DW.temporalCounter_i1 = 0U;
    optimis_Crane3D_DevDriv_DW.is_active_c3_optimis_Crane3D_DevDriv = 0U;
    optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv =
      optimis_Crane3D_DevDriv_IN_NO_ACTIVE_CHILD;
    optimis_Crane3D_DevDriv_DW.ready = 0.0;
    optimis_Crane3D_DevDriv_DW.index = 1.0;
    optimis_Crane3D_DevDriv_DW.initialized = 0.0;
    optimis_Crane3D_DevDriv_DW.arrived = 0.0;
    optimis_Crane3D_DevDriv_DW.finished = -1.0;
    optimis_Crane3D_DevDriv_B.done = 0.0;
    optimis_Crane3D_DevDriv_B.close_switch = 0.0;

    /* Start for MATLABSystem: '<Root>/Lowpass Filter2' incorporates:
     *  InitializeConditions for MATLABSystem: '<Root>/Lowpass Filter2'
     */
    if ((optimis_Crane3D_DevDriv_DW.obj_or.isInitialized == 1) &&
        (optimis_Crane3D_DevDriv_DW.obj_or.FilterObj->isInitialized == 1)) {
      /* System object Initialization function: dsp.FIRFilter */
      tmp =
        optimis_Crane3D_DevDriv_DW.obj_or.FilterObj->cSFunObject.P0_InitialStates;
      for (i = 0; i < 317; i++) {
        optimis_Crane3D_DevDriv_DW.obj_or.FilterObj->cSFunObject.W0_states[i] =
          tmp;
      }
    }

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter2' */

    /* Start for MATLABSystem: '<Root>/Lowpass Filter1' incorporates:
     *  InitializeConditions for MATLABSystem: '<Root>/Lowpass Filter1'
     */
    if ((optimis_Crane3D_DevDriv_DW.obj_o.isInitialized == 1) &&
        (optimis_Crane3D_DevDriv_DW.obj_o.FilterObj->isInitialized == 1)) {
      /* System object Initialization function: dsp.FIRFilter */
      tmp =
        optimis_Crane3D_DevDriv_DW.obj_o.FilterObj->cSFunObject.P0_InitialStates;
      for (i = 0; i < 183; i++) {
        optimis_Crane3D_DevDriv_DW.obj_o.FilterObj->cSFunObject.W0_states[i] =
          tmp;
      }
    }

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter1' */

    /* Start for MATLABSystem: '<Root>/Lowpass Filter3' incorporates:
     *  InitializeConditions for MATLABSystem: '<Root>/Lowpass Filter3'
     */
    if ((optimis_Crane3D_DevDriv_DW.obj_a.isInitialized == 1) &&
        (optimis_Crane3D_DevDriv_DW.obj_a.FilterObj->isInitialized == 1)) {
      /* System object Initialization function: dsp.FIRFilter */
      tmp =
        optimis_Crane3D_DevDriv_DW.obj_a.FilterObj->cSFunObject.P0_InitialStates;
      for (i = 0; i < 179; i++) {
        optimis_Crane3D_DevDriv_DW.obj_a.FilterObj->cSFunObject.W0_states[i] =
          tmp;
      }
    }

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter3' */

    /* Start for MATLABSystem: '<Root>/Lowpass Filter4' incorporates:
     *  InitializeConditions for MATLABSystem: '<Root>/Lowpass Filter4'
     */
    if ((optimis_Crane3D_DevDriv_DW.obj_b.isInitialized == 1) &&
        (optimis_Crane3D_DevDriv_DW.obj_b.FilterObj->isInitialized == 1)) {
      /* System object Initialization function: dsp.FIRFilter */
      tmp =
        optimis_Crane3D_DevDriv_DW.obj_b.FilterObj->cSFunObject.P0_InitialStates;
      for (i = 0; i < 229; i++) {
        optimis_Crane3D_DevDriv_DW.obj_b.FilterObj->cSFunObject.W0_states[i] =
          tmp;
      }
    }

    /* End of Start for MATLABSystem: '<Root>/Lowpass Filter4' */

    /* Start for MATLABSystem: '<Root>/MATLAB System' incorporates:
     *  InitializeConditions for MATLABSystem: '<Root>/MATLAB System'
     */
    if (optimis_Crane3D_DevDriv_DW.obj.isInitialized == 1) {
      for (i = 0; i < 29; i++) {
        optimis_Crane3D_DevDriv_DW.obj.State[i] = 0.0;
      }
    }

    /* End of Start for MATLABSystem: '<Root>/MATLAB System' */

    /* InitializeConditions for MATLABSystem: '<Root>/MATLAB System' */
    memcpy(&optimis_Crane3D_DevDriv_DW.State[0],
           &optimis_Crane3D_DevDriv_DW.obj.State[0], 29U * sizeof(real_T));
  }
}

/* Model terminate function */
void optimis_Crane3D_DevDriv_terminate(void)
{
  /* Level2 S-Function Block: '<S1>/Encoder' (Crane3D_Encoder) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Start for MATLABSystem: '<Root>/Lowpass Filter2' incorporates:
   *  Terminate for MATLABSystem: '<Root>/Lowpass Filter2'
   */
  if (optimis_Crane3D_DevDriv_DW.obj_or.isInitialized == 1) {
    optimis_Crane3D_DevDriv_DW.obj_or.isInitialized = 2;
    if (optimis_Crane3D_DevDriv_DW.obj_or.FilterObj->isInitialized == 1) {
      optimis_Crane3D_DevDriv_DW.obj_or.FilterObj->isInitialized = 2;
    }

    optimis_Crane3D_DevDriv_DW.obj_or.NumChannels = -1.0;
  }

  /* End of Start for MATLABSystem: '<Root>/Lowpass Filter2' */

  /* Start for MATLABSystem: '<Root>/Lowpass Filter1' incorporates:
   *  Terminate for MATLABSystem: '<Root>/Lowpass Filter1'
   */
  if (optimis_Crane3D_DevDriv_DW.obj_o.isInitialized == 1) {
    optimis_Crane3D_DevDriv_DW.obj_o.isInitialized = 2;
    if (optimis_Crane3D_DevDriv_DW.obj_o.FilterObj->isInitialized == 1) {
      optimis_Crane3D_DevDriv_DW.obj_o.FilterObj->isInitialized = 2;
    }

    optimis_Crane3D_DevDriv_DW.obj_o.NumChannels = -1.0;
  }

  /* End of Start for MATLABSystem: '<Root>/Lowpass Filter1' */

  /* Start for MATLABSystem: '<Root>/Lowpass Filter3' incorporates:
   *  Terminate for MATLABSystem: '<Root>/Lowpass Filter3'
   */
  if (optimis_Crane3D_DevDriv_DW.obj_a.isInitialized == 1) {
    optimis_Crane3D_DevDriv_DW.obj_a.isInitialized = 2;
    if (optimis_Crane3D_DevDriv_DW.obj_a.FilterObj->isInitialized == 1) {
      optimis_Crane3D_DevDriv_DW.obj_a.FilterObj->isInitialized = 2;
    }

    optimis_Crane3D_DevDriv_DW.obj_a.NumChannels = -1.0;
  }

  /* End of Start for MATLABSystem: '<Root>/Lowpass Filter3' */

  /* Start for MATLABSystem: '<Root>/Lowpass Filter4' incorporates:
   *  Terminate for MATLABSystem: '<Root>/Lowpass Filter4'
   */
  if (optimis_Crane3D_DevDriv_DW.obj_b.isInitialized == 1) {
    optimis_Crane3D_DevDriv_DW.obj_b.isInitialized = 2;
    if (optimis_Crane3D_DevDriv_DW.obj_b.FilterObj->isInitialized == 1) {
      optimis_Crane3D_DevDriv_DW.obj_b.FilterObj->isInitialized = 2;
    }

    optimis_Crane3D_DevDriv_DW.obj_b.NumChannels = -1.0;
  }

  /* End of Start for MATLABSystem: '<Root>/Lowpass Filter4' */

  /* Start for MATLABSystem: '<Root>/MATLAB System' incorporates:
   *  Terminate for MATLABSystem: '<Root>/MATLAB System'
   */
  if (optimis_Crane3D_DevDriv_DW.obj.isInitialized == 1) {
    optimis_Crane3D_DevDriv_DW.obj.isInitialized = 2;
    optimis_Crane3D_DevDriv_DW.obj.pNumChannels = -1.0;
  }

  /* End of Start for MATLABSystem: '<Root>/MATLAB System' */

  /* Terminate for MATLABSystem: '<Root>/MATLAB System' */
  memcpy(&optimis_Crane3D_DevDriv_DW.State[0],
         &optimis_Crane3D_DevDriv_DW.obj.State[0], 29U * sizeof(real_T));

  /* Level2 S-Function Block: '<S1>/PWM' (Crane3D_PWM) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/LimitFlag' (Crane3D_LimitFlag) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/SetLimit' (Crane3D_SetLimit) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/LimitSwitch' (Crane3D_Switch) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/PWMPrescaler' (Crane3D_PWMPrescaler) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[5];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/ResetEncoder' (Crane3D_ResetEncoder) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[6];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/ResetSwitchFlag ' (Crane3D_ResetSwitchFlag) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[7];
    sfcnTerminate(rts);
  }

  /* Level2 S-Function Block: '<S1>/ThermFlag ' (Crane3D_ThermFlag) */
  {
    SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[8];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  optimis_Crane3D_DevDriv_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  optimis_Crane3D_DevDriv_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  optimis_Crane3D_DevDriv_initialize();
}

void MdlTerminate(void)
{
  optimis_Crane3D_DevDriv_terminate();
}

/* Registration function */
RT_MODEL_optimis_Crane3D_DevDriv_T *optimis_Crane3D_DevDriv(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)optimis_Crane3D_DevDriv_M, 0,
                sizeof(RT_MODEL_optimis_Crane3D_DevDriv_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
                          &optimis_Crane3D_DevDriv_M->Timing.simTimeStep);
    rtsiSetTPtr(&optimis_Crane3D_DevDriv_M->solverInfo, &rtmGetTPtr
                (optimis_Crane3D_DevDriv_M));
    rtsiSetStepSizePtr(&optimis_Crane3D_DevDriv_M->solverInfo,
                       &optimis_Crane3D_DevDriv_M->Timing.stepSize0);
    rtsiSetdXPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
                 &optimis_Crane3D_DevDriv_M->ModelData.derivs);
    rtsiSetContStatesPtr(&optimis_Crane3D_DevDriv_M->solverInfo, (real_T **)
                         &optimis_Crane3D_DevDriv_M->ModelData.contStates);
    rtsiSetNumContStatesPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
      &optimis_Crane3D_DevDriv_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
      &optimis_Crane3D_DevDriv_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
      &optimis_Crane3D_DevDriv_M->ModelData.periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
      &optimis_Crane3D_DevDriv_M->ModelData.periodicContStateRanges);
    rtsiSetErrorStatusPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
                          (&rtmGetErrorStatus(optimis_Crane3D_DevDriv_M)));
    rtsiSetRTModelPtr(&optimis_Crane3D_DevDriv_M->solverInfo,
                      optimis_Crane3D_DevDriv_M);
  }

  rtsiSetSimTimeStep(&optimis_Crane3D_DevDriv_M->solverInfo, MAJOR_TIME_STEP);
  optimis_Crane3D_DevDriv_M->ModelData.intgData.y =
    optimis_Crane3D_DevDriv_M->ModelData.odeY;
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[0] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[0];
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[1] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[1];
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[2] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[2];
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[3] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[3];
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[4] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[4];
  optimis_Crane3D_DevDriv_M->ModelData.intgData.f[5] =
    optimis_Crane3D_DevDriv_M->ModelData.odeF[5];
  optimis_Crane3D_DevDriv_M->ModelData.contStates = ((real_T *)
    &optimis_Crane3D_DevDriv_X);
  rtsiSetSolverData(&optimis_Crane3D_DevDriv_M->solverInfo, (void *)
                    &optimis_Crane3D_DevDriv_M->ModelData.intgData);
  rtsiSetSolverName(&optimis_Crane3D_DevDriv_M->solverInfo,"ode5");
  optimis_Crane3D_DevDriv_M->solverInfoPtr =
    (&optimis_Crane3D_DevDriv_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = optimis_Crane3D_DevDriv_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    optimis_Crane3D_DevDriv_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    optimis_Crane3D_DevDriv_M->Timing.sampleTimes =
      (&optimis_Crane3D_DevDriv_M->Timing.sampleTimesArray[0]);
    optimis_Crane3D_DevDriv_M->Timing.offsetTimes =
      (&optimis_Crane3D_DevDriv_M->Timing.offsetTimesArray[0]);

    /* task periods */
    optimis_Crane3D_DevDriv_M->Timing.sampleTimes[0] = (0.0);
    optimis_Crane3D_DevDriv_M->Timing.sampleTimes[1] = (0.01);

    /* task offsets */
    optimis_Crane3D_DevDriv_M->Timing.offsetTimes[0] = (0.0);
    optimis_Crane3D_DevDriv_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(optimis_Crane3D_DevDriv_M,
             &optimis_Crane3D_DevDriv_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = optimis_Crane3D_DevDriv_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    optimis_Crane3D_DevDriv_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(optimis_Crane3D_DevDriv_M, -1);
  optimis_Crane3D_DevDriv_M->Timing.stepSize0 = 0.01;
  optimis_Crane3D_DevDriv_M->Timing.stepSize1 = 0.01;

  /* External mode info */
  optimis_Crane3D_DevDriv_M->Sizes.checksums[0] = (1105797257U);
  optimis_Crane3D_DevDriv_M->Sizes.checksums[1] = (59500163U);
  optimis_Crane3D_DevDriv_M->Sizes.checksums[2] = (1885592543U);
  optimis_Crane3D_DevDriv_M->Sizes.checksums[3] = (3749051681U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[9];
    optimis_Crane3D_DevDriv_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(optimis_Crane3D_DevDriv_M->extModeInfo,
      &optimis_Crane3D_DevDriv_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(optimis_Crane3D_DevDriv_M->extModeInfo,
                        optimis_Crane3D_DevDriv_M->Sizes.checksums);
    rteiSetTPtr(optimis_Crane3D_DevDriv_M->extModeInfo, rtmGetTPtr
                (optimis_Crane3D_DevDriv_M));
  }

  optimis_Crane3D_DevDriv_M->solverInfoPtr =
    (&optimis_Crane3D_DevDriv_M->solverInfo);
  optimis_Crane3D_DevDriv_M->Timing.stepSize = (0.01);
  rtsiSetFixedStepSize(&optimis_Crane3D_DevDriv_M->solverInfo, 0.01);
  rtsiSetSolverMode(&optimis_Crane3D_DevDriv_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  optimis_Crane3D_DevDriv_M->ModelData.blockIO = ((void *)
    &optimis_Crane3D_DevDriv_B);

  {
    int32_T i;
    for (i = 0; i < 6; i++) {
      optimis_Crane3D_DevDriv_B.xwaypoints[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      optimis_Crane3D_DevDriv_B.ywaypoints[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      optimis_Crane3D_DevDriv_B.Encoder[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      optimis_Crane3D_DevDriv_B.ResetEncoder[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      optimis_Crane3D_DevDriv_B.ResetSource[i] = 0.0;
    }

    optimis_Crane3D_DevDriv_B.start_course = 0.0;
    optimis_Crane3D_DevDriv_B.total_waypoints = 0.0;
    optimis_Crane3D_DevDriv_B.XScale = 0.0;
    optimis_Crane3D_DevDriv_B.settling_time = 0.0;
    optimis_Crane3D_DevDriv_B.YScale = 0.0;
    optimis_Crane3D_DevDriv_B.XAngleScale = 0.0;
    optimis_Crane3D_DevDriv_B.YAngleScale = 0.0;
    optimis_Crane3D_DevDriv_B.Product2 = 0.0;
    optimis_Crane3D_DevDriv_B.Product1 = 0.0;
    optimis_Crane3D_DevDriv_B.Product = 0.0;
    optimis_Crane3D_DevDriv_B.Sum1 = 0.0;
    optimis_Crane3D_DevDriv_B.Product2_k = 0.0;
    optimis_Crane3D_DevDriv_B.Product1_i = 0.0;
    optimis_Crane3D_DevDriv_B.Product1_ik = 0.0;
    optimis_Crane3D_DevDriv_B.PWM[0] = 0.0;
    optimis_Crane3D_DevDriv_B.PWM[1] = 0.0;
    optimis_Crane3D_DevDriv_B.PWM[2] = 0.0;
    optimis_Crane3D_DevDriv_B.Saturation[0] = 0.0;
    optimis_Crane3D_DevDriv_B.Saturation[1] = 0.0;
    optimis_Crane3D_DevDriv_B.Saturation[2] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlag[0] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlag[1] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlag[2] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlagSource[0] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlagSource[1] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitFlagSource[2] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSource[0] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSource[1] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSource[2] = 0.0;
    optimis_Crane3D_DevDriv_B.SetLimit[0] = 0.0;
    optimis_Crane3D_DevDriv_B.SetLimit[1] = 0.0;
    optimis_Crane3D_DevDriv_B.SetLimit[2] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSwitch[0] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSwitch[1] = 0.0;
    optimis_Crane3D_DevDriv_B.LimitSwitch[2] = 0.0;
    optimis_Crane3D_DevDriv_B.PWMPrescaler = 0.0;
    optimis_Crane3D_DevDriv_B.PWMPrescalerSource = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlag[0] = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlag[1] = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlag[2] = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[0] = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[1] = 0.0;
    optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[2] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlag[0] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlag[1] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlag[2] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlagSource[0] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlagSource[1] = 0.0;
    optimis_Crane3D_DevDriv_B.ThermFlagSource[2] = 0.0;
    optimis_Crane3D_DevDriv_B.Product_f = 0.0;
    optimis_Crane3D_DevDriv_B.Product_c = 0.0;
    optimis_Crane3D_DevDriv_B.Clock = 0.0;
    optimis_Crane3D_DevDriv_B.done = 0.0;
    optimis_Crane3D_DevDriv_B.close_switch = 0.0;
    optimis_Crane3D_DevDriv_B.xref = 0.0;
    optimis_Crane3D_DevDriv_B.yref = 0.0;
    optimis_Crane3D_DevDriv_B.Kiy = 0.0;
    optimis_Crane3D_DevDriv_B.at_waypoint = 0.0;
    optimis_Crane3D_DevDriv_B.Kdy = 0.0;
    optimis_Crane3D_DevDriv_B.Kpy = 0.0;
    optimis_Crane3D_DevDriv_B.Kpay = 0.0;
    optimis_Crane3D_DevDriv_B.kix = 0.0;
    optimis_Crane3D_DevDriv_B.kpx = 0.0;
    optimis_Crane3D_DevDriv_B.kpax = 0.0;
    optimis_Crane3D_DevDriv_B.LowpassFilter2 = 0.0;
    optimis_Crane3D_DevDriv_B.u00 = 0.0;
    optimis_Crane3D_DevDriv_B.u0 = 0.0;
    optimis_Crane3D_DevDriv_B.u00_p = 0.0;
    optimis_Crane3D_DevDriv_B.ma = 0.0;
  }

  /* parameters */
  optimis_Crane3D_DevDriv_M->ModelData.defaultParam = ((real_T *)
    &optimis_Crane3D_DevDriv_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &optimis_Crane3D_DevDriv_X;
    optimis_Crane3D_DevDriv_M->ModelData.contStates = (x);
    (void) memset((void *)&optimis_Crane3D_DevDriv_X, 0,
                  sizeof(X_optimis_Crane3D_DevDriv_T));
  }

  /* states (dwork) */
  optimis_Crane3D_DevDriv_M->ModelData.dwork = ((void *)
    &optimis_Crane3D_DevDriv_DW);
  (void) memset((void *)&optimis_Crane3D_DevDriv_DW, 0,
                sizeof(DW_optimis_Crane3D_DevDriv_T));

  {
    int32_T i;
    for (i = 0; i < 29; i++) {
      optimis_Crane3D_DevDriv_DW.State[i] = 0.0;
    }
  }

  optimis_Crane3D_DevDriv_DW.TimeStampA = 0.0;
  optimis_Crane3D_DevDriv_DW.LastUAtTimeA = 0.0;
  optimis_Crane3D_DevDriv_DW.TimeStampB = 0.0;
  optimis_Crane3D_DevDriv_DW.LastUAtTimeB = 0.0;
  optimis_Crane3D_DevDriv_DW.TimeStampA_o = 0.0;
  optimis_Crane3D_DevDriv_DW.LastUAtTimeA_i = 0.0;
  optimis_Crane3D_DevDriv_DW.TimeStampB_c = 0.0;
  optimis_Crane3D_DevDriv_DW.LastUAtTimeB_o = 0.0;
  optimis_Crane3D_DevDriv_DW.ready = 0.0;
  optimis_Crane3D_DevDriv_DW.xlocal = 0.0;
  optimis_Crane3D_DevDriv_DW.ylocal = 0.0;
  optimis_Crane3D_DevDriv_DW.index = 0.0;
  optimis_Crane3D_DevDriv_DW.initialized = 0.0;
  optimis_Crane3D_DevDriv_DW.arrived = 0.0;
  optimis_Crane3D_DevDriv_DW.i = 0.0;
  optimis_Crane3D_DevDriv_DW.finished = 0.0;
  optimis_Crane3D_DevDriv_DW.Kiy_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kd_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kp_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Ki_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kpa_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kix_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kpx_l = 0.0;
  optimis_Crane3D_DevDriv_DW.Kpax_l = 0.0;

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    optimis_Crane3D_DevDriv_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 23;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.sfcnInfo;
    optimis_Crane3D_DevDriv_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus
      (optimis_Crane3D_DevDriv_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo,
      &optimis_Crane3D_DevDriv_M->Sizes.numSampTimes);
    optimis_Crane3D_DevDriv_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (optimis_Crane3D_DevDriv_M)[0]);
    optimis_Crane3D_DevDriv_M->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr
      (optimis_Crane3D_DevDriv_M)[1]);
    rtssSetTPtrPtr(sfcnInfo,
                   optimis_Crane3D_DevDriv_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(optimis_Crane3D_DevDriv_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(optimis_Crane3D_DevDriv_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (optimis_Crane3D_DevDriv_M));
    rtssSetStepSizePtr(sfcnInfo, &optimis_Crane3D_DevDriv_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested
      (optimis_Crane3D_DevDriv_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &optimis_Crane3D_DevDriv_M->ModelData.derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &optimis_Crane3D_DevDriv_M->ModelData.zCCacheNeedsReset);
    rtssSetBlkStateChangePtr(sfcnInfo,
      &optimis_Crane3D_DevDriv_M->ModelData.blkStateChange);
    rtssSetSampleHitsPtr(sfcnInfo, &optimis_Crane3D_DevDriv_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &optimis_Crane3D_DevDriv_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &optimis_Crane3D_DevDriv_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &optimis_Crane3D_DevDriv_M->solverInfoPtr);
  }

  optimis_Crane3D_DevDriv_M->Sizes.numSFcns = (9);

  /* register each child */
  {
    (void) memset((void *)
                  &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.childSFunctions[0],
                  0,
                  9*sizeof(SimStruct));
    optimis_Crane3D_DevDriv_M->childSfunctions =
      (&optimis_Crane3D_DevDriv_M->NonInlinedSFcns.childSFunctionPtrs[0]);

    {
      int_T i;
      for (i = 0; i < 9; i++) {
        optimis_Crane3D_DevDriv_M->childSfunctions[i] =
          (&optimis_Crane3D_DevDriv_M->NonInlinedSFcns.childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/Encoder (Crane3D_Encoder) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[0]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.Encoder));
        }
      }

      /* path info */
      ssSetModelName(rts, "Encoder");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/Encoder");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.Encoder_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.Encoder_P2_Size);
      }

      /* registration */
      Crane3D_Encoder(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/PWM (Crane3D_PWM) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[1]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.UPtrs0;
          sfcnUPtrs[0] = optimis_Crane3D_DevDriv_B.Saturation;
          sfcnUPtrs[1] = &optimis_Crane3D_DevDriv_B.Saturation[1];
          sfcnUPtrs[2] = &optimis_Crane3D_DevDriv_B.Saturation[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.PWM));
        }
      }

      /* path info */
      ssSetModelName(rts, "PWM");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/PWM");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)optimis_Crane3D_DevDriv_P.PWM_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)optimis_Crane3D_DevDriv_P.PWM_P2_Size);
      }

      /* registration */
      Crane3D_PWM(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/LimitFlag (Crane3D_LimitFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[2]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.UPtrs0;
          sfcnUPtrs[0] = optimis_Crane3D_DevDriv_B.LimitFlagSource;
          sfcnUPtrs[1] = &optimis_Crane3D_DevDriv_B.LimitFlagSource[1];
          sfcnUPtrs[2] = &optimis_Crane3D_DevDriv_B.LimitFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.LimitFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "LimitFlag");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/LimitFlag");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.LimitFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.LimitFlag_P2_Size);
      }

      /* registration */
      Crane3D_LimitFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/SetLimit (Crane3D_SetLimit) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[3]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[3]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[3]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.UPtrs0;
          sfcnUPtrs[0] = optimis_Crane3D_DevDriv_B.LimitSource;
          sfcnUPtrs[1] = &optimis_Crane3D_DevDriv_B.LimitSource[1];
          sfcnUPtrs[2] = &optimis_Crane3D_DevDriv_B.LimitSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.SetLimit));
        }
      }

      /* path info */
      ssSetModelName(rts, "SetLimit");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/SetLimit");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.SetLimit_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.SetLimit_P2_Size);
      }

      /* registration */
      Crane3D_SetLimit(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/LimitSwitch (Crane3D_Switch) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[4]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[4]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[4]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn4.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.LimitSwitch));
        }
      }

      /* path info */
      ssSetModelName(rts, "LimitSwitch");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/LimitSwitch");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.LimitSwitch_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.LimitSwitch_P2_Size);
      }

      /* registration */
      Crane3D_Switch(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/PWMPrescaler (Crane3D_PWMPrescaler) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[5];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[5]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [5]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [5]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[5]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[5]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.UPtrs0;
          sfcnUPtrs[0] = &optimis_Crane3D_DevDriv_B.PWMPrescalerSource;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &optimis_Crane3D_DevDriv_B.PWMPrescaler));
        }
      }

      /* path info */
      ssSetModelName(rts, "PWMPrescaler");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/PWMPrescaler");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn5.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.PWMPrescaler_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.PWMPrescaler_P2_Size);
      }

      /* registration */
      Crane3D_PWMPrescaler(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/ResetEncoder (Crane3D_ResetEncoder) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[6];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[6]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [6]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [6]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[6]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[6]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.UPtrs0;

          {
            int_T i1;
            const real_T *u0 = optimis_Crane3D_DevDriv_B.ResetSource;
            for (i1=0; i1 < 5; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }

          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 5);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 5);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.ResetEncoder));
        }
      }

      /* path info */
      ssSetModelName(rts, "ResetEncoder");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/ResetEncoder");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn6.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ResetEncoder_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ResetEncoder_P2_Size);
      }

      /* registration */
      Crane3D_ResetEncoder(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/ResetSwitchFlag  (Crane3D_ResetSwitchFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[7];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[7]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [7]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [7]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[7]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[7]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.UPtrs0;
          sfcnUPtrs[0] = optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource;
          sfcnUPtrs[1] = &optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[1];
          sfcnUPtrs[2] = &optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.ResetSwitchFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "ResetSwitchFlag ");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/ResetSwitchFlag ");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn7.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ResetSwitchFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ResetSwitchFlag_P2_Size);
      }

      /* registration */
      Crane3D_ResetSwitchFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: optimis_Crane3D_DevDriv/<S1>/ThermFlag  (Crane3D_ThermFlag) */
    {
      SimStruct *rts = optimis_Crane3D_DevDriv_M->childSfunctions[8];

      /* timing info */
      time_T *sfcnPeriod =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.sfcnPeriod;
      time_T *sfcnOffset =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.sfcnOffset;
      int_T *sfcnTsMap =
        optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        ssSetBlkInfo2Ptr(rts,
                         &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.blkInfo2[8]);
      }

      ssSetRTWSfcnInfo(rts, optimis_Crane3D_DevDriv_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods2
                           [8]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts,
                           &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.methods3
                           [8]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &optimis_Crane3D_DevDriv_M->
                         NonInlinedSFcns.statesInfo2[8]);
        ssSetPeriodicStatesInfo(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.periodicStatesInfo[8]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.inputPortInfo[0]);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.UPtrs0;
          sfcnUPtrs[0] = optimis_Crane3D_DevDriv_B.ThermFlagSource;
          sfcnUPtrs[1] = &optimis_Crane3D_DevDriv_B.ThermFlagSource[1];
          sfcnUPtrs[2] = &optimis_Crane3D_DevDriv_B.ThermFlagSource[2];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 3);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 3);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            optimis_Crane3D_DevDriv_B.ThermFlag));
        }
      }

      /* path info */
      ssSetModelName(rts, "ThermFlag ");
      ssSetPath(rts, "optimis_Crane3D_DevDriv/Crane 3D/ThermFlag ");
      ssSetRTModel(rts,optimis_Crane3D_DevDriv_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &optimis_Crane3D_DevDriv_M->NonInlinedSFcns.Sfcn8.params;
        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ThermFlag_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       optimis_Crane3D_DevDriv_P.ThermFlag_P2_Size);
      }

      /* registration */
      Crane3D_ThermFlag(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.01);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }
  }

  /* Initialize Sizes */
  optimis_Crane3D_DevDriv_M->Sizes.numContStates = (2);/* Number of continuous states */
  optimis_Crane3D_DevDriv_M->Sizes.numPeriodicContStates = (0);/* Number of periodic continuous states */
  optimis_Crane3D_DevDriv_M->Sizes.numY = (0);/* Number of model outputs */
  optimis_Crane3D_DevDriv_M->Sizes.numU = (0);/* Number of model inputs */
  optimis_Crane3D_DevDriv_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  optimis_Crane3D_DevDriv_M->Sizes.numSampTimes = (2);/* Number of sample times */
  optimis_Crane3D_DevDriv_M->Sizes.numBlocks = (79);/* Number of blocks */
  optimis_Crane3D_DevDriv_M->Sizes.numBlockIO = (52);/* Number of block outputs */
  optimis_Crane3D_DevDriv_M->Sizes.numBlockPrms = (108);/* Sum of parameter "widths" */
  return optimis_Crane3D_DevDriv_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
