  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (optimis_Crane3D_DevDriv_P)
    ;%
      section.nData     = 68;
      section.data(68)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_P.settling_time
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% optimis_Crane3D_DevDriv_P.start_course
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% optimis_Crane3D_DevDriv_P.total_waypoints
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% optimis_Crane3D_DevDriv_P.xwaypoints
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% optimis_Crane3D_DevDriv_P.ywaypoints
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 9;
	
	  ;% optimis_Crane3D_DevDriv_P.Encoder_P1_Size
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 15;
	
	  ;% optimis_Crane3D_DevDriv_P.Encoder_P1
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 17;
	
	  ;% optimis_Crane3D_DevDriv_P.Encoder_P2_Size
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 18;
	
	  ;% optimis_Crane3D_DevDriv_P.Encoder_P2
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 20;
	
	  ;% optimis_Crane3D_DevDriv_P.Encoder500PPR_Gain
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 21;
	
	  ;% optimis_Crane3D_DevDriv_P.XScale_Gain
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 22;
	
	  ;% optimis_Crane3D_DevDriv_P.YScale_Gain
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 23;
	
	  ;% optimis_Crane3D_DevDriv_P.XAngleScale_Gain
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 24;
	
	  ;% optimis_Crane3D_DevDriv_P.YAngleScale_Gain
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 25;
	
	  ;% optimis_Crane3D_DevDriv_P.Integrator_IC
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 26;
	
	  ;% optimis_Crane3D_DevDriv_P.Integrator_UpperSat
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 27;
	
	  ;% optimis_Crane3D_DevDriv_P.Integrator_LowerSat
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 28;
	
	  ;% optimis_Crane3D_DevDriv_P.Constant_Value
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 29;
	
	  ;% optimis_Crane3D_DevDriv_P.Integrator_IC_a
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 30;
	
	  ;% optimis_Crane3D_DevDriv_P.Integrator_UpperSat_g
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 31;
	
	  ;% optimis_Crane3D_DevDriv_P.Integrator_LowerSat_d
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 32;
	
	  ;% optimis_Crane3D_DevDriv_P.Constant2_Value
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 33;
	
	  ;% optimis_Crane3D_DevDriv_P.PWM_P1_Size
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 34;
	
	  ;% optimis_Crane3D_DevDriv_P.PWM_P1
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 36;
	
	  ;% optimis_Crane3D_DevDriv_P.PWM_P2_Size
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 37;
	
	  ;% optimis_Crane3D_DevDriv_P.PWM_P2
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 39;
	
	  ;% optimis_Crane3D_DevDriv_P.Switch_Threshold
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 40;
	
	  ;% optimis_Crane3D_DevDriv_P.Saturation_UpperSat
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 41;
	
	  ;% optimis_Crane3D_DevDriv_P.Saturation_LowerSat
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 42;
	
	  ;% optimis_Crane3D_DevDriv_P.Switch1_Threshold
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 43;
	
	  ;% optimis_Crane3D_DevDriv_P.Saturation1_UpperSat
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 44;
	
	  ;% optimis_Crane3D_DevDriv_P.Saturation1_LowerSat
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 45;
	
	  ;% optimis_Crane3D_DevDriv_P.Saturation_UpperSat_j
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 46;
	
	  ;% optimis_Crane3D_DevDriv_P.Saturation_LowerSat_l
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 47;
	
	  ;% optimis_Crane3D_DevDriv_P.LimitFlag_P1_Size
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 48;
	
	  ;% optimis_Crane3D_DevDriv_P.LimitFlag_P1
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 50;
	
	  ;% optimis_Crane3D_DevDriv_P.LimitFlag_P2_Size
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 51;
	
	  ;% optimis_Crane3D_DevDriv_P.LimitFlag_P2
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 53;
	
	  ;% optimis_Crane3D_DevDriv_P.LimitFlagSource_Value
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 54;
	
	  ;% optimis_Crane3D_DevDriv_P.LimitSource_Value
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 57;
	
	  ;% optimis_Crane3D_DevDriv_P.SetLimit_P1_Size
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 60;
	
	  ;% optimis_Crane3D_DevDriv_P.SetLimit_P1
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 62;
	
	  ;% optimis_Crane3D_DevDriv_P.SetLimit_P2_Size
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 63;
	
	  ;% optimis_Crane3D_DevDriv_P.SetLimit_P2
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 65;
	
	  ;% optimis_Crane3D_DevDriv_P.LimitSwitch_P1_Size
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 66;
	
	  ;% optimis_Crane3D_DevDriv_P.LimitSwitch_P1
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 68;
	
	  ;% optimis_Crane3D_DevDriv_P.LimitSwitch_P2_Size
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 69;
	
	  ;% optimis_Crane3D_DevDriv_P.LimitSwitch_P2
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 71;
	
	  ;% optimis_Crane3D_DevDriv_P.PWMPrescaler_P1_Size
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 72;
	
	  ;% optimis_Crane3D_DevDriv_P.PWMPrescaler_P1
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 74;
	
	  ;% optimis_Crane3D_DevDriv_P.PWMPrescaler_P2_Size
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 75;
	
	  ;% optimis_Crane3D_DevDriv_P.PWMPrescaler_P2
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 77;
	
	  ;% optimis_Crane3D_DevDriv_P.PWMPrescalerSource_Value
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 78;
	
	  ;% optimis_Crane3D_DevDriv_P.ResetEncoder_P1_Size
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 79;
	
	  ;% optimis_Crane3D_DevDriv_P.ResetEncoder_P1
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 81;
	
	  ;% optimis_Crane3D_DevDriv_P.ResetEncoder_P2_Size
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 82;
	
	  ;% optimis_Crane3D_DevDriv_P.ResetEncoder_P2
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 84;
	
	  ;% optimis_Crane3D_DevDriv_P.ResetSource_Value
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 85;
	
	  ;% optimis_Crane3D_DevDriv_P.ResetSwitchFlag_P1_Size
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 90;
	
	  ;% optimis_Crane3D_DevDriv_P.ResetSwitchFlag_P1
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 92;
	
	  ;% optimis_Crane3D_DevDriv_P.ResetSwitchFlag_P2_Size
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 93;
	
	  ;% optimis_Crane3D_DevDriv_P.ResetSwitchFlag_P2
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 95;
	
	  ;% optimis_Crane3D_DevDriv_P.ResetSwitchFlagSource_Value
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 96;
	
	  ;% optimis_Crane3D_DevDriv_P.ThermFlag_P1_Size
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 99;
	
	  ;% optimis_Crane3D_DevDriv_P.ThermFlag_P1
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 101;
	
	  ;% optimis_Crane3D_DevDriv_P.ThermFlag_P2_Size
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 102;
	
	  ;% optimis_Crane3D_DevDriv_P.ThermFlag_P2
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 104;
	
	  ;% optimis_Crane3D_DevDriv_P.ThermFlagSource_Value
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 105;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (optimis_Crane3D_DevDriv_B)
    ;%
      section.nData     = 52;
      section.data(52)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_B.start_course
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% optimis_Crane3D_DevDriv_B.xwaypoints
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% optimis_Crane3D_DevDriv_B.ywaypoints
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 7;
	
	  ;% optimis_Crane3D_DevDriv_B.total_waypoints
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 13;
	
	  ;% optimis_Crane3D_DevDriv_B.Encoder
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 14;
	
	  ;% optimis_Crane3D_DevDriv_B.XScale
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 19;
	
	  ;% optimis_Crane3D_DevDriv_B.settling_time
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 20;
	
	  ;% optimis_Crane3D_DevDriv_B.YScale
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 21;
	
	  ;% optimis_Crane3D_DevDriv_B.XAngleScale
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 22;
	
	  ;% optimis_Crane3D_DevDriv_B.YAngleScale
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 23;
	
	  ;% optimis_Crane3D_DevDriv_B.Product2
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 24;
	
	  ;% optimis_Crane3D_DevDriv_B.Product1
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 25;
	
	  ;% optimis_Crane3D_DevDriv_B.Product
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 26;
	
	  ;% optimis_Crane3D_DevDriv_B.Sum1
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 27;
	
	  ;% optimis_Crane3D_DevDriv_B.Product2_k
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 28;
	
	  ;% optimis_Crane3D_DevDriv_B.Product1_i
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 29;
	
	  ;% optimis_Crane3D_DevDriv_B.Product1_ik
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 30;
	
	  ;% optimis_Crane3D_DevDriv_B.PWM
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 31;
	
	  ;% optimis_Crane3D_DevDriv_B.Saturation
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 34;
	
	  ;% optimis_Crane3D_DevDriv_B.LimitFlag
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 37;
	
	  ;% optimis_Crane3D_DevDriv_B.LimitFlagSource
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 40;
	
	  ;% optimis_Crane3D_DevDriv_B.LimitSource
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 43;
	
	  ;% optimis_Crane3D_DevDriv_B.SetLimit
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 46;
	
	  ;% optimis_Crane3D_DevDriv_B.LimitSwitch
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 49;
	
	  ;% optimis_Crane3D_DevDriv_B.PWMPrescaler
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 52;
	
	  ;% optimis_Crane3D_DevDriv_B.PWMPrescalerSource
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 53;
	
	  ;% optimis_Crane3D_DevDriv_B.ResetEncoder
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 54;
	
	  ;% optimis_Crane3D_DevDriv_B.ResetSource
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 59;
	
	  ;% optimis_Crane3D_DevDriv_B.ResetSwitchFlag
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 64;
	
	  ;% optimis_Crane3D_DevDriv_B.ResetSwitchFlagSource
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 67;
	
	  ;% optimis_Crane3D_DevDriv_B.ThermFlag
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 70;
	
	  ;% optimis_Crane3D_DevDriv_B.ThermFlagSource
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 73;
	
	  ;% optimis_Crane3D_DevDriv_B.Product_f
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 76;
	
	  ;% optimis_Crane3D_DevDriv_B.Product_c
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 77;
	
	  ;% optimis_Crane3D_DevDriv_B.Clock
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 78;
	
	  ;% optimis_Crane3D_DevDriv_B.done
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 79;
	
	  ;% optimis_Crane3D_DevDriv_B.close_switch
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 80;
	
	  ;% optimis_Crane3D_DevDriv_B.xref
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 81;
	
	  ;% optimis_Crane3D_DevDriv_B.yref
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 82;
	
	  ;% optimis_Crane3D_DevDriv_B.Kiy
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 83;
	
	  ;% optimis_Crane3D_DevDriv_B.at_waypoint
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 84;
	
	  ;% optimis_Crane3D_DevDriv_B.Kdy
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 85;
	
	  ;% optimis_Crane3D_DevDriv_B.Kpy
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 86;
	
	  ;% optimis_Crane3D_DevDriv_B.Kpay
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 87;
	
	  ;% optimis_Crane3D_DevDriv_B.kix
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 88;
	
	  ;% optimis_Crane3D_DevDriv_B.kpx
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 89;
	
	  ;% optimis_Crane3D_DevDriv_B.kpax
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 90;
	
	  ;% optimis_Crane3D_DevDriv_B.LowpassFilter2
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 91;
	
	  ;% optimis_Crane3D_DevDriv_B.u00
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 92;
	
	  ;% optimis_Crane3D_DevDriv_B.u0
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 93;
	
	  ;% optimis_Crane3D_DevDriv_B.u00_p
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 94;
	
	  ;% optimis_Crane3D_DevDriv_B.ma
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 95;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 15;
    sectIdxOffset = 1;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (optimis_Crane3D_DevDriv_DW)
    ;%
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.gobj_0
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% optimis_Crane3D_DevDriv_DW.gobj_1
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.gobj_0_j
	  section.data(1).logicalSrcIdx = 2;
	  section.data(1).dtTransOffset = 0;
	
	  ;% optimis_Crane3D_DevDriv_DW.gobj_1_p
	  section.data(2).logicalSrcIdx = 3;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.gobj_0_m
	  section.data(1).logicalSrcIdx = 4;
	  section.data(1).dtTransOffset = 0;
	
	  ;% optimis_Crane3D_DevDriv_DW.gobj_1_c
	  section.data(2).logicalSrcIdx = 5;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.gobj_0_f
	  section.data(1).logicalSrcIdx = 6;
	  section.data(1).dtTransOffset = 0;
	
	  ;% optimis_Crane3D_DevDriv_DW.gobj_1_m
	  section.data(2).logicalSrcIdx = 7;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.obj
	  section.data(1).logicalSrcIdx = 8;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(5) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.obj_o
	  section.data(1).logicalSrcIdx = 9;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(6) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.obj_or
	  section.data(1).logicalSrcIdx = 10;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(7) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.obj_a
	  section.data(1).logicalSrcIdx = 11;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(8) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.obj_b
	  section.data(1).logicalSrcIdx = 12;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(9) = section;
      clear section
      
      section.nData     = 25;
      section.data(25)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.State
	  section.data(1).logicalSrcIdx = 13;
	  section.data(1).dtTransOffset = 0;
	
	  ;% optimis_Crane3D_DevDriv_DW.TimeStampA
	  section.data(2).logicalSrcIdx = 14;
	  section.data(2).dtTransOffset = 29;
	
	  ;% optimis_Crane3D_DevDriv_DW.LastUAtTimeA
	  section.data(3).logicalSrcIdx = 15;
	  section.data(3).dtTransOffset = 30;
	
	  ;% optimis_Crane3D_DevDriv_DW.TimeStampB
	  section.data(4).logicalSrcIdx = 16;
	  section.data(4).dtTransOffset = 31;
	
	  ;% optimis_Crane3D_DevDriv_DW.LastUAtTimeB
	  section.data(5).logicalSrcIdx = 17;
	  section.data(5).dtTransOffset = 32;
	
	  ;% optimis_Crane3D_DevDriv_DW.TimeStampA_o
	  section.data(6).logicalSrcIdx = 18;
	  section.data(6).dtTransOffset = 33;
	
	  ;% optimis_Crane3D_DevDriv_DW.LastUAtTimeA_i
	  section.data(7).logicalSrcIdx = 19;
	  section.data(7).dtTransOffset = 34;
	
	  ;% optimis_Crane3D_DevDriv_DW.TimeStampB_c
	  section.data(8).logicalSrcIdx = 20;
	  section.data(8).dtTransOffset = 35;
	
	  ;% optimis_Crane3D_DevDriv_DW.LastUAtTimeB_o
	  section.data(9).logicalSrcIdx = 21;
	  section.data(9).dtTransOffset = 36;
	
	  ;% optimis_Crane3D_DevDriv_DW.ready
	  section.data(10).logicalSrcIdx = 22;
	  section.data(10).dtTransOffset = 37;
	
	  ;% optimis_Crane3D_DevDriv_DW.xlocal
	  section.data(11).logicalSrcIdx = 23;
	  section.data(11).dtTransOffset = 38;
	
	  ;% optimis_Crane3D_DevDriv_DW.ylocal
	  section.data(12).logicalSrcIdx = 24;
	  section.data(12).dtTransOffset = 39;
	
	  ;% optimis_Crane3D_DevDriv_DW.index
	  section.data(13).logicalSrcIdx = 25;
	  section.data(13).dtTransOffset = 40;
	
	  ;% optimis_Crane3D_DevDriv_DW.initialized
	  section.data(14).logicalSrcIdx = 26;
	  section.data(14).dtTransOffset = 41;
	
	  ;% optimis_Crane3D_DevDriv_DW.arrived
	  section.data(15).logicalSrcIdx = 27;
	  section.data(15).dtTransOffset = 42;
	
	  ;% optimis_Crane3D_DevDriv_DW.i
	  section.data(16).logicalSrcIdx = 28;
	  section.data(16).dtTransOffset = 43;
	
	  ;% optimis_Crane3D_DevDriv_DW.finished
	  section.data(17).logicalSrcIdx = 29;
	  section.data(17).dtTransOffset = 44;
	
	  ;% optimis_Crane3D_DevDriv_DW.Kiy_l
	  section.data(18).logicalSrcIdx = 30;
	  section.data(18).dtTransOffset = 45;
	
	  ;% optimis_Crane3D_DevDriv_DW.Kd_l
	  section.data(19).logicalSrcIdx = 31;
	  section.data(19).dtTransOffset = 46;
	
	  ;% optimis_Crane3D_DevDriv_DW.Kp_l
	  section.data(20).logicalSrcIdx = 32;
	  section.data(20).dtTransOffset = 47;
	
	  ;% optimis_Crane3D_DevDriv_DW.Ki_l
	  section.data(21).logicalSrcIdx = 33;
	  section.data(21).dtTransOffset = 48;
	
	  ;% optimis_Crane3D_DevDriv_DW.Kpa_l
	  section.data(22).logicalSrcIdx = 34;
	  section.data(22).dtTransOffset = 49;
	
	  ;% optimis_Crane3D_DevDriv_DW.Kix_l
	  section.data(23).logicalSrcIdx = 35;
	  section.data(23).dtTransOffset = 50;
	
	  ;% optimis_Crane3D_DevDriv_DW.Kpx_l
	  section.data(24).logicalSrcIdx = 36;
	  section.data(24).dtTransOffset = 51;
	
	  ;% optimis_Crane3D_DevDriv_DW.Kpax_l
	  section.data(25).logicalSrcIdx = 37;
	  section.data(25).dtTransOffset = 52;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(10) = section;
      clear section
      
      section.nData     = 17;
      section.data(17)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.Scope_PWORK.LoggedData
	  section.data(1).logicalSrcIdx = 38;
	  section.data(1).dtTransOffset = 0;
	
	  ;% optimis_Crane3D_DevDriv_DW.Scope1_PWORK.LoggedData
	  section.data(2).logicalSrcIdx = 39;
	  section.data(2).dtTransOffset = 3;
	
	  ;% optimis_Crane3D_DevDriv_DW.Scope2_PWORK.LoggedData
	  section.data(3).logicalSrcIdx = 40;
	  section.data(3).dtTransOffset = 6;
	
	  ;% optimis_Crane3D_DevDriv_DW.Scope3_PWORK.LoggedData
	  section.data(4).logicalSrcIdx = 41;
	  section.data(4).dtTransOffset = 7;
	
	  ;% optimis_Crane3D_DevDriv_DW.Scope4_PWORK.LoggedData
	  section.data(5).logicalSrcIdx = 42;
	  section.data(5).dtTransOffset = 11;
	
	  ;% optimis_Crane3D_DevDriv_DW.anglex_PWORK.LoggedData
	  section.data(6).logicalSrcIdx = 43;
	  section.data(6).dtTransOffset = 13;
	
	  ;% optimis_Crane3D_DevDriv_DW.angley_PWORK.LoggedData
	  section.data(7).logicalSrcIdx = 44;
	  section.data(7).dtTransOffset = 14;
	
	  ;% optimis_Crane3D_DevDriv_DW.filtered_signal_PWORK.LoggedData
	  section.data(8).logicalSrcIdx = 45;
	  section.data(8).dtTransOffset = 15;
	
	  ;% optimis_Crane3D_DevDriv_DW.xpos_PWORK.LoggedData
	  section.data(9).logicalSrcIdx = 46;
	  section.data(9).dtTransOffset = 16;
	
	  ;% optimis_Crane3D_DevDriv_DW.ypos_PWORK.LoggedData
	  section.data(10).logicalSrcIdx = 47;
	  section.data(10).dtTransOffset = 17;
	
	  ;% optimis_Crane3D_DevDriv_DW.Scope_PWORK_b.LoggedData
	  section.data(11).logicalSrcIdx = 48;
	  section.data(11).dtTransOffset = 18;
	
	  ;% optimis_Crane3D_DevDriv_DW.ToWorkspace4_PWORK.LoggedData
	  section.data(12).logicalSrcIdx = 49;
	  section.data(12).dtTransOffset = 21;
	
	  ;% optimis_Crane3D_DevDriv_DW.LowpassFilter2_PWORK
	  section.data(13).logicalSrcIdx = 50;
	  section.data(13).dtTransOffset = 22;
	
	  ;% optimis_Crane3D_DevDriv_DW.LowpassFilter1_PWORK
	  section.data(14).logicalSrcIdx = 51;
	  section.data(14).dtTransOffset = 23;
	
	  ;% optimis_Crane3D_DevDriv_DW.LowpassFilter3_PWORK
	  section.data(15).logicalSrcIdx = 52;
	  section.data(15).dtTransOffset = 24;
	
	  ;% optimis_Crane3D_DevDriv_DW.LowpassFilter4_PWORK
	  section.data(16).logicalSrcIdx = 53;
	  section.data(16).dtTransOffset = 25;
	
	  ;% optimis_Crane3D_DevDriv_DW.MATLABSystem_PWORK
	  section.data(17).logicalSrcIdx = 54;
	  section.data(17).dtTransOffset = 26;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(11) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.sfEvent
	  section.data(1).logicalSrcIdx = 55;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(12) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.temporalCounter_i1
	  section.data(1).logicalSrcIdx = 56;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(13) = section;
      clear section
      
      section.nData     = 5;
      section.data(5)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.is_active_c3_optimis_Crane3D_DevDriv
	  section.data(1).logicalSrcIdx = 57;
	  section.data(1).dtTransOffset = 0;
	
	  ;% optimis_Crane3D_DevDriv_DW.is_c3_optimis_Crane3D_DevDriv
	  section.data(2).logicalSrcIdx = 58;
	  section.data(2).dtTransOffset = 1;
	
	  ;% optimis_Crane3D_DevDriv_DW.is_active_S1_setpoints
	  section.data(3).logicalSrcIdx = 59;
	  section.data(3).dtTransOffset = 2;
	
	  ;% optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidy
	  section.data(4).logicalSrcIdx = 60;
	  section.data(4).dtTransOffset = 3;
	
	  ;% optimis_Crane3D_DevDriv_DW.is_active_S1_setup_pidx
	  section.data(5).logicalSrcIdx = 61;
	  section.data(5).dtTransOffset = 4;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(14) = section;
      clear section
      
      section.nData     = 9;
      section.data(9)  = dumData; %prealloc
      
	  ;% optimis_Crane3D_DevDriv_DW.objisempty
	  section.data(1).logicalSrcIdx = 62;
	  section.data(1).dtTransOffset = 0;
	
	  ;% optimis_Crane3D_DevDriv_DW.isInitialized
	  section.data(2).logicalSrcIdx = 63;
	  section.data(2).dtTransOffset = 1;
	
	  ;% optimis_Crane3D_DevDriv_DW.objisempty_i
	  section.data(3).logicalSrcIdx = 64;
	  section.data(3).dtTransOffset = 2;
	
	  ;% optimis_Crane3D_DevDriv_DW.isInitialized_b
	  section.data(4).logicalSrcIdx = 65;
	  section.data(4).dtTransOffset = 3;
	
	  ;% optimis_Crane3D_DevDriv_DW.objisempty_g
	  section.data(5).logicalSrcIdx = 66;
	  section.data(5).dtTransOffset = 4;
	
	  ;% optimis_Crane3D_DevDriv_DW.isInitialized_f
	  section.data(6).logicalSrcIdx = 67;
	  section.data(6).dtTransOffset = 5;
	
	  ;% optimis_Crane3D_DevDriv_DW.objisempty_id
	  section.data(7).logicalSrcIdx = 68;
	  section.data(7).dtTransOffset = 6;
	
	  ;% optimis_Crane3D_DevDriv_DW.isInitialized_i
	  section.data(8).logicalSrcIdx = 69;
	  section.data(8).dtTransOffset = 7;
	
	  ;% optimis_Crane3D_DevDriv_DW.objisempty_f
	  section.data(9).logicalSrcIdx = 70;
	  section.data(9).dtTransOffset = 8;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(15) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 1105797257;
  targMap.checksum1 = 59500163;
  targMap.checksum2 = 1885592543;
  targMap.checksum3 = 3749051681;

