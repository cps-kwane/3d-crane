%% Test Cases
%%TC0  score=194   fails at 7 but massive overshoot

% Ki=0.2;
% Kia=20;
% Kp=11.9;
% Kpa=4;
% 
% Kix=0.2;
% kiax=20;
% Kpx=11.9;
% Kpax=4;

%%TC1 score=260.8466  failed=19
% Ki = 0.0533;
% Kia=0.9525;
% Kp = 5.3996;
% Kpa = 1.4692;
% 
% Kix=0.2;
% kiax=20;
% Kpx=11.9;
% Kpax=4;

%%TC2  Everything above this is horrible (this is decent)
%%(score=260.2598)failed 21/100
%%count=
% Ki = 0.0579;
% Kia= 1.0488;
% Kp = 5.8410;
% Kpa = 2.002;
% 
% Kix=0.2;
% kiax=20;
% Kpx=11.9;
% Kpax=4;

%%TC3 bad (826.7084) count= 58. for 58 out of 100 failed

% Ki = 0.0028;
% Kia=1.5124;
% Kp = 3.88110;
% Kpa = 4.225;
% 
% Kix = 0.2;
% kiax=20;
% Kpx = 11.9;
% Kpax = 4;


%%TC4 : Used error bounds in minitune without sustaining oscillations
%%(sCORES 254.5933-350) count=27
% Ki=0.283;
% Kia=-2.1399;
% Kp=5.7005;
% Kpa=4.55
% 
% 
% Kix=0.1339;
% kiax=84.9582;
% Kpx=26.6391;
% Kpax=5.5734;

%%TC5   TC4 + SUstained oscillations (SCORES 332.069  c=25) 
% Ki=0.2814;
% Kia=-1.8722;
% Kp=5.0582;
% Kpa=4.524;
% 
% 
% Kix=0.1323;
% kiax=84.9712;
% Kpx=26.6734;
% Kpax=5.5873;

%TC6 attempt at Improved TC0 without massive overshoot(score=564 failed at 43)
% 
% Ki=0.0181;
% Kia=-0.0959;
% Kp=4.5097;
% Kpa=5.6365;
% 
% Kix=0.2;
% kiax=20;
% Kpx=11.9;
% Kpax=4;

%% TC 7 231.1613  count=17  manually tuned TC0
% Ki=0.2;
% Kia=-0.3;
% Kp=6;
% Kpa=4;
% 
% Kix=0.2;
% kiax=20;
% Kpx=11.9;
% Kpax=4;

 %% TC 8 510.3965  40

% Ki=0.1824;
% Kia=-0.1974;
% Kp=4.9261;
% Kpa=3.6143;
% 
% Kix=0.2008;
% kiax=15.7929;
% Kpx=11.9;
% Kpax=4.3256;
%  
 
%% TC 9: Used above and optimized for y step response and angle bounds
% Ki=0.1824;
% Kia=-0.1974;
% Kp=4.9261;
% Kpa=3.6143;
% 
% 
% 
% Kix=0.2008;
% kiax=15.7929;
% Kpx=11.7366;
% Kpax=4.3256;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%TC 10 TC2 & FIXED X STEP RESPONSE AT 0.3

% Ki = 0.0579;
% Kia= 1.0488;
% Kp = 5.8410;
% Kpa = 2.002;
% 
% Kix=0.1389;
% kiax=70.6212;
% Kpx=14.823;
% Kpax=4.0284;

%%TC 11 :TC10 and signal tracking optimization

% Ki = 0.0579;
% Kia= 1.0488;
% Kp = 5.8410;
% Kpa = 2.002;
% 
%  Kix=0.1127;
% kiax=-3.9015;
% Kpx=16.3782;
% Kpax=-0.6432;

 %%TC12: ABOVE PLUS MINIMIZE Y OVERSHOOT
%  Ki = 1.0195;
% Kia= 1.0488;
% Kp = 3.2118;
% Kpa = 2.4981;
% 
%  Kix=0.1127;
% kiax=-3.3654;
% Kpx=16.2446;
% Kpax=-0.3337;
      
 

